package br.com.danilo.feedlauncher;

import java.util.HashMap;
import java.util.Map;

/**
 * v0.30.41 — guarda apenas assinaturas leves do conteúdo já materializado no feed.
 * Não conhece Views: serve para evitar reconstruções incrementais quando os dados
 * que seriam mostrados continuam idênticos.
 */
final class SectionRenderGate {
    private final HashMap<String, String> renderedSignatures = new HashMap<>();
    private long requests = 0L;
    private long skippedEqual = 0L;
    private long applied = 0L;

    void noteRequest() { requests++; }

    boolean isSame(String sectionId, String signature) {
        if (sectionId == null || signature == null) return false;
        String previous = renderedSignatures.get(sectionId);
        if (signature.equals(previous)) {
            skippedEqual++;
            return true;
        }
        return false;
    }

    void markApplied(String sectionId, String signature) {
        applied++;
        if (sectionId != null && signature != null) renderedSignatures.put(sectionId, signature);
    }

    void markSignature(String sectionId, String signature) {
        if (sectionId != null && signature != null) renderedSignatures.put(sectionId, signature);
    }

    void invalidate(String sectionId) {
        if (sectionId != null) renderedSignatures.remove(sectionId);
    }

    void clearSignatures() { renderedSignatures.clear(); }

    void resetMetrics() {
        requests = 0L;
        skippedEqual = 0L;
        applied = 0L;
    }

    long requests() { return requests; }
    long skippedEqual() { return skippedEqual; }
    long applied() { return applied; }
    int tracked() { return renderedSignatures.size(); }
}
