/*
 * Copyright (C) 2026 FeedLauncher contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Launcher3-style in-process drag controller for app/folder shortcuts. The dragged visual lives
 * in the launcher root (DragLayer role), follows the pointer, previews CellLayout reordering and
 * commits/cancels atomically without Android View.startDragAndDrop().
 */
package br.com.danilo.feedlauncher.classic;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

final class L3ItemDragController {
    interface Listener {
        void onItemDragMove(ClassicWorkspace.DragPayload payload,float rawX,float rawY);
        boolean onItemDropTarget(ClassicWorkspace.DragPayload payload,float rawX,float rawY);
        void onItemDragFinished(ClassicWorkspace.DragPayload payload,boolean accepted);
    }

    private final FrameLayout dragLayer;
    private final ClassicWorkspace workspace;
    private final Listener listener;
    private ImageView dragView;
    private View sourceView;
    private ClassicWorkspace.DragPayload payload;
    private float touchOffsetX,touchOffsetY,originX,originY;
    private boolean finishing;

    L3ItemDragController(FrameLayout dragLayer,ClassicWorkspace workspace,Listener listener){
        this.dragLayer=dragLayer;this.workspace=workspace;this.listener=listener;
    }

    boolean isDragging(){return payload!=null&&!finishing;}

    boolean startExisting(View source,ClassicLayoutStore.Item item,float rawX,float rawY){
        if(source==null||item==null||ClassicLayoutStore.TYPE_WIDGET.equals(item.type)||isDragging())return false;
        return start(source,ClassicWorkspace.DragPayload.existing(item.id,item.page,source),rawX,rawY);
    }

    boolean startExternalApp(View source,String pkg,String cls,String folderId,int hotseatIndex,float rawX,float rawY){
        if(source==null||pkg==null||cls==null||isDragging())return false;
        return start(source,ClassicWorkspace.DragPayload.app(source,pkg,cls,folderId,hotseatIndex),rawX,rawY);
    }

    private boolean start(View source,ClassicWorkspace.DragPayload p,float rawX,float rawY){
        sourceView=source;payload=p;finishing=false;
        if(!createDragView(source,rawX,rawY)){reset(false);return false;}
        workspace.startInternalItemDrag(payload);
        source.animate().cancel();source.setAlpha(.14f);source.setPressed(false);
        return true;
    }

    private boolean createDragView(View source,float rawX,float rawY){
        int w=Math.max(1,source.getWidth()),h=Math.max(1,source.getHeight());
        try{
            Bitmap bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bitmap);source.draw(c);
            dragView=new ImageView(source.getContext());dragView.setImageBitmap(bitmap);dragView.setScaleType(ImageView.ScaleType.FIT_XY);
            dragView.setAlpha(.98f);dragView.setElevation(dp(18));
            int[] sourceLoc=new int[2],rootLoc=new int[2];source.getLocationOnScreen(sourceLoc);dragLayer.getLocationOnScreen(rootLoc);
            originX=sourceLoc[0]-rootLoc[0];originY=sourceLoc[1]-rootLoc[1];
            if(rawX<=0&&rawY<=0){rawX=sourceLoc[0]+w/2f;rawY=sourceLoc[1]+h/2f;}
            touchOffsetX=Math.max(0,Math.min(w,rawX-sourceLoc[0]));touchOffsetY=Math.max(0,Math.min(h,rawY-sourceLoc[1]));
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(w,h);dragLayer.addView(dragView,lp);dragView.setX(originX);dragView.setY(originY);dragView.bringToFront();
            dragView.setScaleX(1f);dragView.setScaleY(1f);dragView.animate().scaleX(1.08f).scaleY(1.08f).setDuration(90).start();
            move(rawX,rawY);return true;
        }catch(Throwable t){return false;}
    }

    boolean onMotionEvent(MotionEvent ev){
        if(!isDragging()||ev==null)return false;
        switch(ev.getActionMasked()){
            case MotionEvent.ACTION_MOVE:move(ev.getRawX(),ev.getRawY());return true;
            case MotionEvent.ACTION_UP:move(ev.getRawX(),ev.getRawY());drop(ev.getRawX(),ev.getRawY());return true;
            case MotionEvent.ACTION_CANCEL:cancel();return true;
            default:return true;
        }
    }

    private void move(float rawX,float rawY){
        if(dragView==null||payload==null)return;dragView.bringToFront();
        int[] rootLoc=new int[2];dragLayer.getLocationOnScreen(rootLoc);dragView.setX(rawX-rootLoc[0]-touchOffsetX);dragView.setY(rawY-rootLoc[1]-touchOffsetY);
        if(listener!=null)listener.onItemDragMove(payload,rawX,rawY);
        int[] wsLoc=new int[2];workspace.getLocationOnScreen(wsLoc);workspace.previewItemL3(payload,rawX-wsLoc[0],rawY-wsLoc[1]);
    }

    private void drop(float rawX,float rawY){
        if(finishing||payload==null)return;finishing=true;boolean accepted=false;
        if(listener!=null)accepted=listener.onItemDropTarget(payload,rawX,rawY);
        if(!accepted){int[] wsLoc=new int[2];workspace.getLocationOnScreen(wsLoc);accepted=workspace.dropItemL3(payload,rawX-wsLoc[0],rawY-wsLoc[1]);}
        final boolean ok=accepted;final ClassicWorkspace.DragPayload done=payload;
        workspace.finishInternalItemDrag(done,ok);
        if(ok)animateIntoDestination(done,()->resetAndNotify(done,true));
        else animateBack(()->resetAndNotify(done,false));
    }

    void cancel(){
        if(!isDragging())return;finishing=true;final ClassicWorkspace.DragPayload done=payload;workspace.finishInternalItemDrag(done,false);
        animateBack(()->resetAndNotify(done,false));
    }

    private void animateIntoDestination(ClassicWorkspace.DragPayload p,Runnable end){
        if(dragView==null){end.run();return;}
        View target=p!=null&&p.itemId!=null?workspace.findItemView(p.itemId):null;
        if(target!=null){
            int[] tl=new int[2],rl=new int[2];target.getLocationOnScreen(tl);dragLayer.getLocationOnScreen(rl);
            float sx=target.getWidth()>0?target.getWidth()/(float)Math.max(1,dragView.getWidth()):1f;
            float sy=target.getHeight()>0?target.getHeight()/(float)Math.max(1,dragView.getHeight()):1f;
            dragView.animate().x(tl[0]-rl[0]).y(tl[1]-rl[1]).scaleX(sx).scaleY(sy).alpha(.35f).setDuration(150).withEndAction(end).start();
        }else dragView.animate().alpha(0f).scaleX(.9f).scaleY(.9f).setDuration(130).withEndAction(end).start();
    }

    private void animateBack(Runnable end){
        if(dragView==null){end.run();return;}
        dragView.animate().x(originX).y(originY).scaleX(1f).scaleY(1f).alpha(.45f).setDuration(180).withEndAction(end).start();
    }

    private void resetAndNotify(ClassicWorkspace.DragPayload done,boolean accepted){
        View old=sourceView;reset(true);if(old!=null){old.animate().cancel();old.setAlpha(1f);old.setScaleX(1f);old.setScaleY(1f);}
        if(listener!=null)listener.onItemDragFinished(done,accepted);
    }

    private void reset(boolean remove){
        if(remove&&dragView!=null&&dragView.getParent()==dragLayer)dragLayer.removeView(dragView);
        if(sourceView!=null)sourceView.setAlpha(1f);dragView=null;sourceView=null;payload=null;finishing=false;
    }

    private int dp(float v){return Math.round(v*dragLayer.getResources().getDisplayMetrics().density);}
}
