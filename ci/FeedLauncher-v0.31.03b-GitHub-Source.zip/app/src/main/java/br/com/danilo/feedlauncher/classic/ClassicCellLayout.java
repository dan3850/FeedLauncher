package br.com.danilo.feedlauncher.classic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;

import java.util.Map;

/**
 * Minimal CellLayout-style grid. Layout data lives in cell coordinates and spans,
 * like Launcher3, instead of absolute pixels.
 */
public final class ClassicCellLayout extends ViewGroup {
    public static final class LayoutParams extends ViewGroup.LayoutParams {
        public int cellX, cellY, spanX, spanY;
        public String itemId;
        public LayoutParams(int cellX,int cellY,int spanX,int spanY,String itemId){
            super(MATCH_PARENT,MATCH_PARENT);
            this.cellX=cellX;this.cellY=cellY;this.spanX=Math.max(1,spanX);this.spanY=Math.max(1,spanY);this.itemId=itemId;
        }
    }

    private final int cols;
    private final int rows;
    private final int gapPx;
    private int cellW=1, cellH=1;
    private int hoverX=-1,hoverY=-1,hoverSpanX=1,hoverSpanY=1;
    private boolean hoverValid=false;
    private final Paint hoverPaint=new Paint(Paint.ANTI_ALIAS_FLAG);

    public ClassicCellLayout(Context context,int cols,int rows){
        super(context);this.cols=cols;this.rows=rows;this.gapPx=dp(6);
        setWillNotDraw(false);setClipChildren(false);setClipToPadding(false);
    }

    public int columns(){return cols;}
    public int rows(){return rows;}
    public int cellWidth(){return Math.max(1,cellW);}
    public int cellHeight(){return Math.max(1,cellH);}

    @Override protected boolean checkLayoutParams(ViewGroup.LayoutParams p){return p instanceof LayoutParams;}
    @Override protected ViewGroup.LayoutParams generateDefaultLayoutParams(){return new LayoutParams(0,0,1,1,"");}

    @Override protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){
        int w=MeasureSpec.getSize(widthMeasureSpec),h=MeasureSpec.getSize(heightMeasureSpec);
        cellW=Math.max(1,w/Math.max(1,cols));cellH=Math.max(1,h/Math.max(1,rows));
        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);LayoutParams lp=(LayoutParams)child.getLayoutParams();
            int cw=Math.max(1,cellW*lp.spanX-gapPx*2);int ch=Math.max(1,cellH*lp.spanY-gapPx*2);
            child.measure(MeasureSpec.makeMeasureSpec(cw,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(ch,MeasureSpec.EXACTLY));
        }
        setMeasuredDimension(w,h);
    }

    @Override protected void onLayout(boolean changed,int l,int t,int r,int b){
        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);LayoutParams lp=(LayoutParams)child.getLayoutParams();
            int left=lp.cellX*cellW+gapPx,top=lp.cellY*cellH+gapPx;
            child.layout(left,top,left+child.getMeasuredWidth(),top+child.getMeasuredHeight());
        }
    }

    public int[] cellFromPoint(float x,float y){
        int cx=Math.max(0,Math.min(cols-1,(int)(x/Math.max(1,cellW))));
        int cy=Math.max(0,Math.min(rows-1,(int)(y/Math.max(1,cellH))));
        return new int[]{cx,cy};
    }

    public boolean regionFree(int x,int y,int sx,int sy,String ignoreId){
        if(x<0||y<0||sx<1||sy<1||x+sx>cols||y+sy>rows)return false;
        for(int i=0;i<getChildCount();i++){
            LayoutParams lp=(LayoutParams)getChildAt(i).getLayoutParams();
            if(ignoreId!=null&&ignoreId.equals(lp.itemId))continue;
            if(overlaps(x,y,sx,sy,lp.cellX,lp.cellY,lp.spanX,lp.spanY))return false;
        }
        return true;
    }

    public String itemAtCell(int x,int y,String ignoreId){
        for(int i=0;i<getChildCount();i++){
            LayoutParams lp=(LayoutParams)getChildAt(i).getLayoutParams();
            if(ignoreId!=null&&ignoreId.equals(lp.itemId))continue;
            if(x>=lp.cellX&&x<lp.cellX+lp.spanX&&y>=lp.cellY&&y<lp.cellY+lp.spanY)return lp.itemId;
        }
        return null;
    }

    /** True hit test used to keep empty-space long press separate from item long press/drag. */
    public String itemAtPoint(float x,float y){
        for(int i=getChildCount()-1;i>=0;i--){
            View child=getChildAt(i);
            if(child.getVisibility()!=VISIBLE)continue;
            float left=child.getLeft()+child.getTranslationX();
            float top=child.getTop()+child.getTranslationY();
            if(x>=left&&x<left+child.getWidth()&&y>=top&&y<top+child.getHeight()){
                LayoutParams lp=(LayoutParams)child.getLayoutParams();
                return lp.itemId;
            }
        }
        return null;
    }

    public int[] nearestFree(int desiredX,int desiredY,int sx,int sy,String ignoreId){
        int bestD=Integer.MAX_VALUE,bestX=-1,bestY=-1;
        for(int y=0;y<=rows-sy;y++)for(int x=0;x<=cols-sx;x++){
            if(!regionFree(x,y,sx,sy,ignoreId))continue;
            int d=Math.abs(x-desiredX)+Math.abs(y-desiredY);
            if(d<bestD){bestD=d;bestX=x;bestY=y;}
        }
        return bestX<0?null:new int[]{bestX,bestY};
    }

    public void showDropPreview(int x,int y,int sx,int sy,boolean valid){
        hoverX=x;hoverY=y;hoverSpanX=Math.max(1,sx);hoverSpanY=Math.max(1,sy);hoverValid=valid;invalidate();
    }
    public void clearDropPreview(){hoverX=hoverY=-1;clearReorderPreview();invalidate();}

    /** Visually previews the make-room plan without mutating persisted cell coordinates. */
    public void showReorderPreview(Map<String,int[]> positions){
        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);LayoutParams lp=(LayoutParams)child.getLayoutParams();
            int[] target=positions==null?null:positions.get(lp.itemId);
            float tx=target==null?0f:(target[0]-lp.cellX)*cellW;
            float ty=target==null?0f:(target[1]-lp.cellY)*cellH;
            child.animate().cancel();child.animate().translationX(tx).translationY(ty).setDuration(125).start();
        }
    }

    public void clearReorderPreview(){
        for(int i=0;i<getChildCount();i++){
            View child=getChildAt(i);child.animate().cancel();
            if(child.getTranslationX()!=0f||child.getTranslationY()!=0f)child.animate().translationX(0f).translationY(0f).setDuration(100).start();
        }
    }

    @Override protected void dispatchDraw(Canvas canvas){
        if(hoverX>=0&&hoverY>=0){
            float left=hoverX*cellW+gapPx,top=hoverY*cellH+gapPx;
            float right=Math.min(getWidth(),(hoverX+hoverSpanX)*cellW-gapPx),bottom=Math.min(getHeight(),(hoverY+hoverSpanY)*cellH-gapPx);
            hoverPaint.setStyle(Paint.Style.FILL);hoverPaint.setColor(hoverValid?0x334da3ff:0x44ff5252);
            canvas.drawRoundRect(new RectF(left,top,right,bottom),dp(14),dp(14),hoverPaint);
            hoverPaint.setStyle(Paint.Style.STROKE);hoverPaint.setStrokeWidth(dp(2));hoverPaint.setColor(hoverValid?0xaa8fc7ff:0xaaff7777);
            canvas.drawRoundRect(new RectF(left,top,right,bottom),dp(14),dp(14),hoverPaint);
        }
        super.dispatchDraw(canvas);
    }

    private static boolean overlaps(int ax,int ay,int aw,int ah,int bx,int by,int bw,int bh){
        return ax<bx+bw&&ax+aw>bx&&ay<by+bh&&ay+ah>by;
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
