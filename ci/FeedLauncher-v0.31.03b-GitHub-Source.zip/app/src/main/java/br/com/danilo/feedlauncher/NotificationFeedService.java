package br.com.danilo.feedlauncher;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.SharedPreferences;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ConcurrentHashMap;

public class NotificationFeedService extends NotificationListenerService {
    private static final ConcurrentHashMap<String, PendingIntent> actions = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String,String> labelCache = new ConcurrentHashMap<>();
    private SharedPreferences cachedPrefs;
    private SharedPreferences prefs(){
        if(cachedPrefs==null)cachedPrefs=getSharedPreferences("feed", MODE_PRIVATE);
        return cachedPrefs;
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn){
        if(sbn==null || getPackageName().equals(sbn.getPackageName())) return;
        if(prefs().getStringSet("notificationMutedPackages",java.util.Collections.emptySet()).contains(sbn.getPackageName())) return;
        Notification n=sbn.getNotification();
        if(n!=null && n.contentIntent!=null) actions.put(sbn.getKey(),n.contentIntent);
        save(sbn,false);
    }
    @Override public void onNotificationRemoved(StatusBarNotification sbn){ if(sbn!=null){ actions.remove(sbn.getKey()); save(sbn,true); } }

    private void save(StatusBarNotification sbn, boolean removed){
        try{
            JSONArray old=new JSONArray(prefs().getString("notificationFeedJson","[]"));
            JSONArray out=new JSONArray();
            if(!removed){
                Notification n=sbn.getNotification();
                CharSequence t=n==null?null:n.extras.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence x=n==null?null:n.extras.getCharSequence(Notification.EXTRA_TEXT);
                JSONObject o=new JSONObject();o.put("key",sbn.getKey());o.put("pkg",sbn.getPackageName());o.put("title",t==null?appLabel(sbn.getPackageName()):String.valueOf(t));o.put("text",x==null?"":String.valueOf(x));o.put("time",System.currentTimeMillis());out.put(o);
            }
            for(int i=0;i<old.length() && out.length()<30;i++){
                JSONObject o=old.optJSONObject(i);if(o==null||sbn.getKey().equals(o.optString("key")))continue;out.put(o);
            }
            prefs().edit().putString("notificationFeedJson",out.toString()).apply();
        }catch(Exception ignored){}
    }
    private String appLabel(String pkg){
        String cached=labelCache.get(pkg);if(cached!=null)return cached;
        String value=pkg;
        try{value=String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)));}catch(Exception ignored){}
        labelCache.put(pkg,value);return value;
    }
    public static boolean openNotification(String key){PendingIntent p=actions.get(key);if(p==null)return false;try{p.send();return true;}catch(Exception e){return false;}}
}
