/*
 * Copyright (C) 2026 FeedLauncher contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Launcher3-style in-process widget drag controller. The behavior and lifecycle are adapted
 * from AOSP Launcher3 DragController/DragView/Workspace: the drag stays inside the launcher,
 * follows the pointer in a DragLayer-style overlay, previews CellLayout reordering continuously,
 * and commits/cancels atomically on pointer release.
 */
package br.com.danilo.feedlauncher.classic;

import android.content.ComponentName;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

final class L3WidgetDragController {
    interface Listener {
        void onWidgetDragFinished(String existingItemId, boolean accepted);
    }

    private static final int MODE_NONE=0;
    private static final int MODE_EXISTING=1;
    private static final int MODE_PROVIDER=2;

    private final FrameLayout dragLayer;
    private final ClassicWorkspace workspace;
    private final Listener listener;

    private int mode=MODE_NONE;
    private ImageView dragView;
    private View sourceView;
    private String existingItemId;
    private ComponentName provider;
    private int spanX=1,spanY=1,minSpanX=1,minSpanY=1;
    private float touchOffsetX,touchOffsetY;
    private float originX,originY;
    private int originW,originH;
    private boolean finishing;

    L3WidgetDragController(FrameLayout dragLayer, ClassicWorkspace workspace, Listener listener){
        this.dragLayer=dragLayer;this.workspace=workspace;this.listener=listener;
    }

    boolean isDragging(){return mode!=MODE_NONE&&!finishing;}

    boolean startExisting(View source, ClassicLayoutStore.Item item, int minX, int minY, float rawX, float rawY){
        if(source==null||item==null||dragLayer==null||workspace==null||isDragging())return false;
        mode=MODE_EXISTING;sourceView=source;existingItemId=item.id;provider=null;
        spanX=Math.max(1,item.spanX);spanY=Math.max(1,item.spanY);
        minSpanX=Math.max(1,Math.min(spanX,minX));minSpanY=Math.max(1,Math.min(spanY,minY));
        if(!createDragView(source,rawX,rawY)){reset(false);return false;}
        workspace.startInternalWidgetDrag(item.id);
        source.animate().cancel();source.setAlpha(.18f);
        return true;
    }

    boolean startProvider(View source, ComponentName provider, int spanX, int spanY,
            int minSpanX, int minSpanY, float rawX, float rawY){
        if(source==null||provider==null||dragLayer==null||workspace==null||isDragging())return false;
        mode=MODE_PROVIDER;sourceView=source;existingItemId=null;this.provider=provider;
        this.spanX=Math.max(1,spanX);this.spanY=Math.max(1,spanY);
        this.minSpanX=Math.max(1,Math.min(this.spanX,minSpanX));this.minSpanY=Math.max(1,Math.min(this.spanY,minSpanY));
        if(!createDragView(source,rawX,rawY)){reset(false);return false;}
        workspace.startInternalPendingWidgetDrag();
        source.animate().cancel();source.setAlpha(.35f);
        return true;
    }

    private boolean createDragView(View source,float rawX,float rawY){
        int w=Math.max(1,source.getWidth()),h=Math.max(1,source.getHeight());
        try{
            Bitmap bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
            Canvas c=new Canvas(bitmap);source.draw(c);
            dragView=new ImageView(source.getContext());dragView.setImageBitmap(bitmap);dragView.setScaleType(ImageView.ScaleType.FIT_XY);
            dragView.setAlpha(.96f);dragView.setScaleX(1.04f);dragView.setScaleY(1.04f);dragView.setElevation(dp(18));
            int[] sourceLoc=new int[2],rootLoc=new int[2];source.getLocationOnScreen(sourceLoc);dragLayer.getLocationOnScreen(rootLoc);
            originX=sourceLoc[0]-rootLoc[0];originY=sourceLoc[1]-rootLoc[1];originW=w;originH=h;
            if(rawX<=0&&rawY<=0){rawX=sourceLoc[0]+w/2f;rawY=sourceLoc[1]+h/2f;}
            touchOffsetX=Math.max(0,Math.min(w,rawX-sourceLoc[0]));touchOffsetY=Math.max(0,Math.min(h,rawY-sourceLoc[1]));
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(w,h);dragLayer.addView(dragView,lp);dragView.setX(originX);dragView.setY(originY);dragView.bringToFront();
            dragView.animate().scaleX(1.08f).scaleY(1.08f).setDuration(90).start();
            move(rawX,rawY);return true;
        }catch(Throwable t){return false;}
    }

    boolean onMotionEvent(MotionEvent ev){
        if(!isDragging())return false;
        int action=ev.getActionMasked();
        if(action==MotionEvent.ACTION_MOVE){move(ev.getRawX(),ev.getRawY());return true;}
        if(action==MotionEvent.ACTION_UP){move(ev.getRawX(),ev.getRawY());drop(ev.getRawX(),ev.getRawY());return true;}
        if(action==MotionEvent.ACTION_CANCEL){cancel();return true;}
        return true;
    }

    private void move(float rawX,float rawY){
        if(dragView==null)return;dragView.bringToFront();
        int[] rootLoc=new int[2];dragLayer.getLocationOnScreen(rootLoc);
        dragView.setX(rawX-rootLoc[0]-touchOffsetX);dragView.setY(rawY-rootLoc[1]-touchOffsetY);
        int[] wsLoc=new int[2];workspace.getLocationOnScreen(wsLoc);
        float x=rawX-wsLoc[0],y=rawY-wsLoc[1];
        if(mode==MODE_EXISTING)workspace.previewExistingWidgetL3(existingItemId,x,y,minSpanX,minSpanY);
        else if(mode==MODE_PROVIDER)workspace.previewPendingWidgetL3(x,y,spanX,spanY,minSpanX,minSpanY);
    }

    private void drop(float rawX,float rawY){
        if(finishing)return;finishing=true;
        int[] wsLoc=new int[2];workspace.getLocationOnScreen(wsLoc);
        float x=rawX-wsLoc[0],y=rawY-wsLoc[1];boolean accepted=false;
        if(mode==MODE_EXISTING)accepted=workspace.dropExistingWidgetL3(existingItemId,x,y,minSpanX,minSpanY);
        else if(mode==MODE_PROVIDER)accepted=workspace.dropPendingWidgetL3(provider,x,y,spanX,spanY,minSpanX,minSpanY);
        final boolean ok=accepted;final String id=existingItemId;
        if(ok)animateIntoWorkspace(id,()->resetAndNotify(id,true));
        else animateBack(()->{workspace.cancelInternalWidgetDrag();resetAndNotify(id,false);});
    }

    void cancel(){
        if(!isDragging())return;finishing=true;final String id=existingItemId;
        animateBack(()->{workspace.cancelInternalWidgetDrag();resetAndNotify(id,false);});
    }

    private void animateIntoWorkspace(String itemId,Runnable end){
        if(dragView==null){end.run();return;}
        View target=itemId==null?null:workspace.findItemView(itemId);
        if(target!=null){
            int[] targetLoc=new int[2],rootLoc=new int[2];target.getLocationOnScreen(targetLoc);dragLayer.getLocationOnScreen(rootLoc);
            float tx=targetLoc[0]-rootLoc[0],ty=targetLoc[1]-rootLoc[1];
            float sx=target.getWidth()>0?target.getWidth()/(float)Math.max(1,dragView.getWidth()):1f;
            float sy=target.getHeight()>0?target.getHeight()/(float)Math.max(1,dragView.getHeight()):1f;
            dragView.animate().x(tx).y(ty).scaleX(sx).scaleY(sy).alpha(.35f).setDuration(150).withEndAction(end).start();
        }else dragView.animate().alpha(0f).scaleX(.92f).scaleY(.92f).setDuration(130).withEndAction(end).start();
    }

    private void animateBack(Runnable end){
        if(dragView==null){end.run();return;}
        dragView.animate().x(originX).y(originY).scaleX(1f).scaleY(1f).alpha(.45f).setDuration(180).withEndAction(end).start();
    }

    private void resetAndNotify(String itemId,boolean accepted){
        View oldSource=sourceView;reset(true);if(oldSource!=null)oldSource.animate().cancel();if(oldSource!=null)oldSource.setAlpha(1f);
        if(listener!=null)listener.onWidgetDragFinished(itemId,accepted);
    }

    private void reset(boolean removeView){
        if(removeView&&dragView!=null&&dragView.getParent()==dragLayer)dragLayer.removeView(dragView);
        if(sourceView!=null)sourceView.setAlpha(1f);
        dragView=null;sourceView=null;existingItemId=null;provider=null;mode=MODE_NONE;finishing=false;
        spanX=spanY=minSpanX=minSpanY=1;
    }

    private int dp(float v){return Math.round(v*dragLayer.getResources().getDisplayMetrics().density);}
}
