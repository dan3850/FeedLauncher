package br.com.danilo.feedlauncher;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * v0.30.42 — diagnóstico passivo do ciclo de vida da Home.
 *
 * Separa recriações reais da Activity de simples reconstruções da árvore da Home.
 * Não altera comportamento nem mantém referências a Views/Activity.
 */
final class HomeLifecycleDiagnostics {
    private static final AtomicInteger NEXT_INSTANCE = new AtomicInteger(0);
    private static final AtomicInteger PROCESS_CREATE_COUNT = new AtomicInteger(0);
    private static final AtomicInteger PROCESS_CREATE_WITH_STATE_COUNT = new AtomicInteger(0);
    private static final AtomicInteger DUPLICATE_SUPPRESSED_COUNT = new AtomicInteger(0);
    private static final ArrayDeque<String> PROCESS_EVENTS = new ArrayDeque<>();
    private static volatile String LAST_DESTROY_REASON = "Nenhum";
    private static final int MAX_EVENTS = 10;

    private final int instanceId;
    private final boolean createdWithSavedState;
    private final long createdAt = System.currentTimeMillis();

    private long metricsStartedAt = System.currentTimeMillis();
    private long buildCount = 0L;
    private long buildTotalMs = 0L;
    private long buildMaxMs = 0L;
    private long buildLastMs = 0L;
    private String lastBuildReason = "Nenhuma";
    private String lastDestroyReason = "Nenhum";

    HomeLifecycleDiagnostics(boolean savedInstanceStatePresent) {
        instanceId = NEXT_INSTANCE.incrementAndGet();
        createdWithSavedState = savedInstanceStatePresent;
        PROCESS_CREATE_COUNT.incrementAndGet();
        if (savedInstanceStatePresent) PROCESS_CREATE_WITH_STATE_COUNT.incrementAndGet();
        appendProcessEvent("Activity #" + instanceId + " criada · " + (savedInstanceStatePresent ? "com estado" : "nova"));
    }

    int instanceId() { return instanceId; }
    boolean createdWithSavedState() { return createdWithSavedState; }
    long buildCount() { return buildCount; }

    void recordDuplicateSuppressed(int keptInstanceId) {
        DUPLICATE_SUPPRESSED_COUNT.incrementAndGet();
        appendProcessEvent("Activity #" + instanceId + " duplicada bloqueada · mantendo #" + (keptInstanceId <= 0 ? "?" : keptInstanceId));
    }

    void recordBuild(String reason, long tookMs) {
        buildCount++;
        buildLastMs = Math.max(0L, tookMs);
        buildTotalMs += buildLastMs;
        buildMaxMs = Math.max(buildMaxMs, buildLastMs);
        lastBuildReason = clean(reason);
        appendProcessEvent("Home #" + instanceId + " build " + buildCount + " · " + lastBuildReason + " · " + buildLastMs + " ms");
    }

    void recordDestroy(boolean changingConfigurations, boolean finishing) {
        if (changingConfigurations) lastDestroyReason = "mudança de configuração";
        else if (finishing) lastDestroyReason = "Activity finalizada";
        else lastDestroyReason = "Android/processo";
        LAST_DESTROY_REASON = lastDestroyReason;
        appendProcessEvent("Activity #" + instanceId + " destroy · " + lastDestroyReason);
    }

    void resetMetrics() {
        // O número de builds é uma invariante de ciclo de vida e não é apagado
        // ao zerar métricas operacionais. Assim o diagnóstico continua provando
        // "1 Home build por sessão" mesmo após o usuário limpar os contadores.
        metricsStartedAt = System.currentTimeMillis();
    }

    String report() {
        long avg = buildCount <= 0L ? 0L : buildTotalMs / buildCount;
        StringBuilder out = new StringBuilder();
        out.append("Home lifecycle: Activity #").append(instanceId)
                .append(" · criada ").append(createdWithSavedState ? "com estado" : "sem estado")
                .append(" · idade ").append(formatDuration(System.currentTimeMillis() - createdAt)).append('\n');
        int created = PROCESS_CREATE_COUNT.get();
        int blocked = DUPLICATE_SUPPRESSED_COUNT.get();
        out.append("Activities neste processo: ").append(created)
                .append(" · efetivas: ").append(Math.max(0, created - blocked))
                .append(" · com estado: ").append(PROCESS_CREATE_WITH_STATE_COUNT.get())
                .append(" · duplicadas bloqueadas: ").append(blocked).append('\n');
        out.append("Construções da Home: ").append(buildCount)
                .append(" · última ").append(buildLastMs).append(" ms")
                .append(" · média ").append(avg).append(" ms")
                .append(" · pico ").append(buildMaxMs).append(" ms").append('\n');
        out.append("Última construção: ").append(lastBuildReason).append('\n');
        String destroy = !"Nenhum".equals(lastDestroyReason) ? lastDestroyReason : LAST_DESTROY_REASON;
        if (!"Nenhum".equals(destroy)) out.append("Último destroy: ").append(destroy).append('\n');
        ArrayList<String> events = processEventsSnapshot();
        if (!events.isEmpty()) {
            out.append("Histórico Home:");
            int start = Math.max(0, events.size() - 5);
            for (int i = start; i < events.size(); i++) out.append("\n• ").append(events.get(i));
        }
        return out.toString();
    }

    private static synchronized void appendProcessEvent(String detail) {
        PROCESS_EVENTS.addLast(formatClock(System.currentTimeMillis()) + " · " + clean(detail));
        while (PROCESS_EVENTS.size() > MAX_EVENTS) PROCESS_EVENTS.removeFirst();
    }

    private static synchronized ArrayList<String> processEventsSnapshot() {
        return new ArrayList<>(PROCESS_EVENTS);
    }

    private static String clean(String value) {
        if (value == null || value.trim().isEmpty()) return "—";
        String out = value.replace('\n', ' ').replace('\r', ' ').trim();
        return out.length() > 140 ? out.substring(0, 140) + "…" : out;
    }

    private static String formatClock(long when) {
        try { return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(when)); }
        catch (Throwable ignored) { return String.valueOf(when); }
    }

    private static String formatDuration(long millis) {
        long seconds = Math.max(0L, millis / 1000L);
        long minutes = seconds / 60L;
        long secs = seconds % 60L;
        if (minutes > 0L) return minutes + "min " + secs + "s";
        return secs + "s";
    }
}
