package br.com.danilo.feedlauncher;

import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;

/**
 * v0.30.52 — fonte única das superfícies visuais compartilhadas entre a Home
 * e experiências secundárias (ex.: Notícias). O MainActivity publica as cores
 * finais já calculadas pelo motor de tema; outros componentes apenas consomem
 * essa mesma receita. Assim Stock/Glass/Blur/gradiente/bordas não divergem.
 */
final class UnifiedThemeRuntime {
    private UnifiedThemeRuntime() {}
    static final String P = "runtimeUnifiedTheme.";

    static final class Style {
        boolean light, gradientEnabled, gradientThird, effectSubcards, effectButtons;
        int bg, fg, subtle, accent, primary, sub, tertiary, button, selected, border, dialog;
        int baseColor, gradientColor2, gradientColor3, gradientAngle, gradientStrength, harmonyStrength, depth;
        int glassIntensity, blurIntensity, borderStrength, cornerRadius, cardAlpha, homeCardAlpha;
        String colorStyle = "solid", effectMode = "off", signature = "";
    }

    static int dp(Context c,float n){return (int)(n*c.getResources().getDisplayMetrics().density+.5f);}
    static int blend(int a,int b,float f){
        return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f));
    }
    static String signature(Style s){
        if(s==null)return "";
        return (s.light?1:0)+"|"+s.bg+"|"+s.fg+"|"+s.subtle+"|"+s.accent+"|"+s.primary+"|"+s.sub+"|"+s.tertiary+"|"+s.button+"|"+s.selected+"|"+s.border+"|"+s.dialog+"|"+
                s.baseColor+"|"+s.gradientColor2+"|"+s.gradientColor3+"|"+s.gradientAngle+"|"+s.gradientStrength+"|"+s.harmonyStrength+"|"+s.depth+"|"+s.gradientEnabled+"|"+s.gradientThird+"|"+
                s.colorStyle+"|"+s.effectMode+"|"+s.glassIntensity+"|"+s.blurIntensity+"|"+s.borderStrength+"|"+s.cornerRadius+"|"+s.cardAlpha+"|"+s.homeCardAlpha+"|"+s.effectSubcards+"|"+s.effectButtons;
    }

    static void publish(SharedPreferences p,Style s){
        if(p==null||s==null)return;
        String sig=signature(s);
        if(sig.equals(p.getString(P+"signature","")))return;
        p.edit()
                .putString(P+"signature",sig).putBoolean(P+"light",s.light)
                .putInt(P+"bg",s.bg).putInt(P+"fg",s.fg).putInt(P+"subtle",s.subtle).putInt(P+"accent",s.accent)
                .putInt(P+"primary",s.primary).putInt(P+"sub",s.sub).putInt(P+"tertiary",s.tertiary)
                .putInt(P+"button",s.button).putInt(P+"selected",s.selected).putInt(P+"border",s.border).putInt(P+"dialog",s.dialog)
                .putInt(P+"base",s.baseColor).putInt(P+"g2",s.gradientColor2).putInt(P+"g3",s.gradientColor3)
                .putInt(P+"angle",s.gradientAngle).putInt(P+"gradientStrength",s.gradientStrength).putInt(P+"harmony",s.harmonyStrength).putInt(P+"depth",s.depth)
                .putBoolean(P+"gradient",s.gradientEnabled).putBoolean(P+"gradientThird",s.gradientThird)
                .putString(P+"colorStyle",s.colorStyle).putString(P+"effect",s.effectMode)
                .putInt(P+"glass",s.glassIntensity).putInt(P+"blur",s.blurIntensity).putInt(P+"borderStrength",s.borderStrength)
                .putInt(P+"corner",s.cornerRadius).putInt(P+"alpha",s.cardAlpha).putInt(P+"homeAlpha",s.homeCardAlpha)
                .putBoolean(P+"effectSubcards",s.effectSubcards).putBoolean(P+"effectButtons",s.effectButtons)
                .apply();
    }

    static Style load(SharedPreferences p){
        if(p==null||!p.contains(P+"signature"))return null;
        Style s=new Style();
        s.signature=p.getString(P+"signature","");s.light=p.getBoolean(P+"light",false);
        s.bg=p.getInt(P+"bg",0xff020f1d);s.fg=p.getInt(P+"fg",Color.WHITE);s.subtle=p.getInt(P+"subtle",0xff9db5d5);s.accent=p.getInt(P+"accent",0xff187cff);
        s.primary=p.getInt(P+"primary",s.bg);s.sub=p.getInt(P+"sub",s.primary);s.tertiary=p.getInt(P+"tertiary",s.sub);s.button=p.getInt(P+"button",s.sub);s.selected=p.getInt(P+"selected",s.accent);s.border=p.getInt(P+"border",s.accent);s.dialog=p.getInt(P+"dialog",s.primary);
        s.baseColor=p.getInt(P+"base",s.accent);s.gradientColor2=p.getInt(P+"g2",s.baseColor);s.gradientColor3=p.getInt(P+"g3",s.gradientColor2);s.gradientAngle=p.getInt(P+"angle",135);
        s.gradientStrength=p.getInt(P+"gradientStrength",80);s.harmonyStrength=p.getInt(P+"harmony",72);s.depth=p.getInt(P+"depth",68);s.gradientEnabled=p.getBoolean(P+"gradient",false);s.gradientThird=p.getBoolean(P+"gradientThird",false);
        s.colorStyle=p.getString(P+"colorStyle","solid");s.effectMode=p.getString(P+"effect","off");s.glassIntensity=p.getInt(P+"glass",65);s.blurIntensity=p.getInt(P+"blur",62);s.borderStrength=p.getInt(P+"borderStrength",55);
        s.cornerRadius=p.getInt(P+"corner",14);s.cardAlpha=p.getInt(P+"alpha",238);s.homeCardAlpha=p.getInt(P+"homeAlpha",s.cardAlpha);s.effectSubcards=p.getBoolean(P+"effectSubcards",true);s.effectButtons=p.getBoolean(P+"effectButtons",true);
        return s;
    }

    static GradientDrawable.Orientation orientation(int angle){
        int a=((angle%360)+360)%360;
        if(a<23||a>=338)return GradientDrawable.Orientation.LEFT_RIGHT;if(a<68)return GradientDrawable.Orientation.TL_BR;if(a<113)return GradientDrawable.Orientation.TOP_BOTTOM;if(a<158)return GradientDrawable.Orientation.TR_BL;if(a<203)return GradientDrawable.Orientation.RIGHT_LEFT;if(a<248)return GradientDrawable.Orientation.BR_TL;if(a<293)return GradientDrawable.Orientation.BOTTOM_TOP;return GradientDrawable.Orientation.BL_TR;
    }
    static int harmonicGradientStop(Style s,int seed,int surfaceColor,float valueShift){
        float[] sh=new float[3],bh=new float[3];Color.colorToHSV(seed,sh);Color.colorToHSV(surfaceColor,bh);
        float presence=.32f+.68f*(s.gradientStrength/100f);presence*=.82f+.18f*(s.harmonyStrength/100f);
        float minSat=("pastel".equals(s.colorStyle)||"muted".equals(s.colorStyle)||"mono".equals(s.colorStyle))?.06f:.18f;
        float targetSat=Math.max(minSat,sh[1]);if(s.light)targetSat*=.72f;
        float sat=Math.max(.02f,Math.min(1f,bh[1]*(1f-presence)+targetSat*presence));
        float depth=.55f+.45f*(s.depth/100f);float value=Math.max(.025f,Math.min(1f,bh[2]+valueShift*depth));
        return Color.HSVToColor(new float[]{sh[0],sat,value});
    }
    static int[] harmonicGradientStops(Style s,int surface){
        if(!s.gradientEnabled)return new int[]{surface};
        int a=harmonicGradientStop(s,s.baseColor,surface,.010f),b=harmonicGradientStop(s,s.gradientColor2,surface,-.012f);
        if(s.gradientThird){int c=harmonicGradientStop(s,s.gradientColor3,surface,.004f);return new int[]{a,c,b};}
        return new int[]{a,b};
    }
    static int frostedSurfaceColor(Style s,int color){
        float[] h=new float[3];Color.colorToHSV(color,h);h[1]*=s.light?.38f:.52f;h[2]=s.light?Math.min(1f,Math.max(.86f,h[2]+.18f)):Math.max(.12f,Math.min(.42f,h[2]+.08f));return Color.HSVToColor(h);
    }
    static int glassGradientStop(Style s,int color,float intensity,boolean highlight){return s.light?blend(color,Color.WHITE,(highlight?.07f:.025f)+.08f*intensity):blend(color,highlight?s.accent:Color.BLACK,(highlight?.025f:.018f)+.055f*intensity);}
    static int blurGradientStop(Style s,int color,float intensity,boolean highlight){int frost=frostedSurfaceColor(s,color);return s.light?blend(frost,Color.WHITE,(highlight?.05f:.025f)+.07f*intensity):blend(frost,highlight?s.accent:Color.BLACK,(highlight?.018f:.030f)+.045f*intensity);}

    static GradientDrawable plainSurface(Context c,Style s,int color){
        GradientDrawable d=s.gradientEnabled?new GradientDrawable(orientation(s.gradientAngle),harmonicGradientStops(s,color)):new GradientDrawable();
        if(!s.gradientEnabled)d.setColor(color);d.setCornerRadius(dp(c,s.cornerRadius));d.setStroke(dp(c,1),s.border);d.setAlpha(s.cardAlpha);return d;
    }
    static GradientDrawable surface(Context c,Style s,int color){
        if(s==null){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,14));return d;}
        String effect=s.effectMode;boolean glass="glass".equals(effect),blur="blur".equals(effect);float gi=s.glassIntensity/100f,bi=s.blurIntensity/100f,bs=s.borderStrength/100f;GradientDrawable d;
        if(s.gradientEnabled){int[] raw=harmonicGradientStops(s,color),stops=new int[raw.length];for(int i=0;i<raw.length;i++){boolean hi=i==0;stops[i]=glass?glassGradientStop(s,raw[i],gi,hi):blur?blurGradientStop(s,raw[i],bi,hi):raw[i];}d=new GradientDrawable(orientation(s.gradientAngle),stops);if(glass)d.setStroke(dp(c,1),blend(s.border,Color.WHITE,(s.light?(.08f+.18f*bi):(.03f+.10f*bi))+.28f*bs));else if(blur)d.setStroke(dp(c,1),blend(s.border,s.light?Color.WHITE:Color.BLACK,.22f));else d.setStroke(dp(c,1),s.border);
        }else if(glass){int c1=blend(color,s.light?Color.WHITE:s.accent,s.light?(.10f+.18f*gi):(.06f+.16f*gi)),c2=blend(color,s.light?Color.WHITE:Color.BLACK,s.light?(.03f+.09f*gi):(.03f+.08f*gi));d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});d.setStroke(dp(c,1),blend(s.border,Color.WHITE,(s.light?(.08f+.18f*bi):(.03f+.10f*bi))+.28f*bs));
        }else if(blur){int frost=frostedSurfaceColor(s,color),c1=blend(frost,s.light?Color.WHITE:s.accent,s.light?(.08f+.18f*bi):(.03f+.10f*bi)),c2=blend(frost,s.light?Color.WHITE:Color.BLACK,s.light?(.03f+.10f*bi):(.05f+.14f*bi));d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});d.setStroke(dp(c,1),blend(s.border,s.light?Color.WHITE:Color.BLACK,.22f));
        }else{int second=blend(color,s.light?Color.WHITE:Color.BLACK,.018f);d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{color,second});d.setStroke(dp(c,1),s.border);}
        if(glass)d.setAlpha(Math.min(s.cardAlpha,Math.round(245-45*gi)));else if(blur)d.setAlpha(Math.min(s.cardAlpha,Math.round(246-28*bi)));else d.setAlpha(s.cardAlpha);d.setCornerRadius(dp(c,s.cornerRadius));return d;
    }
    static GradientDrawable homeCard(Context c,Style s){GradientDrawable g=surface(c,s,s.primary);g.setCornerRadius(dp(c,Math.max(12,s.cornerRadius-1)));g.setStroke(dp(c,1),s.border);g.setAlpha(Math.min(s.cardAlpha,s.homeCardAlpha));return g;}
    static GradientDrawable subCard(Context c,Style s){return s.effectSubcards?surface(c,s,s.sub):plainSurface(c,s,s.sub);}
    static GradientDrawable tertiaryCard(Context c,Style s){return s.effectSubcards?surface(c,s,s.tertiary):plainSurface(c,s,s.tertiary);}
    static GradientDrawable dialog(Context c,Style s){GradientDrawable d=(s.gradientEnabled||"glass".equals(s.effectMode)||"blur".equals(s.effectMode))?surface(c,s,s.dialog):plainSurface(c,s,s.dialog);d.setCornerRadius(dp(c,22));d.setStroke(dp(c,1),s.border);d.setAlpha(Math.max(0,Math.min(255,Math.min(246,s.cardAlpha))));return d;}
    static GradientDrawable button(Context c,Style s,boolean selected){int color=selected?s.selected:s.button;GradientDrawable d=(s.effectButtons||s.gradientEnabled||"glass".equals(s.effectMode)||"blur".equals(s.effectMode))?surface(c,s,color):plainSurface(c,s,color);d.setCornerRadius(dp(c,15));d.setStroke(dp(c,1),selected?blend(s.border,s.accent,.35f):s.border);d.setAlpha(Math.max(0,Math.min(255,Math.min(s.cardAlpha,242))));return d;}
}
