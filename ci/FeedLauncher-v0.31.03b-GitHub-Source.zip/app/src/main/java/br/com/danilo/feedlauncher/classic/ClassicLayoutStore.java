package br.com.danilo.feedlauncher.classic;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Persistent model for the reduced Launcher3-style classic workspace. */
public final class ClassicLayoutStore {
    public static final String TYPE_APP = "app";
    public static final String TYPE_WIDGET = "widget";
    public static final String TYPE_FOLDER = "folder";
    private static final String KEY_LAYOUT = "classic3.layout.v1";
    private static final String KEY_PAGES = "classic3.pages.v1";
    private static final String KEY_CURRENT_PAGE = "classic3.currentPage.v1";
    private static final String KEY_LAYOUT_BACKUP = "classic3.layout.backup.v1";

    public static final class Item {
        public String id = UUID.randomUUID().toString();
        public String type = TYPE_APP;
        public int page = 0;
        public int cellX = 0;
        public int cellY = 0;
        public int spanX = 1;
        public int spanY = 1;
        public String packageName = "";
        public String className = "";
        public int appWidgetId = -1;
        public String title = "";
        public final ArrayList<String> members = new ArrayList<>();

        public Item copy() {
            Item o = new Item();
            o.id=id; o.type=type; o.page=page; o.cellX=cellX; o.cellY=cellY;
            o.spanX=spanX; o.spanY=spanY; o.packageName=packageName;
            o.className=className; o.appWidgetId=appWidgetId; o.title=title;
            o.members.clear(); o.members.addAll(members);
            return o;
        }
    }

    private final SharedPreferences prefs;
    private final ArrayList<Item> items = new ArrayList<>();
    private int pageCount = 2;
    private int currentPage = 0;

    public ClassicLayoutStore(SharedPreferences prefs) {
        this.prefs = prefs;
        load();
    }

    public synchronized List<Item> items() {
        ArrayList<Item> out = new ArrayList<>();
        for (Item item : items) out.add(item.copy());
        return out;
    }

    public synchronized List<Item> itemsOnPage(int page) {
        ArrayList<Item> out = new ArrayList<>();
        for (Item item : items) if (item.page == page) out.add(item.copy());
        Collections.sort(out, Comparator.comparingInt((Item i) -> i.cellY).thenComparingInt(i -> i.cellX));
        return out;
    }

    /** Live model entry; call put/save after mutation. */
    public synchronized Item find(String id) {
        if (id == null) return null;
        for (Item item : items) if (id.equals(item.id)) return item;
        return null;
    }

    public synchronized int pageCount() { return Math.max(1, pageCount); }
    public synchronized int currentPage() { return Math.max(0, Math.min(currentPage, pageCount()-1)); }

    public synchronized void setCurrentPage(int page) {
        int clamped=Math.max(0,Math.min(page,pageCount()-1));
        if(clamped==currentPage)return;
        currentPage=clamped;
        prefs.edit().putInt(KEY_CURRENT_PAGE,currentPage).apply();
    }

    public synchronized void ensurePages(int count) {
        int next=Math.max(pageCount,Math.max(1,count));
        if(next==pageCount)return;
        pageCount=next;
        save();
    }

    public synchronized boolean pageHasItems(int page){
        for(Item item:items)if(item.page==page)return true;
        return false;
    }

    public synchronized void trimTrailingEmptyPages() {
        int lastUsed = 0;
        for (Item item : items) lastUsed = Math.max(lastUsed, item.page);
        pageCount = Math.max(2, lastUsed + 1);
        currentPage=Math.min(currentPage,pageCount-1);
        save();
    }

    public synchronized void put(Item incoming) {
        Item old = find(incoming.id);
        if (old == null) items.add(incoming.copy());
        else copyInto(incoming, old);
        pageCount = Math.max(pageCount, incoming.page + 1);
        save();
    }

    /** Atomically persists a set of simulated placements with one write. */
    public synchronized void putAll(List<Item> incoming) {
        if(incoming==null||incoming.isEmpty())return;
        for(Item next:incoming){
            Item old=find(next.id);
            if(old==null)items.add(next.copy());
            else copyInto(next,old);
            pageCount=Math.max(pageCount,next.page+1);
        }
        save();
    }

    public synchronized void remove(String id) {
        for (int i=items.size()-1;i>=0;i--) if (id.equals(items.get(i).id)) items.remove(i);
        trimTrailingEmptyPages();
    }

    public synchronized void removeWidgetId(int appWidgetId) {
        for (int i=items.size()-1;i>=0;i--) {
            Item it=items.get(i);
            if (TYPE_WIDGET.equals(it.type) && it.appWidgetId==appWidgetId) items.remove(i);
        }
        trimTrailingEmptyPages();
    }

    public synchronized Item createFolderFromApps(String movingId,String targetId,int page,int cellX,int cellY){
        Item moving=find(movingId),target=find(targetId);
        if(moving==null||target==null||moving==target)return null;
        if(!TYPE_APP.equals(moving.type)||!TYPE_APP.equals(target.type))return null;
        String a=componentKey(moving),b=componentKey(target);
        if(a.isEmpty()||b.isEmpty()||a.equals(b))return null;
        Item folder=new Item();
        folder.type=TYPE_FOLDER;folder.page=page;folder.cellX=cellX;folder.cellY=cellY;folder.spanX=1;folder.spanY=1;
        folder.title="Pasta";folder.members.add(a);folder.members.add(b);
        removeInternal(moving.id);removeInternal(target.id);items.add(folder);
        pageCount=Math.max(pageCount,page+1);save();return folder.copy();
    }

    public synchronized Item createFolderWithExternalApp(String targetId,String pkg,String cls,int page,int cellX,int cellY){
        Item target=find(targetId);if(target==null||!TYPE_APP.equals(target.type))return null;
        String a=componentKey(target),b=componentKey(pkg,cls);
        if(a.isEmpty()||b.isEmpty()||a.equals(b))return null;
        Item folder=new Item();folder.type=TYPE_FOLDER;folder.page=page;folder.cellX=cellX;folder.cellY=cellY;folder.title="Pasta";
        folder.members.add(a);folder.members.add(b);
        removeInternal(target.id);items.add(folder);pageCount=Math.max(pageCount,page+1);save();return folder.copy();
    }

    public synchronized boolean addItemToFolder(String movingId,String folderId){
        Item moving=find(movingId),folder=find(folderId);
        if(moving==null||folder==null||moving==folder)return false;
        if(!TYPE_APP.equals(moving.type)||!TYPE_FOLDER.equals(folder.type))return false;
        String key=componentKey(moving);if(key.isEmpty())return false;
        if(!folder.members.contains(key))folder.members.add(key);
        removeInternal(moving.id);save();return true;
    }

    public synchronized boolean addComponentToFolder(String pkg,String cls,String folderId){
        Item folder=find(folderId);if(folder==null||!TYPE_FOLDER.equals(folder.type))return false;
        String key=componentKey(pkg,cls);if(key.isEmpty())return false;
        if(!folder.members.contains(key))folder.members.add(key);
        save();return true;
    }

    public synchronized boolean removeFolderMember(String folderId,String componentKey){
        Item folder=find(folderId);if(folder==null||!TYPE_FOLDER.equals(folder.type))return false;
        boolean removed=folder.members.remove(componentKey);if(!removed)return false;
        if(folder.members.isEmpty()){
            removeInternal(folder.id);
        }else if(folder.members.size()==1){
            String only=folder.members.get(0);String[] pair=parseComponentKey(only);
            folder.type=TYPE_APP;folder.packageName=pair[0];folder.className=pair[1];folder.title="";folder.members.clear();
        }
        trimTrailingEmptyPagesNoSave();save();return true;
    }

    public synchronized List<String> folderMembers(String folderId){
        Item folder=find(folderId);if(folder==null||!TYPE_FOLDER.equals(folder.type))return Collections.emptyList();
        return new ArrayList<>(folder.members);
    }

    public synchronized boolean renameFolder(String folderId,String title){
        Item folder=find(folderId);if(folder==null||!TYPE_FOLDER.equals(folder.type))return false;
        String clean=title==null?"":title.trim();
        if(clean.length()>32)clean=clean.substring(0,32);
        folder.title=clean.isEmpty()?"Pasta":clean;
        save();return true;
    }

    public synchronized boolean reorderFolderMember(String folderId,String componentKey,int targetIndex){
        Item folder=find(folderId);if(folder==null||!TYPE_FOLDER.equals(folder.type))return false;
        int old=folder.members.indexOf(componentKey);if(old<0)return false;
        String key=folder.members.remove(old);
        targetIndex=Math.max(0,Math.min(targetIndex,folder.members.size()));
        folder.members.add(targetIndex,key);save();return true;
    }

    public synchronized boolean containsComponent(String componentKey){
        if(componentKey==null||componentKey.isEmpty())return false;
        for(Item it:items){
            if(TYPE_APP.equals(it.type)&&componentKey.equals(componentKey(it)))return true;
            if(TYPE_FOLDER.equals(it.type)&&it.members.contains(componentKey))return true;
        }
        return false;
    }

    /** Removes app shortcuts/folder members that are no longer installed. */
    public synchronized boolean pruneMissingComponents(Set<String> installed){
        if(installed==null)return false;boolean changed=false;
        for(int i=items.size()-1;i>=0;i--){
            Item it=items.get(i);
            if(TYPE_APP.equals(it.type)){
                if(!installed.contains(componentKey(it))){items.remove(i);changed=true;}
            }else if(TYPE_FOLDER.equals(it.type)){
                for(int m=it.members.size()-1;m>=0;m--){
                    if(!installed.contains(it.members.get(m))){it.members.remove(m);changed=true;}
                }
                if(it.members.isEmpty()){items.remove(i);changed=true;}
                else if(it.members.size()==1){
                    String[] pair=parseComponentKey(it.members.get(0));
                    it.type=TYPE_APP;it.packageName=pair[0];it.className=pair[1];it.title="";it.members.clear();changed=true;
                }
            }
        }
        if(changed){trimTrailingEmptyPagesNoSave();save();}
        return changed;
    }

    public synchronized void repairDuplicatesAndBounds(int cols, int rows) {
        boolean changed=false;
        Set<String> ids=new HashSet<>();
        for (int i=items.size()-1;i>=0;i--) {
            Item it=items.get(i);
            if (it.id==null || it.id.isEmpty() || !ids.add(it.id)) { items.remove(i); changed=true; continue; }
            if(!TYPE_APP.equals(it.type)&&!TYPE_WIDGET.equals(it.type)&&!TYPE_FOLDER.equals(it.type)){items.remove(i);changed=true;continue;}
            if(TYPE_FOLDER.equals(it.type)){
                for(int m=it.members.size()-1;m>=0;m--)if(it.members.get(m)==null||it.members.get(m).isEmpty())it.members.remove(m);
                if(it.members.isEmpty()){items.remove(i);changed=true;continue;}
                if(it.members.size()==1){String[] pair=parseComponentKey(it.members.get(0));it.type=TYPE_APP;it.packageName=pair[0];it.className=pair[1];it.members.clear();changed=true;}
                it.spanX=1;it.spanY=1;
            }
            int oldX=it.cellX,oldY=it.cellY,oldSx=it.spanX,oldSy=it.spanY,oldPage=it.page;
            it.page=Math.max(0,it.page);
            it.spanX=Math.max(1,Math.min(cols,it.spanX));
            it.spanY=Math.max(1,Math.min(rows,it.spanY));
            it.cellX=Math.max(0,Math.min(cols-it.spanX,it.cellX));
            it.cellY=Math.max(0,Math.min(rows-it.spanY,it.cellY));
            if(oldX!=it.cellX||oldY!=it.cellY||oldSx!=it.spanX||oldSy!=it.spanY||oldPage!=it.page)changed=true;
            pageCount=Math.max(pageCount,it.page+1);
        }
        currentPage=Math.max(0,Math.min(currentPage,pageCount-1));
        if(changed)save();
    }

    /** Reflows collisions after a grid-size change instead of allowing clamped items to overlap. */
    public synchronized void reflowForGrid(int cols,int rows){
        cols=Math.max(1,cols);rows=Math.max(1,rows);
        ArrayList<Item> ordered=new ArrayList<>(items);
        Collections.sort(ordered,Comparator.comparingInt((Item i)->i.page).thenComparingInt(i->i.cellY).thenComparingInt(i->i.cellX).thenComparing(i->i.id));
        ArrayList<Item> placed=new ArrayList<>();boolean changed=false;int maxPage=0;
        for(Item it:ordered){
            int oldPage=it.page,oldX=it.cellX,oldY=it.cellY,oldSx=it.spanX,oldSy=it.spanY;
            if(TYPE_FOLDER.equals(it.type)){it.spanX=1;it.spanY=1;}
            it.spanX=Math.max(1,Math.min(cols,it.spanX));it.spanY=Math.max(1,Math.min(rows,it.spanY));
            int page=Math.max(0,it.page);int dx=Math.max(0,Math.min(cols-it.spanX,it.cellX));int dy=Math.max(0,Math.min(rows-it.spanY,it.cellY));
            int[] free=findNearestFreeForReflow(placed,page,dx,dy,it.spanX,it.spanY,cols,rows);
            while(free==null){page++;free=findNearestFreeForReflow(placed,page,0,0,it.spanX,it.spanY,cols,rows);}
            it.page=page;it.cellX=free[0];it.cellY=free[1];placed.add(it);maxPage=Math.max(maxPage,page);
            if(oldPage!=it.page||oldX!=it.cellX||oldY!=it.cellY||oldSx!=it.spanX||oldSy!=it.spanY)changed=true;
        }
        int nextPages=Math.max(2,maxPage+1);if(pageCount!=nextPages){pageCount=nextPages;changed=true;}
        int nextCurrent=Math.max(0,Math.min(currentPage,pageCount-1));if(nextCurrent!=currentPage){currentPage=nextCurrent;changed=true;}
        if(changed)save();
    }

    private static int[] findNearestFreeForReflow(List<Item> placed,int page,int desiredX,int desiredY,int sx,int sy,int cols,int rows){
        int bestD=Integer.MAX_VALUE,bestX=-1,bestY=-1;
        for(int y=0;y<=rows-sy;y++)for(int x=0;x<=cols-sx;x++){
            boolean occupied=false;for(Item p:placed){if(p.page==page&&overlapsForReflow(x,y,sx,sy,p.cellX,p.cellY,p.spanX,p.spanY)){occupied=true;break;}}
            if(occupied)continue;int d=Math.abs(x-desiredX)+Math.abs(y-desiredY);if(d<bestD){bestD=d;bestX=x;bestY=y;}
        }
        return bestX<0?null:new int[]{bestX,bestY};
    }

    private static boolean overlapsForReflow(int ax,int ay,int aw,int ah,int bx,int by,int bw,int bh){
        return ax<bx+bw&&ax+aw>bx&&ay<by+bh&&ay+ah>by;
    }

    public static String componentKey(Item item){return item==null?"":componentKey(item.packageName,item.className);}
    public static String componentKey(String pkg,String cls){
        if(pkg==null||pkg.isEmpty()||cls==null||cls.isEmpty())return "";
        return pkg+"/"+cls;
    }
    public static String[] parseComponentKey(String key){
        if(key==null)return new String[]{"",""};int slash=key.indexOf('/');
        if(slash<=0||slash>=key.length()-1)return new String[]{"",""};
        return new String[]{key.substring(0,slash),key.substring(slash+1)};
    }

    private void removeInternal(String id){for(int i=items.size()-1;i>=0;i--)if(id.equals(items.get(i).id))items.remove(i);}
    private void trimTrailingEmptyPagesNoSave(){
        int lastUsed=0;for(Item item:items)lastUsed=Math.max(lastUsed,item.page);
        pageCount=Math.max(2,lastUsed+1);currentPage=Math.min(currentPage,pageCount-1);
    }

    private void copyInto(Item from, Item to) {
        to.id=from.id; to.type=from.type; to.page=from.page; to.cellX=from.cellX; to.cellY=from.cellY;
        to.spanX=from.spanX; to.spanY=from.spanY; to.packageName=from.packageName;
        to.className=from.className; to.appWidgetId=from.appWidgetId; to.title=from.title;
        to.members.clear();to.members.addAll(from.members);
    }

    private synchronized void load() {
        items.clear();
        pageCount=Math.max(2,prefs.getInt(KEY_PAGES,2));
        currentPage=Math.max(0,prefs.getInt(KEY_CURRENT_PAGE,0));
        String raw=prefs.getString(KEY_LAYOUT,"[]");
        String backup=prefs.getString(KEY_LAYOUT_BACKUP,"[]");
        try {
            JSONArray array=new JSONArray(raw==null?"[]":raw);
            for(int i=0;i<array.length();i++){
                JSONObject o=array.optJSONObject(i); if(o==null)continue;
                Item it=new Item();
                it.id=o.optString("id",UUID.randomUUID().toString());
                it.type=o.optString("type",TYPE_APP);
                it.page=Math.max(0,o.optInt("page",0));
                it.cellX=Math.max(0,o.optInt("x",0));
                it.cellY=Math.max(0,o.optInt("y",0));
                it.spanX=Math.max(1,o.optInt("sx",1));
                it.spanY=Math.max(1,o.optInt("sy",1));
                it.packageName=o.optString("pkg","");
                it.className=o.optString("cls","");
                it.appWidgetId=o.optInt("wid",-1);
                it.title=o.optString("title","");
                JSONArray members=o.optJSONArray("members");
                if(members!=null)for(int m=0;m<members.length();m++){String key=members.optString(m,"");if(!key.isEmpty()&&!it.members.contains(key))it.members.add(key);}
                if(TYPE_APP.equals(it.type) || TYPE_WIDGET.equals(it.type) || TYPE_FOLDER.equals(it.type)){
                    items.add(it); pageCount=Math.max(pageCount,it.page+1);
                }
            }
        } catch (Exception ignored) {
            items.clear();pageCount=Math.max(2,prefs.getInt(KEY_PAGES,2));currentPage=Math.max(0,prefs.getInt(KEY_CURRENT_PAGE,0));
            try{
                JSONArray array=new JSONArray(backup==null?"[]":backup);
                for(int i=0;i<array.length();i++){
                    JSONObject o=array.optJSONObject(i);if(o==null)continue;
                    Item it=new Item();it.id=o.optString("id",UUID.randomUUID().toString());it.type=o.optString("type",TYPE_APP);
                    it.page=Math.max(0,o.optInt("page",0));it.cellX=Math.max(0,o.optInt("x",0));it.cellY=Math.max(0,o.optInt("y",0));
                    it.spanX=Math.max(1,o.optInt("sx",1));it.spanY=Math.max(1,o.optInt("sy",1));it.packageName=o.optString("pkg","");
                    it.className=o.optString("cls","");it.appWidgetId=o.optInt("wid",-1);it.title=o.optString("title","");
                    JSONArray members=o.optJSONArray("members");if(members!=null)for(int m=0;m<members.length();m++){String key=members.optString(m,"");if(!key.isEmpty()&&!it.members.contains(key))it.members.add(key);}
                    if(TYPE_APP.equals(it.type)||TYPE_WIDGET.equals(it.type)||TYPE_FOLDER.equals(it.type)){items.add(it);pageCount=Math.max(pageCount,it.page+1);}
                }
            }catch(Exception ignoredBackup){items.clear();pageCount=2;currentPage=0;}
        }
        currentPage=Math.min(currentPage,pageCount-1);
    }

    public synchronized void save() {
        JSONArray array=new JSONArray();
        try {
            for(Item it:items){
                JSONObject o=new JSONObject();
                o.put("id",it.id); o.put("type",it.type); o.put("page",it.page);
                o.put("x",it.cellX); o.put("y",it.cellY); o.put("sx",it.spanX); o.put("sy",it.spanY);
                o.put("pkg",it.packageName==null?"":it.packageName);
                o.put("cls",it.className==null?"":it.className); o.put("wid",it.appWidgetId);
                o.put("title",it.title==null?"":it.title);
                if(TYPE_FOLDER.equals(it.type)){
                    JSONArray members=new JSONArray();for(String key:it.members)members.put(key);o.put("members",members);
                }
                array.put(o);
            }
        } catch (Exception ignored) {}
        String next=array.toString();
        String previous=prefs.getString(KEY_LAYOUT,"[]");
        SharedPreferences.Editor editor=prefs.edit();
        if(previous!=null&&!previous.isEmpty()&&!previous.equals(next))editor.putString(KEY_LAYOUT_BACKUP,previous);
        editor.putString(KEY_LAYOUT,next)
                .putInt(KEY_PAGES,Math.max(2,pageCount))
                .putInt(KEY_CURRENT_PAGE,Math.max(0,Math.min(currentPage,pageCount-1)))
                .commit();
    }
}
