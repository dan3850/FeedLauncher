/*
 * Behaviour ported/adapted from AOSP Launcher3 AppWidgetResizeFrame.java.
 * Copyright (C) The Android Open Source Project
 * Licensed under the Apache License, Version 2.0.
 */
package br.com.danilo.feedlauncher.classic;

import android.animation.ValueAnimator;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetProviderInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Dependency-light port of Launcher3's AppWidgetResizeFrame mechanics.
 *
 * Kept deliberately close to Launcher3 behaviour:
 * - border hit-regions (not old Classic corner controls);
 * - horizontal/vertical edges can be active together for true corner resize;
 * - 0.66-cell accumulated threshold;
 * - exact requested widget cell/span while neighbours are reordered;
 * - resize direction is passed into the reorder algorithm;
 * - temporary widget geometry + AppWidgetHostView size-range updates;
 * - commit on pointer release, then the frame stays open and snaps back to the widget;
 * - touching outside closes the resize frame.
 */
final class L3WidgetResizeFrame extends FrameLayout {
    interface Callbacks { void onClosed(boolean committed); }

    private static final float RESIZE_THRESHOLD=.66f;
    private static final long SNAP_DURATION_MS=150L;
    private static final float DIMMED_HANDLE_ALPHA=0f;
    private static final int INDEX_LEFT=0,INDEX_TOP=1,INDEX_RIGHT=2,INDEX_BOTTOM=3;

    private final FrameLayout root;
    private final ClassicWorkspace workspace;
    private final ClassicLayoutStore store;
    private final String itemId;
    private final View widgetContainer;
    private final AppWidgetHostView hostView;
    private final AppWidgetProviderInfo provider;
    private final Callbacks callbacks;
    private final FrameLayout frame;
    private final View[] dragHandles=new View[4];
    private final int minSpanX,minSpanY,maxSpanX,maxSpanY;
    private final int cellW,cellH;
    private final int touchTargetWidth;
    private final int backgroundPadding;

    private boolean leftActive,rightActive,topActive,bottomActive;
    private int baseCellX,baseCellY,baseSpanX,baseSpanY;
    private int pendingCellX,pendingCellY,pendingSpanX,pendingSpanY;
    private int runningHInc,runningVInc;
    private final int[] lastDirectionVector=new int[]{1,0};
    private float downRawX,downRawY;
    private float baselineX,baselineY,baselineW,baselineH;
    private boolean gestureChanged=false;
    private boolean sessionCommitted=false;
    private boolean closed=false;
    private ValueAnimator snapAnimator;

    private final OnLayoutChangeListener widgetLayoutListener=(v,l,t,r,b,ol,ot,or,ob)->{
        if(!closed && !leftActive && !rightActive && !topActive && !bottomActive) post(()->snapToWidget(true));
    };

    static L3WidgetResizeFrame show(FrameLayout root,ClassicWorkspace workspace,ClassicLayoutStore store,
            String itemId,View widgetContainer,AppWidgetHostView hostView,AppWidgetProviderInfo provider,
            int minSpanX,int minSpanY,int maxSpanX,int maxSpanY,Callbacks cb){
        if(root==null||workspace==null||store==null||itemId==null||widgetContainer==null||hostView==null||provider==null)return null;
        L3WidgetResizeFrame v=new L3WidgetResizeFrame(root,workspace,store,itemId,widgetContainer,hostView,provider,
                minSpanX,minSpanY,maxSpanX,maxSpanY,cb);
        root.addView(v,new FrameLayout.LayoutParams(-1,-1));
        v.bringToFront();
        v.post(()->v.snapToWidget(false));
        return v;
    }

    private L3WidgetResizeFrame(FrameLayout root,ClassicWorkspace workspace,ClassicLayoutStore store,
            String itemId,View widgetContainer,AppWidgetHostView hostView,AppWidgetProviderInfo provider,
            int minSpanX,int minSpanY,int maxSpanX,int maxSpanY,Callbacks cb){
        super(root.getContext());
        this.root=root;this.workspace=workspace;this.store=store;this.itemId=itemId;
        this.widgetContainer=widgetContainer;this.hostView=hostView;this.provider=provider;this.callbacks=cb;
        ClassicCellLayout grid=workspace.currentCellLayout();
        cellW=Math.max(1,grid==null?1:grid.cellWidth());cellH=Math.max(1,grid==null?1:grid.cellHeight());
        this.minSpanX=Math.max(1,minSpanX);this.minSpanY=Math.max(1,minSpanY);
        this.maxSpanX=Math.max(this.minSpanX,Math.min(workspace.columns(),maxSpanX));
        this.maxSpanY=Math.max(this.minSpanY,Math.min(workspace.rows(),maxSpanY));
        touchTargetWidth=dp(32);backgroundPadding=dp(8);
        syncBaseFromStore();

        setClickable(true);setFocusable(true);setBackgroundColor(Color.TRANSPARENT);
        frame=new FrameLayout(getContext());frame.setClipChildren(false);frame.setClipToPadding(false);
        updateFrameBackground(false);
        addView(frame,new FrameLayout.LayoutParams(dp(100),dp(100)));

        boolean horizontal=(provider.resizeMode&AppWidgetProviderInfo.RESIZE_HORIZONTAL)!=0;
        boolean vertical=(provider.resizeMode&AppWidgetProviderInfo.RESIZE_VERTICAL)!=0;
        if(horizontal){dragHandles[INDEX_LEFT]=addHandle(true,Gravity.LEFT|Gravity.CENTER_VERTICAL);dragHandles[INDEX_RIGHT]=addHandle(true,Gravity.RIGHT|Gravity.CENTER_VERTICAL);}
        if(vertical){dragHandles[INDEX_TOP]=addHandle(false,Gravity.TOP|Gravity.CENTER_HORIZONTAL);dragHandles[INDEX_BOTTOM]=addHandle(false,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);}

        widgetContainer.addOnLayoutChangeListener(widgetLayoutListener);
        setOnTouchListener((v,e)->handleControllerTouch(e));
    }

    private View addHandle(boolean verticalBar,int gravity){
        View handle=new View(getContext());GradientDrawable d=new GradientDrawable();d.setColor(Color.WHITE);d.setCornerRadius(dp(4));d.setStroke(dp(1),0x66000000);handle.setBackground(d);handle.setContentDescription("Redimensionar widget");
        int w=verticalBar?dp(6):dp(34),h=verticalBar?dp(34):dp(6);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(w,h,gravity);
        if((gravity&Gravity.LEFT)!=0)lp.leftMargin=-dp(3);if((gravity&Gravity.RIGHT)!=0)lp.rightMargin=-dp(3);
        if((gravity&Gravity.TOP)!=0)lp.topMargin=-dp(3);if((gravity&Gravity.BOTTOM)!=0)lp.bottomMargin=-dp(3);
        frame.addView(handle,lp);return handle;
    }

    private boolean handleControllerTouch(MotionEvent e){
        if(closed)return false;
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN){
            if(!beginResizeIfPointInRegion(e.getX(),e.getY())){close(false);return true;}
            downRawX=e.getRawX();downRawY=e.getRawY();
            baselineX=frame.getX();baselineY=frame.getY();baselineW=frame.getWidth();baselineH=frame.getHeight();
            runningHInc=runningVInc=0;gestureChanged=false;syncBaseFromStore();
            return true;
        }
        if(!(leftActive||rightActive||topActive||bottomActive))return true;
        float dx=e.getRawX()-downRawX,dy=e.getRawY()-downRawY;
        if(action==MotionEvent.ACTION_MOVE){visualizeResizeForDelta(dx,dy);return true;}
        if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
            visualizeResizeForDelta(dx,dy);finishResizeGesture();return true;
        }
        return true;
    }

    /** Equivalent to Launcher3 beginResizeIfPointInRegion(). */
    private boolean beginResizeIfPointInRegion(float x,float y){
        float localX=x-frame.getX(),localY=y-frame.getY();float w=frame.getWidth(),h=frame.getHeight();
        boolean horizontal=(provider.resizeMode&AppWidgetProviderInfo.RESIZE_HORIZONTAL)!=0;
        boolean vertical=(provider.resizeMode&AppWidgetProviderInfo.RESIZE_VERTICAL)!=0;
        leftActive=horizontal&&localX>=-touchTargetWidth&&localX<=touchTargetWidth;
        rightActive=horizontal&&localX>=w-touchTargetWidth&&localX<=w+touchTargetWidth;
        topActive=vertical&&localY>=-touchTargetWidth&&localY<=touchTargetWidth;
        bottomActive=vertical&&localY>=h-touchTargetWidth&&localY<=h+touchTargetWidth;
        if(leftActive&&rightActive){if(Math.abs(localX)<Math.abs(localX-w))rightActive=false;else leftActive=false;}
        if(topActive&&bottomActive){if(Math.abs(localY)<Math.abs(localY-h))bottomActive=false;else topActive=false;}
        boolean any=leftActive||rightActive||topActive||bottomActive;
        if(any){
            setHandleAlpha(INDEX_LEFT,leftActive?1f:DIMMED_HANDLE_ALPHA);
            setHandleAlpha(INDEX_RIGHT,rightActive?1f:DIMMED_HANDLE_ALPHA);
            setHandleAlpha(INDEX_TOP,topActive?1f:DIMMED_HANDLE_ALPHA);
            setHandleAlpha(INDEX_BOTTOM,bottomActive?1f:DIMMED_HANDLE_ALPHA);
        }
        return any;
    }

    /** Equivalent to Launcher3 visualizeResizeForDelta(). */
    private void visualizeResizeForDelta(float deltaX,float deltaY){
        float l=baselineX,t=baselineY,r=baselineX+baselineW,b=baselineY+baselineH;
        if(leftActive)l+=deltaX;if(rightActive)r+=deltaX;if(topActive)t+=deltaY;if(bottomActive)b+=deltaY;
        float minVisual=touchTargetWidth*2f;
        if(r-l<minVisual){if(leftActive)l=r-minVisual;else r=l+minVisual;}
        if(b-t<minVisual){if(topActive)t=b-minVisual;else b=t+minVisual;}
        l=Math.max(-backgroundPadding,Math.min(root.getWidth()-minVisual,l));t=Math.max(-backgroundPadding,Math.min(root.getHeight()-minVisual,t));
        r=Math.max(l+minVisual,Math.min(root.getWidth()+backgroundPadding,r));b=Math.max(t+minVisual,Math.min(root.getHeight()+backgroundPadding,b));
        setFrameBounds(l,t,r-l,b-t);
        resizeWidgetIfNeeded(deltaX,deltaY,false);
    }

    /** Port of Launcher3 resizeWidgetIfNeeded(), adapted to ClassicCellLayout. */
    private void resizeWidgetIfNeeded(float deltaX,float deltaY,boolean onDismiss){
        int hSpanInc=getSpanIncrement(deltaX/(float)cellW-runningHInc);
        int vSpanInc=getSpanIncrement(deltaY/(float)cellH-runningVInc);
        if(!leftActive&&!rightActive)hSpanInc=0;if(!topActive&&!bottomActive)vSpanInc=0;
        if(!onDismiss&&hSpanInc==0&&vSpanInc==0)return;

        int dirX=leftActive?-1:(rightActive?1:0),dirY=topActive?-1:(bottomActive?1:0);
        if(onDismiss){dirX=lastDirectionVector[0];dirY=lastDirectionVector[1];}
        else if(dirX!=0||dirY!=0){lastDirectionVector[0]=dirX;lastDirectionVector[1]=dirY;}

        int cx=pendingCellX,cy=pendingCellY,sx=pendingSpanX,sy=pendingSpanY;
        int oldCx=cx,oldCy=cy,oldSx=sx,oldSy=sy;
        if(leftActive&&hSpanInc!=0){int right=cx+sx;cx=clamp(cx+hSpanInc,0,right-minSpanX);sx=right-cx;sx=clamp(sx,minSpanX,maxSpanX);cx=right-sx;}
        else if(rightActive&&hSpanInc!=0){sx=clamp(sx+hSpanInc,minSpanX,Math.min(maxSpanX,workspace.columns()-cx));}
        if(topActive&&vSpanInc!=0){int bottom=cy+sy;cy=clamp(cy+vSpanInc,0,bottom-minSpanY);sy=bottom-cy;sy=clamp(sy,minSpanY,maxSpanY);cy=bottom-sy;}
        else if(bottomActive&&vSpanInc!=0){sy=clamp(sy+vSpanInc,minSpanY,Math.min(maxSpanY,workspace.rows()-cy));}
        if(cx==oldCx&&cy==oldCy&&sx==oldSx&&sy==oldSy)return;

        boolean valid=workspace.previewWidgetResize(itemId,cx,cy,sx,sy,minSpanX,minSpanY,dirX,dirY);
        updateFrameBackground(!valid);
        if(!valid)return;

        int actualH=rightActive?(sx-oldSx):(leftActive?(cx-oldCx):0);
        int actualV=bottomActive?(sy-oldSy):(topActive?(cy-oldCy):0);
        pendingCellX=cx;pendingCellY=cy;pendingSpanX=sx;pendingSpanY=sy;
        runningHInc+=actualH;runningVInc+=actualV;gestureChanged=true;
        applyWidgetPreviewGeometry();
    }

    private void applyWidgetPreviewGeometry(){
        if(!(widgetContainer.getLayoutParams() instanceof ClassicCellLayout.LayoutParams))return;
        ClassicCellLayout.LayoutParams lp=(ClassicCellLayout.LayoutParams)widgetContainer.getLayoutParams();
        lp.cellX=pendingCellX;lp.cellY=pendingCellY;lp.spanX=pendingSpanX;lp.spanY=pendingSpanY;widgetContainer.setLayoutParams(lp);widgetContainer.requestLayout();
        widgetContainer.post(this::updateHostSizeRange);
    }

    private void finishResizeGesture(){
        boolean committed=false;
        if(gestureChanged){
            committed=workspace.commitWidgetResize(itemId,pendingCellX,pendingCellY,pendingSpanX,pendingSpanY,minSpanX,minSpanY,lastDirectionVector[0],lastDirectionVector[1]);
            if(committed){sessionCommitted=true;syncBaseFromStore();updateHostSizeRange();}
            else restoreWidgetToStore();
        }else workspace.clearWidgetReorderPreview();
        leftActive=rightActive=topActive=bottomActive=false;runningHInc=runningVInc=0;gestureChanged=false;updateFrameBackground(false);restoreHandleAlpha();post(()->snapToWidget(true));
    }

    private void syncBaseFromStore(){
        ClassicLayoutStore.Item item=store.find(itemId);if(item==null)return;
        baseCellX=pendingCellX=item.cellX;baseCellY=pendingCellY=item.cellY;baseSpanX=pendingSpanX=item.spanX;baseSpanY=pendingSpanY=item.spanY;
    }

    private void restoreWidgetToStore(){
        syncBaseFromStore();workspace.clearWidgetReorderPreview();
        if(widgetContainer.getLayoutParams() instanceof ClassicCellLayout.LayoutParams){ClassicCellLayout.LayoutParams lp=(ClassicCellLayout.LayoutParams)widgetContainer.getLayoutParams();lp.cellX=baseCellX;lp.cellY=baseCellY;lp.spanX=baseSpanX;lp.spanY=baseSpanY;widgetContainer.setLayoutParams(lp);widgetContainer.requestLayout();}
        updateHostSizeRange();
    }

    private void updateHostSizeRange(){
        if(hostView==null||widgetContainer.getWidth()<=0||widgetContainer.getHeight()<=0)return;
        float density=getResources().getDisplayMetrics().density;int wDp=Math.max(1,Math.round(widgetContainer.getWidth()/density)),hDp=Math.max(1,Math.round(widgetContainer.getHeight()/density));
        try{hostView.updateAppWidgetSize(null,wDp,hDp,wDp,hDp);}catch(Exception ignored){}
    }

    void dismiss(boolean commit){
        if(commit&&gestureChanged){boolean ok=workspace.commitWidgetResize(itemId,pendingCellX,pendingCellY,pendingSpanX,pendingSpanY,minSpanX,minSpanY,lastDirectionVector[0],lastDirectionVector[1]);sessionCommitted|=ok;if(!ok)restoreWidgetToStore();}
        close(false);
    }

    private void close(boolean ignored){
        if(closed)return;closed=true;if(snapAnimator!=null)snapAnimator.cancel();workspace.clearWidgetReorderPreview();widgetContainer.removeOnLayoutChangeListener(widgetLayoutListener);
        if(getParent() instanceof FrameLayout)((FrameLayout)getParent()).removeView(this);if(callbacks!=null)callbacks.onClosed(sessionCommitted);
    }

    /** Launcher3-style snap around the actual widget after each resize gesture. */
    private void snapToWidget(boolean animate){
        if(closed||widgetContainer.getWindowToken()==null||root.getWidth()<=0)return;int[] rootLoc=new int[2],widgetLoc=new int[2];root.getLocationOnScreen(rootLoc);widgetContainer.getLocationOnScreen(widgetLoc);
        float tx=widgetLoc[0]-rootLoc[0]-backgroundPadding,ty=widgetLoc[1]-rootLoc[1]-backgroundPadding;
        float tw=widgetContainer.getWidth()+backgroundPadding*2f,th=widgetContainer.getHeight()+backgroundPadding*2f;
        if(!animate||frame.getWidth()<=0){setFrameBounds(tx,ty,tw,th);return;}
        final float sx=frame.getX(),sy=frame.getY(),sw=frame.getWidth(),sh=frame.getHeight();if(snapAnimator!=null)snapAnimator.cancel();snapAnimator=ValueAnimator.ofFloat(0f,1f);snapAnimator.setDuration(SNAP_DURATION_MS);snapAnimator.addUpdateListener(a->{float f=(Float)a.getAnimatedValue();setFrameBounds(lerp(sx,tx,f),lerp(sy,ty,f),lerp(sw,tw,f),lerp(sh,th,f));});snapAnimator.start();
    }

    private void setFrameBounds(float x,float y,float w,float h){
        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)frame.getLayoutParams();lp.width=Math.max(1,Math.round(w));lp.height=Math.max(1,Math.round(h));frame.setLayoutParams(lp);frame.setX(x);frame.setY(y);
    }

    private void updateFrameBackground(boolean invalid){GradientDrawable bg=new GradientDrawable();bg.setColor(0x08000000);bg.setStroke(dp(2),invalid?0xffff6b6b:0xfff4f7fb);bg.setCornerRadius(dp(18));frame.setBackground(bg);}
    private void setHandleAlpha(int index,float alpha){View h=dragHandles[index];if(h!=null)h.setAlpha(alpha);}
    private void restoreHandleAlpha(){for(View h:dragHandles)if(h!=null)h.animate().alpha(1f).setDuration(80).start();}
    private static int getSpanIncrement(float deltaFrac){return Math.abs(deltaFrac)>RESIZE_THRESHOLD?Math.round(deltaFrac):0;}
    private static int clamp(int v,int lo,int hi){return Math.max(lo,Math.min(hi,v));}
    private static float lerp(float a,float b,float f){return a+(b-a)*f;}
    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
