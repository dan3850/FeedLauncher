package br.com.danilo.feedlauncher;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Runtime diagnostics extracted from MainActivity in v0.30.38.
 *
 * This class intentionally owns only passive diagnostics: it never changes launcher
 * behavior, layout or preferences outside of the diagnostic keys it owns.
 */
final class LauncherRuntimeDiagnostics {
    private static final int MAX_EVENTS = 18;
    private static final String KEY_EVENTS = "runtimeRecentEvents";
    private static final String KEY_PREFIX = "runtimeLast";
    private static final AtomicBoolean CRASH_HANDLER_INSTALLED = new AtomicBoolean(false);
    private static volatile LauncherRuntimeDiagnostics activeInstance;
    private static volatile Thread.UncaughtExceptionHandler baseCrashHandler;

    private final SharedPreferences prefs;
    private final long sessionStartedAt = System.currentTimeMillis();
    private final ArrayDeque<String> recentEvents = new ArrayDeque<>();
    private long lastEventAt = 0L;
    private String lastEventSignature = "";

    LauncherRuntimeDiagnostics(Context context, SharedPreferences prefs) {
        this.prefs = prefs;
        loadRecentEvents();
    }

    void installCrashHandler() {
        activeInstance = this;
        if (!CRASH_HANDLER_INSTALLED.compareAndSet(false, true)) return;
        baseCrashHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                LauncherRuntimeDiagnostics current = activeInstance;
                if (current != null) { current.recordError("Falha fatal em " + safeThreadName(thread), error); current.flushNow(); }
            } catch (Throwable ignored) {}
            Thread.UncaughtExceptionHandler base = baseCrashHandler;
            if (base != null) {
                base.uncaughtException(thread, error);
            } else {
                try { android.os.Process.killProcess(android.os.Process.myPid()); } catch (Throwable ignored) {}
                try { System.exit(10); } catch (Throwable ignored) {}
            }
        });
    }

    void recordScreen(String screen) { record("Tela", clean(screen), "Screen"); }
    void recordGesture(String gesture) { record("Gesto", clean(gesture), "Gesture"); }
    void recordGridRebuild(String detail) { record("Grade", clean(detail), "GridRebuild"); }
    void recordWallpaper(String source) { record("Wallpaper", clean(source), "Wallpaper"); }
    void recordRepair(String detail) { record("Reparo", clean(detail), "Repair"); }
    void recordRecovery(String detail) { record("Estado", clean(detail), "StateRecovery"); }
    void recordLifecycle(String detail) { record("Ciclo", clean(detail), "Lifecycle"); }

    void recordAction(String action) {
        record("Ação", safeActionLabel(action), "Action");
    }

    void recordError(String context, Throwable error) {
        StringBuilder detail = new StringBuilder();
        if (context != null && !context.trim().isEmpty()) detail.append(clean(context)).append(" · ");
        if (error == null) detail.append("Erro sem exceção");
        else {
            detail.append(error.getClass().getSimpleName());
            String message = error.getMessage();
            if (message != null && !message.trim().isEmpty()) detail.append(": ").append(clean(message));
            StackTraceElement selected = null;
            try {
                for (StackTraceElement frame : error.getStackTrace()) {
                    if (frame != null && frame.getClassName() != null && frame.getClassName().startsWith("br.com.danilo.feedlauncher")) {
                        selected = frame; break;
                    }
                }
                if (selected == null && error.getStackTrace().length > 0) selected = error.getStackTrace()[0];
            } catch (Throwable ignored) {}
            if (selected != null) detail.append(" @ ").append(selected.getClassName()).append(":").append(selected.getLineNumber());
        }
        record("Erro", detail.toString(), "Error");
    }

    void clearRuntimeHistory() {
        synchronized (recentEvents) { recentEvents.clear(); }
        if (prefs == null) return;
        SharedPreferences.Editor editor = prefs.edit().remove(KEY_EVENTS);
        String[] suffixes = {"Screen","Action","Gesture","GridRebuild","Wallpaper","Repair","StateRecovery","Lifecycle","Error"};
        for (String suffix : suffixes) {
            editor.remove(KEY_PREFIX + suffix).remove(KEY_PREFIX + suffix + "At");
        }
        editor.apply();
    }

    static String memoryText() {
        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        long max = rt.maxMemory();
        return (used / 1024L / 1024L) + " MB / " + (max / 1024L / 1024L) + " MB";
    }

    static int executorQueueSize(ExecutorService executor) {
        try {
            if (executor instanceof ThreadPoolExecutor) return ((ThreadPoolExecutor) executor).getQueue().size();
        } catch (Throwable ignored) {}
        return 0;
    }

    String report() {
        StringBuilder out = new StringBuilder();
        out.append("\n\nRuntime\n");
        appendLast(out, "Última tela", "Screen");
        appendLast(out, "Última ação", "Action");
        appendLast(out, "Último gesto", "Gesture");
        appendLast(out, "Última grade", "GridRebuild");
        appendLast(out, "Último wallpaper", "Wallpaper");
        appendLast(out, "Último reparo runtime", "Repair");
        appendLast(out, "Última recuperação runtime", "StateRecovery");
        appendLast(out, "Último erro interno", "Error");
        out.append("Sessão: ").append(formatDuration(System.currentTimeMillis() - sessionStartedAt)).append("\n");
        ArrayList<String> events = recentEventsSnapshot();
        if (!events.isEmpty()) {
            out.append("Eventos recentes:\n");
            int start = Math.max(0, events.size() - 8);
            for (int i = start; i < events.size(); i++) out.append("• ").append(events.get(i)).append("\n");
        } else {
            out.append("Eventos recentes: nenhum\n");
        }
        return out.toString().trim();
    }

    private void appendLast(StringBuilder out, String label, String suffix) {
        String value = getString(KEY_PREFIX + suffix, "Nenhum");
        long at = getLong(KEY_PREFIX + suffix + "At", 0L);
        out.append(label).append(": ").append(value);
        if (at > 0L) out.append(" · ").append(formatClock(at));
        out.append("\n");
    }

    private void record(String kind, String detail, String suffix) {
        if (detail == null || detail.isEmpty()) detail = "—";
        long now = System.currentTimeMillis();
        String signature = kind + "|" + detail;
        boolean appendEvent = true;
        synchronized (this) {
            if (signature.equals(lastEventSignature) && now - lastEventAt < 350L) appendEvent = false;
            lastEventSignature = signature;
            lastEventAt = now;
        }
        if (appendEvent) {
            String event = formatClock(now) + " · " + kind + " · " + detail;
            synchronized (recentEvents) {
                recentEvents.addLast(event);
                while (recentEvents.size() > MAX_EVENTS) recentEvents.removeFirst();
            }
        }
        if (prefs != null) {
            try {
                SharedPreferences.Editor editor = prefs.edit()
                        .putString(KEY_PREFIX + suffix, detail)
                        .putLong(KEY_PREFIX + suffix + "At", now);
                if (appendEvent) editor.putString(KEY_EVENTS, serializeEvents());
                editor.apply();
            } catch (Throwable ignored) {}
        }
    }

    private void flushNow() {
        if (prefs == null) return;
        try { prefs.edit().putString(KEY_EVENTS, serializeEvents()).commit(); } catch (Throwable ignored) {}
    }

    private void loadRecentEvents() {
        String raw = getString(KEY_EVENTS, "");
        if (raw.isEmpty()) return;
        String[] lines = raw.split("\\n");
        synchronized (recentEvents) {
            for (String line : lines) {
                String clean = clean(line);
                if (!clean.isEmpty()) recentEvents.addLast(clean);
            }
            while (recentEvents.size() > MAX_EVENTS) recentEvents.removeFirst();
        }
    }

    private String serializeEvents() {
        StringBuilder out = new StringBuilder();
        synchronized (recentEvents) {
            for (String event : recentEvents) {
                if (out.length() > 0) out.append('\n');
                out.append(clean(event));
            }
        }
        return out.toString();
    }

    private ArrayList<String> recentEventsSnapshot() {
        synchronized (recentEvents) { return new ArrayList<>(recentEvents); }
    }

    private String getString(String key, String def) {
        if (prefs == null) return def;
        try { return prefs.getString(key, def); } catch (Throwable ignored) { return def; }
    }

    private long getLong(String key, long def) {
        if (prefs == null) return def;
        try { return prefs.getLong(key, def); } catch (Throwable ignored) { return def; }
    }

    private static String safeActionLabel(String action) {
        if (action == null || action.trim().isEmpty()) return "Nenhuma";
        if (action.startsWith("app:")) return "Abrir aplicativo";
        if (action.startsWith("wa:")) return "Abrir conversa do WhatsApp";
        if (action.startsWith("dial:")) return "Abrir discador para contato";
        if (action.startsWith("sms:")) return "Criar SMS para contato";
        if (action.startsWith("url:")) return "Abrir URL/deep link";
        if (action.startsWith("macro:")) return "Executar macro " + clean(action.substring(6));
        return clean(action);
    }

    private static String clean(String value) {
        if (value == null) return "";
        String cleaned = value.replace('\n', ' ').replace('\r', ' ').trim();
        if (cleaned.length() > 180) cleaned = cleaned.substring(0, 180) + "…";
        return cleaned;
    }

    private static String safeThreadName(Thread thread) {
        try { return thread == null ? "desconhecida" : clean(thread.getName()); } catch (Throwable ignored) { return "desconhecida"; }
    }

    private static String formatClock(long when) {
        try { return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(when)); }
        catch (Throwable ignored) { return String.valueOf(when); }
    }

    private static String formatDuration(long millis) {
        long seconds = Math.max(0L, millis / 1000L);
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long secs = seconds % 60L;
        if (hours > 0L) return hours + "h " + minutes + "min";
        if (minutes > 0L) return minutes + "min " + secs + "s";
        return secs + "s";
    }
}
