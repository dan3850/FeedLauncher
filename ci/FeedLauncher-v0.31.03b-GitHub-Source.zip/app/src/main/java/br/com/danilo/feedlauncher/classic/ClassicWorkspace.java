package br.com.danilo.feedlauncher.classic;

import android.content.ComponentName;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Launcher3-style paged workspace reduced to public Android APIs.
 * Positions and widget spans are persisted in cell coordinates.
 */
public final class ClassicWorkspace extends FrameLayout {
    public interface Callbacks {
        View createItemView(ClassicLayoutStore.Item item);
        void onPageChanged(int page,int pageCount);
        void onLayoutPersisted();
        void onNoSpace();
        void onRequestAdd();
        void onRequestLegacyHome();
        void onExternalAppCommitted(DragPayload payload);
        void onWidgetDropRequested(ComponentName provider,int page,int cellX,int cellY,int spanX,int spanY);
        void onDragStateChanged(boolean active,DragPayload payload);
    }

    public static final class DragPayload {
        public static final int KIND_EXISTING=0;
        public static final int KIND_APP=1;
        public static final int KIND_WIDGET=2;

        public final int kind;
        public final String itemId;
        public final int sourcePage;
        public final View sourceView;
        public final String packageName;
        public final String className;
        public final String sourceFolderId;
        public final int sourceHotseatIndex;
        public final ComponentName widgetProvider;
        public final int spanX;
        public final int spanY;
        public final int minSpanX;
        public final int minSpanY;
        public boolean keepSource=false;
        public boolean dropAccepted=false;

        private DragPayload(int kind,String itemId,int sourcePage,View sourceView,
                String packageName,String className,String sourceFolderId,int sourceHotseatIndex,
                ComponentName widgetProvider,int spanX,int spanY,int minSpanX,int minSpanY){
            this.kind=kind;this.itemId=itemId;this.sourcePage=sourcePage;this.sourceView=sourceView;
            this.packageName=packageName;this.className=className;this.sourceFolderId=sourceFolderId;
            this.sourceHotseatIndex=sourceHotseatIndex;this.widgetProvider=widgetProvider;
            this.spanX=Math.max(1,spanX);this.spanY=Math.max(1,spanY);
            this.minSpanX=Math.max(1,Math.min(this.spanX,minSpanX));
            this.minSpanY=Math.max(1,Math.min(this.spanY,minSpanY));
        }

        static DragPayload existing(String itemId,int page,View source){
            return new DragPayload(KIND_EXISTING,itemId,page,source,"","",null,-1,null,1,1,1,1);
        }
        static DragPayload app(View source,String pkg,String cls,String folderId,int hotseatIndex){
            return new DragPayload(KIND_APP,null,-1,source,pkg,cls,folderId,hotseatIndex,null,1,1,1,1);
        }
        static DragPayload widget(View source,ComponentName provider,int spanX,int spanY,int minSpanX,int minSpanY){
            return new DragPayload(KIND_WIDGET,null,-1,source,"","",null,-1,provider,spanX,spanY,minSpanX,minSpanY);
        }
    }

    private final ClassicLayoutStore store;
    private final Callbacks callbacks;
    private final ArrayList<ClassicCellLayout> pages=new ArrayList<>();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final int cols,rows;
    private int currentPage=0;
    private float downX,downY;
    private final int touchSlop;
    private Runnable edgeRunnable;
    private int edgeDirection=0;
    private Runnable longPressRunnable;
    private boolean longPressTriggered=false;
    private boolean dragging=false;
    private boolean internalWidgetDrag=false;
    private boolean downOnItem=false;

    public ClassicWorkspace(Context c,ClassicLayoutStore store,int cols,int rows,Callbacks callbacks){
        super(c);this.store=store;this.cols=cols;this.rows=rows;this.callbacks=callbacks;
        setClipChildren(false);setClipToPadding(false);
        touchSlop=ViewConfiguration.get(c).getScaledTouchSlop();
        store.repairDuplicatesAndBounds(cols,rows);
        store.reflowForGrid(cols,rows);
        currentPage=store.currentPage();
        rebuild();
    }

    public int currentPage(){return currentPage;}
    public int pageCount(){return pages.size();}
    public int columns(){return cols;}
    public int rows(){return rows;}
    public ClassicCellLayout currentCellLayout(){
        return pages.isEmpty()?null:pages.get(Math.max(0,Math.min(currentPage,pages.size()-1)));
    }

    public void rebuild(){
        removeAllViews();pages.clear();
        int count=Math.max(2,store.pageCount());
        for(int page=0;page<count;page++)appendPageInternal(page);
        currentPage=Math.max(0,Math.min(currentPage,pages.size()-1));
        showPage(currentPage,false);
        callbacks.onLayoutPersisted();
    }

    private void appendPageInternal(int pageIndex){
        ClassicCellLayout grid=new ClassicCellLayout(getContext(),cols,rows);
        grid.setVisibility(pageIndex==currentPage?VISIBLE:GONE);
        List<ClassicLayoutStore.Item> pageItems=store.itemsOnPage(pageIndex);
        for(ClassicLayoutStore.Item item:pageItems){
            View v=callbacks.createItemView(item);if(v==null)continue;
            ClassicCellLayout.LayoutParams lp=new ClassicCellLayout.LayoutParams(
                    item.cellX,item.cellY,item.spanX,item.spanY,item.id);
            grid.addView(v,lp);
        }
        pages.add(grid);addView(grid,new FrameLayout.LayoutParams(-1,-1));
    }

    /** Adds a final page without tearing down active drag views. */
    private void appendEmptyPage(){
        int index=pages.size();
        store.ensurePages(index+1);
        appendPageInternal(index);
        callbacks.onPageChanged(currentPage,pages.size());
    }

    public boolean addApp(String pkg,String cls){
        ClassicLayoutStore.Item item=new ClassicLayoutStore.Item();
        item.type=ClassicLayoutStore.TYPE_APP;item.packageName=pkg;item.className=cls;item.page=currentPage;
        int[] pos=findFreeOnPage(currentPage,1,1,null,0,0);
        if(pos==null){
            int p=ensureNextPageForInsert(1,1);item.page=p;pos=findFreeOnPage(p,1,1,null,0,0);
        }
        if(pos==null){callbacks.onNoSpace();return false;}
        item.cellX=pos[0];item.cellY=pos[1];store.put(item);rebuild();showPage(item.page,true);return true;
    }

    public boolean addExternalAppAt(String pkg,String cls,int page,int x,int y){
        ClassicLayoutStore.Item item=new ClassicLayoutStore.Item();item.type=ClassicLayoutStore.TYPE_APP;
        item.packageName=pkg;item.className=cls;item.spanX=1;item.spanY=1;
        return placeNewItemAt(item,page,x,y);
    }

    public boolean addWidget(int widgetId,int spanX,int spanY){
        ClassicLayoutStore.Item item=new ClassicLayoutStore.Item();
        item.type=ClassicLayoutStore.TYPE_WIDGET;item.appWidgetId=widgetId;
        item.spanX=Math.max(1,Math.min(cols,spanX));item.spanY=Math.max(1,Math.min(rows,spanY));item.page=currentPage;
        int[] pos=findFreeOnPage(currentPage,item.spanX,item.spanY,null,0,0);
        if(pos==null){
            int p=ensureNextPageForInsert(item.spanX,item.spanY);item.page=p;
            pos=findFreeOnPage(p,item.spanX,item.spanY,null,0,0);
        }
        if(pos==null){callbacks.onNoSpace();return false;}
        item.cellX=pos[0];item.cellY=pos[1];store.put(item);rebuild();showPage(item.page,true);return true;
    }

    public boolean addWidgetAt(int widgetId,int spanX,int spanY,int page,int x,int y){
        ClassicLayoutStore.Item item=new ClassicLayoutStore.Item();item.type=ClassicLayoutStore.TYPE_WIDGET;
        item.appWidgetId=widgetId;item.spanX=Math.max(1,Math.min(cols,spanX));item.spanY=Math.max(1,Math.min(rows,spanY));
        return placeNewItemAt(item,page,x,y);
    }


    public boolean addWidgetL3(int widgetId,int spanX,int spanY,int minSpanX,int minSpanY){
        int page=Math.max(0,currentPage);while(true){
            store.ensurePages(page+1);while(page>=pages.size())appendEmptyPage();ClassicCellLayout grid=page(page);if(grid==null)return false;
            L3ReorderEngine.Solution sol=l3ReorderSolution(page,null,grid.getWidth()/2f,grid.getHeight()/2f,minSpanX,minSpanY,spanX,spanY);
            if(sol!=null&&sol.isSolution){return addWidgetAtL3(widgetId,sol.spanX,sol.spanY,minSpanX,minSpanY,page,sol.cellX,sol.cellY);}
            if(page>=pages.size()-1)appendEmptyPage();page++;if(page>20)return false;
        }
    }

    public boolean addWidgetAtL3(int widgetId,int spanX,int spanY,int minSpanX,int minSpanY,int page,int x,int y){
        page=Math.max(0,page);store.ensurePages(page+1);while(page>=pages.size())appendEmptyPage();ClassicCellLayout grid=page(page);if(grid==null)return false;
        int px=Math.round((x+Math.max(1,spanX)/2f)*grid.cellWidth()),py=Math.round((y+Math.max(1,spanY)/2f)*grid.cellHeight());
        L3ReorderEngine.Solution sol=l3ReorderSolution(page,null,px,py,minSpanX,minSpanY,spanX,spanY);if(sol==null||!sol.isSolution)return false;
        ClassicLayoutStore.Item item=new ClassicLayoutStore.Item();item.type=ClassicLayoutStore.TYPE_WIDGET;item.appWidgetId=widgetId;item.spanX=sol.spanX;item.spanY=sol.spanY;item.page=page;item.cellX=sol.cellX;item.cellY=sol.cellY;
        List<ClassicLayoutStore.Item> plan=l3ItemsForSolution(page,null,item,sol);if(plan==null)return false;store.putAll(plan);store.trimTrailingEmptyPages();rebuild();showPage(Math.min(page,pages.size()-1),false);return true;
    }

    private boolean placeNewItemAt(ClassicLayoutStore.Item item,int page,int x,int y){
        if(item==null)return false;page=Math.max(0,page);store.ensurePages(page+1);while(page>=pages.size())appendEmptyPage();
        ClassicCellLayout grid=page(page);if(grid==null)return false;int sx=Math.max(1,Math.min(cols,item.spanX)),sy=Math.max(1,Math.min(rows,item.spanY));
        x=Math.max(0,Math.min(cols-sx,x));y=Math.max(0,Math.min(rows-sy,y));int px=Math.round((x+sx/2f)*grid.cellWidth()),py=Math.round((y+sy/2f)*grid.cellHeight());
        L3ReorderEngine.Solution sol=l3ReorderSolution(page,null,px,py,sx,sy,sx,sy);if(sol==null||!sol.isSolution)return false;
        item.spanX=sx;item.spanY=sy;List<ClassicLayoutStore.Item> plan=l3ItemsForSolution(page,null,item,sol);if(plan==null)return false;
        store.putAll(plan);store.trimTrailingEmptyPages();rebuild();showPage(Math.min(page,pages.size()-1),false);return true;
    }

    public void removeItem(String itemId){store.remove(itemId);rebuild();}

    public boolean resizeItem(String itemId,int newSpanX,int newSpanY){
        ClassicLayoutStore.Item item=store.find(itemId);if(item==null)return false;
        return resizeItemAnchored(itemId,item.cellX,item.cellY,newSpanX,newSpanY);
    }

    public boolean resizeItemAnchored(String itemId,int newCellX,int newCellY,int newSpanX,int newSpanY){
        ClassicLayoutStore.Item item=store.find(itemId);if(item==null)return false;
        newSpanX=Math.max(1,Math.min(cols,newSpanX));newSpanY=Math.max(1,Math.min(rows,newSpanY));newCellX=Math.max(0,Math.min(cols-newSpanX,newCellX));newCellY=Math.max(0,Math.min(rows-newSpanY,newCellY));
        ClassicCellLayout grid=page(item.page);if(grid==null)return false;int px=Math.round((newCellX+newSpanX/2f)*grid.cellWidth()),py=Math.round((newCellY+newSpanY/2f)*grid.cellHeight());
        L3ReorderEngine.Solution sol=l3ReorderSolution(item.page,item.id,px,py,newSpanX,newSpanY,newSpanX,newSpanY);if(sol==null||!sol.isSolution)return false;
        ClassicLayoutStore.Item moving=item.copy();moving.spanX=newSpanX;moving.spanY=newSpanY;List<ClassicLayoutStore.Item> plan=l3ItemsForSolution(item.page,item.id,moving,sol);if(plan==null)return false;
        store.putAll(plan);rebuild();showPage(item.page,false);return true;
    }

    /** Compatibility move API, now backed by the Launcher3 reorder engine. */
    public boolean moveItemTo(String itemId,int targetPage,int targetX,int targetY){
        ClassicLayoutStore.Item original=store.find(itemId);if(original==null)return false;targetPage=Math.max(0,targetPage);store.ensurePages(targetPage+1);while(targetPage>=pages.size())appendEmptyPage();
        ClassicCellLayout grid=page(targetPage);if(grid==null)return false;int sx=Math.max(1,original.spanX),sy=Math.max(1,original.spanY);targetX=Math.max(0,Math.min(cols-sx,targetX));targetY=Math.max(0,Math.min(rows-sy,targetY));
        int px=Math.round((targetX+sx/2f)*grid.cellWidth()),py=Math.round((targetY+sy/2f)*grid.cellHeight());L3ReorderEngine.Solution sol=l3ReorderSolution(targetPage,original.id,px,py,sx,sy,sx,sy);if(sol==null||!sol.isSolution)return false;
        List<ClassicLayoutStore.Item> plan=l3ItemsForSolution(targetPage,original.id,original.copy(),sol);if(plan==null)return false;store.putAll(plan);store.trimTrailingEmptyPages();rebuild();showPage(Math.min(targetPage,pages.size()-1),false);return true;
    }

    /**
     * Starts an in-process widget drag. Launcher3 does not use Android's system drag shadow for
     * Workspace widgets; DragController owns the pointer/DragView and CellLayout only receives
     * continuous reorder coordinates.
     */
    public void startInternalWidgetDrag(String itemId){
        ClassicLayoutStore.Item item=store.find(itemId);if(item==null||!ClassicLayoutStore.TYPE_WIDGET.equals(item.type))return;
        cancelWorkspaceLongPress();cancelEdge();dragging=true;internalWidgetDrag=true;
        for(ClassicCellLayout p:pages)p.clearDropPreview();
    }

    public void startInternalPendingWidgetDrag(){
        cancelWorkspaceLongPress();cancelEdge();dragging=true;internalWidgetDrag=true;
        for(ClassicCellLayout p:pages)p.clearDropPreview();
    }

    /** Launcher3-style internal drag lifecycle for app and folder shortcuts. */
    public void startInternalItemDrag(DragPayload payload){
        if(payload==null||payload.kind==DragPayload.KIND_WIDGET)return;
        cancelWorkspaceLongPress();cancelEdge();dragging=true;
        for(ClassicCellLayout p:pages)p.clearDropPreview();
        callbacks.onDragStateChanged(true,payload);
    }

    /**
     * Continuous CellLayout/ReorderAlgorithm preview for app/folder drags. This intentionally
     * uses the same Launcher3 reorder path as widgets.
     */
    public void previewItemL3(DragPayload payload,float x,float y){
        if(payload==null||payload.kind==DragPayload.KIND_WIDGET)return;
        ClassicCellLayout grid=currentCellLayout();if(grid==null)return;updateEdge(x);
        ClassicLayoutStore.Item existing=payload.kind==DragPayload.KIND_EXISTING?store.find(payload.itemId):null;
        if(payload.kind==DragPayload.KIND_EXISTING&&existing==null)return;
        int sx=existing==null?1:Math.max(1,existing.spanX),sy=existing==null?1:Math.max(1,existing.spanY);
        int[] cell=grid.cellFromPoint(x,y);int tx=Math.max(0,Math.min(cols-sx,cell[0])),ty=Math.max(0,Math.min(rows-sy,cell[1]));
        boolean folderTarget=(existing!=null&&ClassicLayoutStore.TYPE_APP.equals(existing.type)&&folderTargetAt(grid,tx,ty,x,y,existing.id)!=null)
                ||(payload.kind==DragPayload.KIND_APP&&folderTargetAt(grid,tx,ty,x,y,null)!=null);
        if(folderTarget){grid.clearReorderPreview();grid.showDropPreview(tx,ty,sx,sy,true);return;}
        String movingId=existing==null?null:existing.id;
        L3ReorderEngine.Solution sol=l3ReorderSolution(currentPage,movingId,x,y,sx,sy,sx,sy);
        boolean valid=sol!=null&&sol.isSolution;
        grid.showDropPreview(valid?sol.cellX:tx,valid?sol.cellY:ty,sx,sy,valid);
        if(!valid){grid.clearReorderPreview();return;}
        HashMap<String,int[]> targets=new HashMap<>();
        for(Map.Entry<String,L3ReorderEngine.CellAndSpan> e:sol.map.entrySet())targets.put(e.getKey(),new int[]{e.getValue().cellX,e.getValue().cellY});
        grid.showReorderPreview(targets);
    }

    /** Commit an app/folder drag using the same ReorderAlgorithm engine used by widgets. */
    public boolean dropItemL3(DragPayload payload,float x,float y){
        if(payload==null||payload.kind==DragPayload.KIND_WIDGET)return false;cancelEdge();
        ClassicCellLayout grid=currentCellLayout();if(grid==null)return false;
        ClassicLayoutStore.Item existing=payload.kind==DragPayload.KIND_EXISTING?store.find(payload.itemId):null;
        if(payload.kind==DragPayload.KIND_EXISTING&&existing==null)return false;
        int sx=existing==null?1:Math.max(1,existing.spanX),sy=existing==null?1:Math.max(1,existing.spanY);
        int[] cell=grid.cellFromPoint(x,y);boolean ok=false;
        if(existing!=null&&ClassicLayoutStore.TYPE_APP.equals(existing.type)&&tryFolderDropExisting(existing,grid,cell[0],cell[1],x,y))ok=true;
        else if(payload.kind==DragPayload.KIND_APP&&tryFolderDropExternal(payload,grid,cell[0],cell[1],x,y))ok=true;
        else{
            String movingId=existing==null?null:existing.id;
            L3ReorderEngine.Solution sol=l3ReorderSolution(currentPage,movingId,x,y,sx,sy,sx,sy);
            if(sol!=null&&sol.isSolution){
                ClassicLayoutStore.Item moving;
                if(existing!=null)moving=existing.copy();
                else{moving=new ClassicLayoutStore.Item();moving.type=ClassicLayoutStore.TYPE_APP;moving.packageName=payload.packageName;moving.className=payload.className;moving.spanX=1;moving.spanY=1;}
                List<ClassicLayoutStore.Item> plan=l3ItemsForSolution(currentPage,movingId,moving,sol);
                if(plan!=null){store.putAll(plan);store.trimTrailingEmptyPages();rebuild();showPage(Math.min(currentPage,pages.size()-1),false);ok=true;}
            }
        }
        payload.dropAccepted=ok;grid=currentCellLayout();if(grid!=null)grid.clearDropPreview();
        if(ok&&payload.kind==DragPayload.KIND_APP)callbacks.onExternalAppCommitted(payload);
        if(!ok)callbacks.onNoSpace();return ok;
    }

    /** Completes an internal app/folder drag and clears every transient reorder state. */
    public void finishInternalItemDrag(DragPayload payload,boolean accepted){
        cancelEdge();dragging=false;for(ClassicCellLayout p:pages)p.clearDropPreview();
        if(payload!=null)payload.dropAccepted=accepted;callbacks.onDragStateChanged(false,payload);
    }

    public boolean previewExistingWidgetL3(String itemId,float x,float y,int minSpanX,int minSpanY){
        ClassicLayoutStore.Item item=store.find(itemId);ClassicCellLayout grid=currentCellLayout();
        if(item==null||grid==null||!ClassicLayoutStore.TYPE_WIDGET.equals(item.type))return false;
        updateEdge(x);
        L3ReorderEngine.Solution sol=l3ReorderSolution(currentPage,item.id,x,y,minSpanX,minSpanY,item.spanX,item.spanY);
        int[] c=grid.cellFromPoint(x,y);int tx=Math.max(0,Math.min(cols-item.spanX,c[0])),ty=Math.max(0,Math.min(rows-item.spanY,c[1]));
        boolean valid=sol!=null&&sol.isSolution;grid.showDropPreview(valid?sol.cellX:tx,valid?sol.cellY:ty,valid?sol.spanX:item.spanX,valid?sol.spanY:item.spanY,valid);
        if(!valid){grid.clearReorderPreview();return false;}
        HashMap<String,int[]> targets=new HashMap<>();for(Map.Entry<String,L3ReorderEngine.CellAndSpan> e:sol.map.entrySet())targets.put(e.getKey(),new int[]{e.getValue().cellX,e.getValue().cellY});
        grid.showReorderPreview(targets);return true;
    }

    public boolean previewPendingWidgetL3(float x,float y,int spanX,int spanY,int minSpanX,int minSpanY){
        ClassicCellLayout grid=currentCellLayout();if(grid==null)return false;updateEdge(x);
        L3ReorderEngine.Solution sol=l3ReorderSolution(currentPage,null,x,y,minSpanX,minSpanY,spanX,spanY);
        int[] c=grid.cellFromPoint(x,y);int tx=Math.max(0,Math.min(cols-Math.max(1,spanX),c[0])),ty=Math.max(0,Math.min(rows-Math.max(1,spanY),c[1]));
        boolean valid=sol!=null&&sol.isSolution;grid.showDropPreview(valid?sol.cellX:tx,valid?sol.cellY:ty,valid?sol.spanX:spanX,valid?sol.spanY:spanY,valid);
        if(!valid){grid.clearReorderPreview();return false;}
        HashMap<String,int[]> targets=new HashMap<>();for(Map.Entry<String,L3ReorderEngine.CellAndSpan> e:sol.map.entrySet())targets.put(e.getKey(),new int[]{e.getValue().cellX,e.getValue().cellY});
        grid.showReorderPreview(targets);return true;
    }

    public boolean dropExistingWidgetL3(String itemId,float x,float y,int minSpanX,int minSpanY){
        cancelEdge();ClassicLayoutStore.Item item=store.find(itemId);boolean ok=item!=null&&ClassicLayoutStore.TYPE_WIDGET.equals(item.type)&&moveWidgetL3(item,currentPage,x,y,minSpanX,minSpanY);
        internalWidgetDrag=false;dragging=false;for(ClassicCellLayout p:pages)p.clearDropPreview();return ok;
    }

    public boolean dropPendingWidgetL3(ComponentName provider,float x,float y,int spanX,int spanY,int minSpanX,int minSpanY){
        cancelEdge();if(provider==null){cancelInternalWidgetDrag();return false;}
        L3ReorderEngine.Solution sol=l3ReorderSolution(currentPage,null,x,y,minSpanX,minSpanY,spanX,spanY);boolean ok=sol!=null&&sol.isSolution;
        for(ClassicCellLayout p:pages)p.clearDropPreview();internalWidgetDrag=false;dragging=false;
        if(ok)callbacks.onWidgetDropRequested(provider,currentPage,sol.cellX,sol.cellY,sol.spanX,sol.spanY);
        return ok;
    }

    public void cancelInternalWidgetDrag(){
        cancelEdge();internalWidgetDrag=false;dragging=false;for(ClassicCellLayout p:pages)p.clearDropPreview();
    }

    public View findItemView(String itemId){
        if(itemId==null)return null;for(ClassicCellLayout grid:pages)for(int i=0;i<grid.getChildCount();i++){View child=grid.getChildAt(i);if(child.getLayoutParams() instanceof ClassicCellLayout.LayoutParams){ClassicCellLayout.LayoutParams lp=(ClassicCellLayout.LayoutParams)child.getLayoutParams();if(itemId.equals(lp.itemId))return child;}}return null;
    }

    /** Legacy entry point intentionally disabled: app/folder drag is owned by L3ItemDragController. */
    @Deprecated public void beginDrag(View source,ClassicLayoutStore.Item item){}
    /** Legacy entry point intentionally disabled: app/folder drag is owned by L3ItemDragController. */
    @Deprecated public void beginDrag(View source,ClassicLayoutStore.Item item,int minSpanX,int minSpanY){}
    /** Legacy entry point intentionally disabled: external app drag is owned by L3ItemDragController. */
    @Deprecated public boolean beginExternalAppDrag(View source,String pkg,String cls,String sourceFolderId,int sourceHotseatIndex){return false;}

    /** Kept only for source compatibility; widgets must use L3WidgetDragController. */
    @Deprecated public boolean beginWidgetProviderDrag(View source,ComponentName provider,int spanX,int spanY){return false;}
    @Deprecated public boolean beginWidgetProviderDrag(View source,ComponentName provider,int spanX,int spanY,int minSpanX,int minSpanY){return false;}

    public void showPage(int page,boolean animate){
        if(pages.isEmpty())return;
        int target=Math.max(0,Math.min(page,pages.size()-1)),old=currentPage;
        currentPage=target;store.setCurrentPage(currentPage);
        for(int i=0;i<pages.size();i++){
            View p=pages.get(i);p.animate().cancel();p.setVisibility(i==target?VISIBLE:GONE);
            p.setAlpha(1f);p.setTranslationX(0f);
        }
        if(animate&&old!=target){
            ClassicCellLayout p=pages.get(target);
            float from=target>old?getWidth()*.18f:-getWidth()*.18f;
            p.setTranslationX(from);p.setAlpha(.7f);
            p.animate().translationX(0f).alpha(1f).setDuration(180).start();
        }
        callbacks.onPageChanged(currentPage,pages.size());
    }

    /** AppWidgetProviderInfo dimensions are pixel dimensions on the current device. */
    public int[] suggestedSpan(int minWidthPx,int minHeightPx){
        ClassicCellLayout grid=currentCellLayout();
        int cellW=grid==null?dp(84):grid.cellWidth();
        int cellH=grid==null?dp(110):grid.cellHeight();
        int sx=Math.max(1,Math.min(cols,(int)Math.ceil(Math.max(1,minWidthPx)/(double)Math.max(1,cellW))));
        int sy=Math.max(1,Math.min(rows,(int)Math.ceil(Math.max(1,minHeightPx)/(double)Math.max(1,cellH))));
        return new int[]{sx,sy};
    }

    @Override public boolean onInterceptTouchEvent(MotionEvent e){
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                downX=e.getX();downY=e.getY();downOnItem=isPointOnItem(downX,downY);
                if(!downOnItem)scheduleLongPress();else cancelWorkspaceLongPress();
                return false;
            case MotionEvent.ACTION_MOVE:
                float dx=e.getX()-downX,dy=e.getY()-downY;
                if(Math.abs(dx)>touchSlop||Math.abs(dy)>touchSlop)cancelWorkspaceLongPress();
                return !downOnItem&&Math.abs(dx)>touchSlop&&Math.abs(dx)>Math.abs(dy)*1.25f;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:cancelWorkspaceLongPress();downOnItem=false;break;
        }
        return false;
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                downX=e.getX();downY=e.getY();downOnItem=isPointOnItem(downX,downY);longPressTriggered=false;
                if(!downOnItem)scheduleLongPress();else cancelWorkspaceLongPress();return true;
            case MotionEvent.ACTION_MOVE:
                float mdx=e.getX()-downX,mdy=e.getY()-downY;
                if(Math.abs(mdx)>touchSlop||Math.abs(mdy)>touchSlop)cancelWorkspaceLongPress();
                return true;
            case MotionEvent.ACTION_UP:
                cancelWorkspaceLongPress();
                if(longPressTriggered){downOnItem=false;return true;}
                float dx=e.getX()-downX,dy=e.getY()-downY;
                downOnItem=false;
                if(Math.abs(dx)>Math.max(dp(48),getWidth()*.16f)&&Math.abs(dx)>Math.abs(dy)*1.25f){
                    if(dx>0&&currentPage>0)showPage(currentPage-1,true);
                    else if(dx>0&&currentPage==0)callbacks.onRequestLegacyHome();
                    else if(dx<0&&currentPage<pages.size()-1)showPage(currentPage+1,true);
                    return true;
                }
                performClick();return true;
            case MotionEvent.ACTION_CANCEL:cancelWorkspaceLongPress();downOnItem=false;return true;
        }
        return true;
    }

    private boolean isPointOnItem(float x,float y){
        ClassicCellLayout grid=currentCellLayout();return grid!=null&&grid.itemAtPoint(x,y)!=null;
    }

    @Override public boolean performClick(){super.performClick();return true;}

    private void scheduleLongPress(){
        cancelWorkspaceLongPress();longPressTriggered=false;if(downOnItem)return;
        longPressRunnable=()->{
            if(dragging||downOnItem)return;
            longPressTriggered=true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            callbacks.onRequestAdd();
        };
        handler.postDelayed(longPressRunnable,ViewConfiguration.getLongPressTimeout());
    }
    private void cancelWorkspaceLongPress(){
        if(longPressRunnable!=null)handler.removeCallbacks(longPressRunnable);
        longPressRunnable=null;
    }

    private String folderTargetAt(ClassicCellLayout grid,int cellX,int cellY,float px,float py,String ignoreId){
        String id=grid.itemAtCell(cellX,cellY,ignoreId);if(id==null)return null;
        ClassicLayoutStore.Item target=store.find(id);if(target==null||target.spanX!=1||target.spanY!=1)return null;
        if(!ClassicLayoutStore.TYPE_APP.equals(target.type)&&!ClassicLayoutStore.TYPE_FOLDER.equals(target.type))return null;
        float cx=(target.cellX+.5f)*grid.cellWidth(),cy=(target.cellY+.5f)*grid.cellHeight();
        if(Math.abs(px-cx)>grid.cellWidth()*.34f||Math.abs(py-cy)>grid.cellHeight()*.34f)return null;
        return id;
    }

    private boolean tryFolderDropExisting(ClassicLayoutStore.Item moving,ClassicCellLayout grid,int x,int y,float px,float py){
        if(moving==null||!ClassicLayoutStore.TYPE_APP.equals(moving.type))return false;
        String targetId=folderTargetAt(grid,x,y,px,py,moving.id);if(targetId==null)return false;
        ClassicLayoutStore.Item target=store.find(targetId);if(target==null)return false;
        boolean ok;
        if(ClassicLayoutStore.TYPE_FOLDER.equals(target.type))ok=store.addItemToFolder(moving.id,target.id);
        else ok=store.createFolderFromApps(moving.id,target.id,target.page,target.cellX,target.cellY)!=null;
        if(ok){rebuild();showPage(Math.min(currentPage,pages.size()-1),false);}return ok;
    }

    private boolean tryFolderDropExternal(DragPayload payload,ClassicCellLayout grid,int x,int y,float px,float py){
        String targetId=folderTargetAt(grid,x,y,px,py,null);if(targetId==null)return false;
        ClassicLayoutStore.Item target=store.find(targetId);if(target==null)return false;
        boolean ok;
        if(ClassicLayoutStore.TYPE_FOLDER.equals(target.type)){
            if(payload.sourceFolderId!=null&&payload.sourceFolderId.equals(target.id)){payload.keepSource=true;return true;}
            ok=store.addComponentToFolder(payload.packageName,payload.className,target.id);
        }else ok=store.createFolderWithExternalApp(target.id,payload.packageName,payload.className,target.page,target.cellX,target.cellY)!=null;
        if(ok){rebuild();showPage(Math.min(currentPage,pages.size()-1),false);}return ok;
    }

    /**
     * Launcher3 CellLayout/ReorderAlgorithm path for widgets. Unlike the older Classic3 make-room
     * logic this can push a touching cluster, move a block, move individual blockers and, for a
     * pending widget, shrink from span toward minSpan exactly in the AOSP order.
     */
    private L3ReorderEngine.Solution l3ReorderSolution(int page,String movingId,float px,float py,
            int minSpanX,int minSpanY,int spanX,int spanY){
        ClassicCellLayout grid=page(page);if(grid==null)return null;
        L3ReorderEngine engine=new L3ReorderEngine(cols,rows,grid.cellWidth(),grid.cellHeight(),
                store.itemsOnPage(page),movingId);
        return engine.calculate(Math.round(px),Math.round(py),minSpanX,minSpanY,spanX,spanY);
    }

    private List<ClassicLayoutStore.Item> l3ItemsForSolution(int page,String movingId,
            ClassicLayoutStore.Item moving,L3ReorderEngine.Solution solution){
        ClassicCellLayout grid=page(page);if(grid==null||solution==null||!solution.isSolution)return null;
        L3ReorderEngine engine=new L3ReorderEngine(cols,rows,grid.cellWidth(),grid.cellHeight(),
                store.itemsOnPage(page),movingId);
        return engine.toItems(solution,moving,page);
    }

    /** Commits an existing widget using Launcher3 reorder semantics. */
    private boolean moveWidgetL3(ClassicLayoutStore.Item original,int targetPage,float px,float py,
            int minSpanX,int minSpanY){
        if(original==null)return false;targetPage=Math.max(0,targetPage);store.ensurePages(targetPage+1);
        while(targetPage>=pages.size())appendEmptyPage();
        L3ReorderEngine.Solution sol=l3ReorderSolution(targetPage,original.id,px,py,minSpanX,minSpanY,original.spanX,original.spanY);
        if(sol==null||!sol.isSolution)return false;
        List<ClassicLayoutStore.Item> plan=l3ItemsForSolution(targetPage,original.id,original.copy(),sol);
        if(plan==null)return false;store.putAll(plan);store.trimTrailingEmptyPages();rebuild();showPage(Math.min(targetPage,pages.size()-1),false);return true;
    }

    /** Preview used by the Launcher3-style widget resize frame. */
    public boolean previewWidgetResize(String itemId,int cellX,int cellY,int spanX,int spanY,int minSpanX,int minSpanY){
        return previewWidgetResize(itemId,cellX,cellY,spanX,spanY,minSpanX,minSpanY,0,0);
    }

    /**
     * Directional resize preview matching CellLayout.createAreaForResize: the requested widget
     * geometry is fixed and only blocking neighbours are pushed/reordered in the active edge
     * direction.
     */
    public boolean previewWidgetResize(String itemId,int cellX,int cellY,int spanX,int spanY,int minSpanX,int minSpanY,int dirX,int dirY){
        ClassicLayoutStore.Item original=store.find(itemId);ClassicCellLayout grid=currentCellLayout();
        if(original==null||grid==null||original.page!=currentPage)return false;
        L3ReorderEngine engine=new L3ReorderEngine(cols,rows,grid.cellWidth(),grid.cellHeight(),store.itemsOnPage(currentPage),itemId);
        L3ReorderEngine.Solution sol=engine.calculateResizeExact(cellX,cellY,spanX,spanY,dirX,dirY);
        if(sol==null||!sol.isSolution){grid.clearReorderPreview();grid.showDropPreview(cellX,cellY,spanX,spanY,false);return false;}
        HashMap<String,int[]> targets=new HashMap<>();for(Map.Entry<String,L3ReorderEngine.CellAndSpan> e:sol.map.entrySet())targets.put(e.getKey(),new int[]{e.getValue().cellX,e.getValue().cellY});
        grid.showDropPreview(sol.cellX,sol.cellY,sol.spanX,sol.spanY,true);grid.showReorderPreview(targets);return true;
    }

    /** Commit resize after the frame settles, mirroring CellLayout.createAreaForResize(commit=true). */
    public boolean commitWidgetResize(String itemId,int cellX,int cellY,int spanX,int spanY,int minSpanX,int minSpanY){
        return commitWidgetResize(itemId,cellX,cellY,spanX,spanY,minSpanX,minSpanY,0,0);
    }

    public boolean commitWidgetResize(String itemId,int cellX,int cellY,int spanX,int spanY,int minSpanX,int minSpanY,int dirX,int dirY){
        ClassicLayoutStore.Item original=store.find(itemId);ClassicCellLayout grid=currentCellLayout();
        if(original==null||grid==null||original.page!=currentPage)return false;
        L3ReorderEngine engine=new L3ReorderEngine(cols,rows,grid.cellWidth(),grid.cellHeight(),store.itemsOnPage(currentPage),itemId);
        L3ReorderEngine.Solution sol=engine.calculateResizeExact(cellX,cellY,spanX,spanY,dirX,dirY);
        if(sol==null||!sol.isSolution)return false;
        ClassicLayoutStore.Item moving=original.copy();moving.cellX=sol.cellX;moving.cellY=sol.cellY;moving.spanX=sol.spanX;moving.spanY=sol.spanY;
        List<ClassicLayoutStore.Item> plan=engine.toItems(sol,moving,currentPage);if(plan==null)return false;
        store.putAll(plan);
        HashMap<String,ClassicLayoutStore.Item> committed=new HashMap<>();for(ClassicLayoutStore.Item i:plan)committed.put(i.id,i);
        for(int i=0;i<grid.getChildCount();i++){View child=grid.getChildAt(i);if(!(child.getLayoutParams() instanceof ClassicCellLayout.LayoutParams))continue;ClassicCellLayout.LayoutParams lp=(ClassicCellLayout.LayoutParams)child.getLayoutParams();ClassicLayoutStore.Item ci=committed.get(lp.itemId);if(ci==null)continue;lp.cellX=ci.cellX;lp.cellY=ci.cellY;lp.spanX=ci.spanX;lp.spanY=ci.spanY;child.setLayoutParams(lp);child.setTranslationX(0f);child.setTranslationY(0f);}
        grid.clearDropPreview();grid.requestLayout();callbacks.onLayoutPersisted();return true;
    }

    public void clearWidgetReorderPreview(){ClassicCellLayout grid=currentCellLayout();if(grid!=null)grid.clearDropPreview();}

    private void updateEdge(float x){
        int dir=x<dp(42)?-1:(x>getWidth()-dp(42)?1:0);
        if(dir==0){cancelEdge();return;}
        if(edgeDirection==dir&&edgeRunnable!=null)return;
        cancelEdge();edgeDirection=dir;
        edgeRunnable=()->{
            if(edgeDirection<0&&currentPage>0){
                showPage(currentPage-1,true);
            }else if(edgeDirection>0){
                if(currentPage>=pages.size()-1&&store.pageHasItems(currentPage))appendEmptyPage();
                if(currentPage<pages.size()-1)showPage(currentPage+1,true);
            }
            edgeRunnable=null;
        };
        handler.postDelayed(edgeRunnable,380);
    }

    private void cancelEdge(){
        if(edgeRunnable!=null)handler.removeCallbacks(edgeRunnable);
        edgeRunnable=null;edgeDirection=0;
    }

    private int ensureNextPageForInsert(int sx,int sy){
        for(int p=currentPage+1;p<pages.size();p++)
            if(findFreeOnPage(p,sx,sy,null,0,0)!=null)return p;
        int p=pages.size();appendEmptyPage();return p;
    }

    private int[] findFreeOnPage(int page,int sx,int sy,String ignore,int x,int y){
        ClassicCellLayout p=page(page);return p==null?null:p.nearestFree(x,y,sx,sy,ignore);
    }
    private ClassicCellLayout page(int page){return page>=0&&page<pages.size()?pages.get(page):null;}

    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
