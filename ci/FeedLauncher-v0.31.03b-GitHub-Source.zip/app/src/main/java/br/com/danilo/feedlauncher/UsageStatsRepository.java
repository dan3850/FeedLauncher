package br.com.danilo.feedlauncher;

import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v0.30.40 — consulta UsageStats fora da thread principal e mantém um snapshot local curto.
 * O repositório não conhece Views nem layout; entrega apenas pacote + tempo em primeiro plano.
 */
final class UsageStatsRepository {
    static final String KEY_TODAY = "runtimeUsageTodayCache";
    static final String KEY_YESTERDAY = "runtimeUsageYesterdayCache";
    static final String KEY_TODAY_AT = "runtimeUsageTodayCacheAt";
    static final String KEY_YESTERDAY_AT = "runtimeUsageYesterdayCacheAt";
    static final String KEY_TODAY_DAY = "runtimeUsageTodayDayStart";
    static final String KEY_YESTERDAY_DAY = "runtimeUsageYesterdayDayStart";

    static final class Entry {
        String packageName = "";
        long foregroundMs = 0L;
    }

    static final class Snapshot {
        long dayStart = 0L;
        long savedAt = 0L;
        final ArrayList<Entry> entries = new ArrayList<>();
    }

    interface Listener {
        void onLoaded(Snapshot today, Snapshot yesterday, long queryMs);
        void onError(Throwable error);
    }

    private final Context appContext;
    private final SharedPreferences prefs;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean inFlight = new AtomicBoolean(false);

    UsageStatsRepository(Context context, SharedPreferences prefs) {
        this.appContext = context.getApplicationContext();
        this.prefs = prefs;
    }

    boolean isInFlight() { return inFlight.get(); }

    Snapshot readToday(long expectedDayStart) { return readSnapshot(KEY_TODAY, KEY_TODAY_AT, KEY_TODAY_DAY, expectedDayStart); }
    Snapshot readYesterday(long expectedDayStart) { return readSnapshot(KEY_YESTERDAY, KEY_YESTERDAY_AT, KEY_YESTERDAY_DAY, expectedDayStart); }

    boolean requestRefresh(final long todayStart, final Listener listener) {
        if (!inFlight.compareAndSet(false, true)) return false;
        executor.execute(() -> {
            long started = android.os.SystemClock.uptimeMillis();
            try {
                long now = System.currentTimeMillis();
                long yesterdayStart = todayStart - 24L * 60L * 60L * 1000L;
                Snapshot today = queryRange(todayStart, now);
                today.dayStart = todayStart;
                today.savedAt = System.currentTimeMillis();
                Snapshot yesterday = queryRange(yesterdayStart, todayStart);
                yesterday.dayStart = yesterdayStart;
                yesterday.savedAt = System.currentTimeMillis();
                saveSnapshot(KEY_TODAY, KEY_TODAY_AT, KEY_TODAY_DAY, today);
                saveSnapshot(KEY_YESTERDAY, KEY_YESTERDAY_AT, KEY_YESTERDAY_DAY, yesterday);
                long took = Math.max(0L, android.os.SystemClock.uptimeMillis() - started);
                mainHandler.post(() -> {
                    inFlight.set(false);
                    if (listener != null) listener.onLoaded(today, yesterday, took);
                });
            } catch (Throwable error) {
                mainHandler.post(() -> {
                    inFlight.set(false);
                    if (listener != null) listener.onError(error);
                });
            }
        });
        return true;
    }

    void clear() {
        if (prefs != null) {
            prefs.edit().remove(KEY_TODAY).remove(KEY_YESTERDAY)
                    .remove(KEY_TODAY_AT).remove(KEY_YESTERDAY_AT)
                    .remove(KEY_TODAY_DAY).remove(KEY_YESTERDAY_DAY).apply();
        }
    }

    void shutdown() {
        try { executor.shutdownNow(); } catch (Throwable ignored) {}
    }

    private Snapshot queryRange(long start, long end) {
        Snapshot snapshot = new Snapshot();
        UsageStatsManager manager = (UsageStatsManager) appContext.getSystemService(Context.USAGE_STATS_SERVICE);
        if (manager == null) return snapshot;
        List<UsageStats> stats = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end);
        HashMap<String, Long> totals = new HashMap<>();
        if (stats != null) {
            for (UsageStats item : stats) {
                if (item == null || item.getPackageName() == null) continue;
                long ms = item.getTotalTimeInForeground();
                if (ms <= 0L) continue;
                String pkg = item.getPackageName();
                Long old = totals.get(pkg);
                totals.put(pkg, (old == null ? 0L : old) + ms);
            }
        }
        for (Map.Entry<String, Long> item : totals.entrySet()) {
            Entry e = new Entry();
            e.packageName = item.getKey();
            e.foregroundMs = item.getValue();
            snapshot.entries.add(e);
        }
        Collections.sort(snapshot.entries, (a, b) -> Long.compare(b.foregroundMs, a.foregroundMs));
        return snapshot;
    }

    private Snapshot readSnapshot(String dataKey, String atKey, String dayKey, long expectedDayStart) {
        Snapshot snapshot = new Snapshot();
        if (prefs == null) return snapshot;
        try {
            long savedDay = prefs.getLong(dayKey, 0L);
            if (savedDay != expectedDayStart) return snapshot;
            snapshot.dayStart = savedDay;
            snapshot.savedAt = prefs.getLong(atKey, 0L);
            JSONArray array = new JSONArray(prefs.getString(dataKey, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                String pkg = o.optString("p", "");
                long ms = o.optLong("m", 0L);
                if (pkg.isEmpty() || ms <= 0L) continue;
                Entry e = new Entry();
                e.packageName = pkg;
                e.foregroundMs = ms;
                snapshot.entries.add(e);
            }
            Collections.sort(snapshot.entries, (a, b) -> Long.compare(b.foregroundMs, a.foregroundMs));
        } catch (Throwable ignored) {
            snapshot.entries.clear();
            snapshot.savedAt = 0L;
        }
        return snapshot;
    }

    private void saveSnapshot(String dataKey, String atKey, String dayKey, Snapshot snapshot) {
        if (prefs == null || snapshot == null) return;
        try {
            JSONArray array = new JSONArray();
            int max = Math.min(64, snapshot.entries.size());
            for (int i = 0; i < max; i++) {
                Entry e = snapshot.entries.get(i);
                JSONObject o = new JSONObject();
                o.put("p", e.packageName);
                o.put("m", e.foregroundMs);
                array.put(o);
            }
            prefs.edit().putString(dataKey, array.toString()).putLong(atKey, snapshot.savedAt)
                    .putLong(dayKey, snapshot.dayStart).apply();
        } catch (Throwable ignored) {}
    }
}
