/*
 * Portions adapted from AOSP Launcher3 ReorderAlgorithm.java / CellLayout.java.
 * Copyright (C) 2023 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0.
 */
package br.com.danilo.feedlauncher.classic;

import android.graphics.Rect;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Small, dependency-free port of Launcher3's CellLayout/ReorderAlgorithm mechanics.
 *
 * This class intentionally keeps the AOSP algorithmic model (drop-in-place, push cluster,
 * block move, individual move, closest empty space and alternating span shrink) while adapting
 * it to ClassicLayoutStore items instead of Launcher3 View/ItemInfo objects.
 */
final class L3ReorderEngine {
    static class CellAndSpan {
        int cellX=-1,cellY=-1,spanX=1,spanY=1;
        CellAndSpan(){}
        CellAndSpan(int x,int y,int sx,int sy){cellX=x;cellY=y;spanX=sx;spanY=sy;}
        CellAndSpan copy(){return new CellAndSpan(cellX,cellY,spanX,spanY);}
    }

    static final class Solution extends CellAndSpan {
        final LinkedHashMap<String,CellAndSpan> map=new LinkedHashMap<>();
        final ArrayList<String> sortedIds=new ArrayList<>();
        ArrayList<String> intersectingIds=new ArrayList<>();
        boolean isSolution=false;
        int area(){return spanX*spanY;}
        Solution deepCopy(){
            Solution s=new Solution();s.cellX=cellX;s.cellY=cellY;s.spanX=spanX;s.spanY=spanY;s.isSolution=isSolution;
            for(Map.Entry<String,CellAndSpan> e:map.entrySet())s.map.put(e.getKey(),e.getValue().copy());
            s.sortedIds.addAll(sortedIds);s.intersectingIds=new ArrayList<>(intersectingIds);return s;
        }
    }

    private final int countX,countY,cellW,cellH;
    private final ArrayList<ClassicLayoutStore.Item> originals=new ArrayList<>();
    private final HashMap<String,ClassicLayoutStore.Item> byId=new HashMap<>();
    private final int[] directionVector=new int[]{1,0};

    L3ReorderEngine(int countX,int countY,int cellW,int cellH,List<ClassicLayoutStore.Item> pageItems,String ignoreId){
        this.countX=Math.max(1,countX);this.countY=Math.max(1,countY);this.cellW=Math.max(1,cellW);this.cellH=Math.max(1,cellH);
        if(pageItems!=null){
            for(ClassicLayoutStore.Item src:pageItems){
                if(src==null||src.id==null||(ignoreId!=null&&ignoreId.equals(src.id)))continue;
                ClassicLayoutStore.Item c=src.copy();originals.add(c);byId.put(c.id,c);
            }
        }
    }

    Solution calculate(int pixelX,int pixelY,int minSpanX,int minSpanY,int spanX,int spanY){
        minSpanX=clamp(minSpanX,1,countX);minSpanY=clamp(minSpanY,1,countY);
        spanX=clamp(spanX,minSpanX,countX);spanY=clamp(spanY,minSpanY,countY);
        getDirectionVectorForDrop(pixelX,pixelY,spanX,spanY,directionVector);
        Solution dropInPlace=dropInPlaceSolution(pixelX,pixelY,spanX,spanY);
        Solution swap=findReorderSolution(pixelX,pixelY,minSpanX,minSpanY,spanX,spanY,directionVector,true);
        Solution closest=closestEmptySpaceReorder(pixelX,pixelY,minSpanX,minSpanY,spanX,spanY);
        if(swap!=null&&swap.isSolution&&(closest==null||!closest.isSolution||swap.area()>=closest.area()))return swap;
        if(closest!=null&&closest.isSolution)return closest;
        if(dropInPlace!=null&&dropInPlace.isSolution)return dropInPlace;
        return null;
    }

    /**
     * Launcher3 CellLayout.createAreaForResize-style path: the widget's requested cell/span stay
     * fixed and only intersecting neighbours are rearranged, using the resize edge direction.
     * Unlike a normal drop this must never relocate or shrink the widget itself.
     */
    Solution calculateResizeExact(int cellX,int cellY,int spanX,int spanY,int dirX,int dirY){
        spanX=clamp(spanX,1,countX);spanY=clamp(spanY,1,countY);
        cellX=clamp(cellX,0,Math.max(0,countX-spanX));cellY=clamp(cellY,0,Math.max(0,countY-spanY));
        int[] direction=new int[]{Integer.signum(dirX),Integer.signum(dirY)};
        if(direction[0]==0&&direction[1]==0){direction[0]=1;}
        Solution solution=copyCurrentState();
        boolean[][] occupied=buildOccupied(solution);
        if(!rearrangementExists(cellX,cellY,spanX,spanY,direction,solution,occupied)){
            solution.isSolution=false;return solution;
        }
        solution.isSolution=true;solution.cellX=cellX;solution.cellY=cellY;solution.spanX=spanX;solution.spanY=spanY;
        return solution;
    }

    private Solution findReorderSolution(int pixelX,int pixelY,int minSpanX,int minSpanY,int spanX,int spanY,int[] direction,boolean decX){
        return findReorderSolutionRecursive(pixelX,pixelY,minSpanX,minSpanY,spanX,spanY,new int[]{direction[0],direction[1]},decX);
    }

    private Solution findReorderSolutionRecursive(int pixelX,int pixelY,int minSpanX,int minSpanY,int spanX,int spanY,int[] direction,boolean decX){
        Solution solution=copyCurrentState();
        boolean[][] occupied=buildOccupied(solution);
        int[] result=findNearestAreaIgnoreOccupied(pixelX,pixelY,spanX,spanY);
        boolean success=result[0]>=0&&rearrangementExists(result[0],result[1],spanX,spanY,direction,solution,occupied);
        if(!success){
            if(spanX>minSpanX&&(minSpanY==spanY||decX))return findReorderSolutionRecursive(pixelX,pixelY,minSpanX,minSpanY,spanX-1,spanY,direction,false);
            if(spanY>minSpanY)return findReorderSolutionRecursive(pixelX,pixelY,minSpanX,minSpanY,spanX,spanY-1,direction,true);
            solution.isSolution=false;return solution;
        }
        solution.isSolution=true;solution.cellX=result[0];solution.cellY=result[1];solution.spanX=spanX;solution.spanY=spanY;return solution;
    }

    private Solution copyCurrentState(){
        Solution s=new Solution();
        ArrayList<ClassicLayoutStore.Item> sorted=new ArrayList<>(originals);
        Collections.sort(sorted,new Comparator<ClassicLayoutStore.Item>(){
            @Override public int compare(ClassicLayoutStore.Item a,ClassicLayoutStore.Item b){
                if(a.cellX!=b.cellX)return Integer.compare(a.cellX,b.cellX);
                if(a.cellY!=b.cellY)return Integer.compare(a.cellY,b.cellY);
                return a.id.compareTo(b.id);
            }
        });
        for(ClassicLayoutStore.Item i:sorted){s.map.put(i.id,new CellAndSpan(i.cellX,i.cellY,i.spanX,i.spanY));s.sortedIds.add(i.id);}return s;
    }

    private boolean[][] buildOccupied(Solution s){
        boolean[][] out=new boolean[countX][countY];
        for(CellAndSpan c:s.map.values())mark(out,c.cellX,c.cellY,c.spanX,c.spanY,true);return out;
    }

    private boolean rearrangementExists(int cellX,int cellY,int spanX,int spanY,int[] direction,Solution solution,boolean[][] occupied){
        if(cellX<0||cellY<0)return false;
        Rect desired=new Rect(cellX,cellY,cellX+spanX,cellY+spanY);
        ArrayList<String> intersecting=new ArrayList<>();
        for(String id:solution.sortedIds){
            CellAndSpan c=solution.map.get(id);if(c==null)continue;
            Rect r=new Rect(c.cellX,c.cellY,c.cellX+c.spanX,c.cellY+c.spanY);
            if(Rect.intersects(desired,r))intersecting.add(id);
        }
        solution.intersectingIds=intersecting;
        if(attemptPushInDirection(intersecting,desired,direction,solution,occupied))return true;
        if(addViewsToTempLocation(intersecting,desired,direction,solution,occupied))return true;
        for(String id:intersecting)if(!addViewToTempLocation(id,desired,direction,solution,occupied))return false;
        return true;
    }

    private boolean addViewToTempLocation(String id,Rect desired,int[] direction,Solution state,boolean[][] occupied){
        CellAndSpan c=state.map.get(id);if(c==null)return false;
        mark(occupied,c.cellX,c.cellY,c.spanX,c.spanY,false);mark(occupied,desired.left,desired.top,desired.width(),desired.height(),true);
        int[] loc=findNearestArea(c.cellX,c.cellY,c.spanX,c.spanY,direction,occupied,null);
        boolean ok=loc[0]>=0;
        if(ok){c.cellX=loc[0];c.cellY=loc[1];}
        mark(occupied,c.cellX,c.cellY,c.spanX,c.spanY,true);return ok;
    }

    private boolean attemptPushInDirection(ArrayList<String> ids,Rect desired,int[] direction,Solution state,boolean[][] occupied){
        if(ids.isEmpty())return true;
        int[] d=new int[]{direction[0],direction[1]};
        if(Math.abs(d[0])+Math.abs(d[1])>1){
            for(int j=0;j<2;j++){
                for(int i=1;i>=0;i--){int temp=d[i];d[i]=0;if(pushViewsToTempLocation(ids,desired,d,state,occupied))return true;d[i]=temp;}
                d[0]*=-1;d[1]*=-1;
            }
        }else{
            for(int j=0;j<2;j++){
                for(int i=0;i<2;i++){if(pushViewsToTempLocation(ids,desired,d,state,occupied))return true;d[0]*=-1;d[1]*=-1;}
                int t=d[1];d[1]=d[0];d[0]=t;
            }
        }
        return false;
    }

    private boolean pushViewsToTempLocation(ArrayList<String> initial,Rect desired,int[] direction,Solution state,boolean[][] occupied){
        Solution before=state.deepCopy();boolean[][] occBefore=copyGrid(occupied);
        ArrayList<String> cluster=new ArrayList<>(initial);
        Rect clusterRect=boundingRect(cluster,state);
        final int LEFT=1,TOP=2,RIGHT=4,BOTTOM=8;int edge;int distance;
        if(direction[0]<0){edge=LEFT;distance=clusterRect.right-desired.left;}
        else if(direction[0]>0){edge=RIGHT;distance=desired.right-clusterRect.left;}
        else if(direction[1]<0){edge=TOP;distance=clusterRect.bottom-desired.top;}
        else{edge=BOTTOM;distance=desired.bottom-clusterRect.top;}
        if(distance<=0)return false;
        for(String id:cluster){CellAndSpan c=state.map.get(id);mark(occupied,c.cellX,c.cellY,c.spanX,c.spanY,false);}
        while(distance>0){
            ArrayList<String> sorted=new ArrayList<>(state.sortedIds);sortForEdge(sorted,state,edge);
            for(String id:sorted){
                if(cluster.contains(id))continue;
                if(touchesClusterEdge(id,cluster,state,edge)){
                    cluster.add(id);CellAndSpan c=state.map.get(id);mark(occupied,c.cellX,c.cellY,c.spanX,c.spanY,false);
                }
            }
            shiftCluster(cluster,state,edge,1);distance--;
        }
        clusterRect=boundingRect(cluster,state);
        boolean ok=clusterRect.left>=0&&clusterRect.top>=0&&clusterRect.right<=countX&&clusterRect.bottom<=countY;
        if(!ok){restoreState(state,before);restoreGrid(occupied,occBefore);return false;}
        for(String id:cluster){CellAndSpan c=state.map.get(id);mark(occupied,c.cellX,c.cellY,c.spanX,c.spanY,true);}return true;
    }

    private boolean addViewsToTempLocation(ArrayList<String> ids,Rect desired,int[] direction,Solution state,boolean[][] occupied){
        if(ids.isEmpty())return true;
        Rect bounds=boundingRect(ids,state);boolean[][] before=copyGrid(occupied);Solution saved=state.deepCopy();
        for(String id:ids){CellAndSpan c=state.map.get(id);mark(occupied,c.cellX,c.cellY,c.spanX,c.spanY,false);}
        boolean[][] block=new boolean[Math.max(1,bounds.width())][Math.max(1,bounds.height())];
        for(String id:ids){CellAndSpan c=state.map.get(id);mark(block,c.cellX-bounds.left,c.cellY-bounds.top,c.spanX,c.spanY,true);}
        mark(occupied,desired.left,desired.top,desired.width(),desired.height(),true);
        int[] loc=findNearestArea(bounds.left,bounds.top,bounds.width(),bounds.height(),direction,occupied,block);
        if(loc[0]<0){restoreState(state,saved);restoreGrid(occupied,before);return false;}
        int dx=loc[0]-bounds.left,dy=loc[1]-bounds.top;
        for(String id:ids){CellAndSpan c=state.map.get(id);c.cellX+=dx;c.cellY+=dy;mark(occupied,c.cellX,c.cellY,c.spanX,c.spanY,true);}return true;
    }

    private Solution dropInPlaceSolution(int pixelX,int pixelY,int spanX,int spanY){
        int[] pos=findNearestAreaIgnoreOccupied(pixelX,pixelY,spanX,spanY);Solution s=copyCurrentState();
        if(pos[0]<0)return s;Rect r=new Rect(pos[0],pos[1],pos[0]+spanX,pos[1]+spanY);
        for(CellAndSpan c:s.map.values())if(Rect.intersects(r,new Rect(c.cellX,c.cellY,c.cellX+c.spanX,c.cellY+c.spanY)))return s;
        s.isSolution=true;s.cellX=pos[0];s.cellY=pos[1];s.spanX=spanX;s.spanY=spanY;return s;
    }

    private Solution closestEmptySpaceReorder(int pixelX,int pixelY,int minSpanX,int minSpanY,int spanX,int spanY){
        boolean[][] occupied=buildOccupied(copyCurrentState());double best=Double.MAX_VALUE;Solution bestSol=null;
        boolean incX=true; // Same expansion preference as Launcher3: grow X then Y.
        for(int y=0;y<countY;y++)for(int x=0;x<countX;x++){
            if(!isVacant(occupied,x,y,minSpanX,minSpanY))continue;
            int sx=minSpanX,sy=minSpanY;boolean hitX=sx>=spanX,hitY=sy>=spanY;boolean localIncX=incX;
            while(!(hitX&&hitY)){
                if(localIncX&&!hitX){if(isVacant(occupied,x,y,sx+1,sy))sx++;else hitX=true;}
                else if(!hitY){if(isVacant(occupied,x,y,sx,sy+1))sy++;else hitY=true;}
                hitX|=sx>=spanX;hitY|=sy>=spanY;localIncX=!localIncX;
            }
            float cx=(x+.5f)*cellW,cy=(y+.5f)*cellH;double d=Math.hypot(cx-pixelX,cy-pixelY);
            if(bestSol==null||d<best||(d==best&&sx*sy>bestSol.area())){best=d;bestSol=copyCurrentState();bestSol.isSolution=true;bestSol.cellX=x;bestSol.cellY=y;bestSol.spanX=sx;bestSol.spanY=sy;}
        }
        return bestSol==null?new Solution():bestSol;
    }

    private void getDirectionVectorForDrop(int pixelX,int pixelY,int spanX,int spanY,int[] out){
        int[] target=findNearestAreaIgnoreOccupied(pixelX,pixelY,spanX,spanY);if(target[0]<0){out[0]=1;out[1]=0;return;}
        Rect region=new Rect(target[0],target[1],target[0]+spanX,target[1]+spanY);Rect intersect=null;
        Solution s=copyCurrentState();
        for(CellAndSpan c:s.map.values()){
            Rect r=new Rect(c.cellX,c.cellY,c.cellX+c.spanX,c.cellY+c.spanY);
            if(Rect.intersects(region,r)){if(intersect==null)intersect=new Rect(r);else intersect.union(r);}
        }
        if(intersect==null)intersect=new Rect(region);
        int centerX=Math.round((intersect.left+intersect.right)*cellW/2f),centerY=Math.round((intersect.top+intersect.bottom)*cellH/2f);
        int dx=(centerX-pixelX)/Math.max(1,spanX),dy=(centerY-pixelY)/Math.max(1,spanY);
        if(intersect.width()==countX||spanX==countX)dx=0;if(intersect.height()==countY||spanY==countY)dy=0;
        if(dx==0&&dy==0){out[0]=1;out[1]=0;}else computeDirectionVector(dx,dy,out);
    }

    private int[] findNearestAreaIgnoreOccupied(int pixelX,int pixelY,int spanX,int spanY){
        int rx=Math.round(pixelX-cellW*(spanX-1)/2f),ry=Math.round(pixelY-cellH*(spanY-1)/2f);
        double best=Double.MAX_VALUE;int bx=-1,by=-1;
        for(int y=0;y<=countY-spanY;y++)for(int x=0;x<=countX-spanX;x++){
            int cx=Math.round((x+.5f)*cellW),cy=Math.round((y+.5f)*cellH);double d=Math.hypot(cx-rx,cy-ry);
            if(d<best){best=d;bx=x;by=y;}
        }
        return new int[]{bx,by};
    }

    private int[] findNearestArea(int cellX,int cellY,int spanX,int spanY,int[] direction,boolean[][] occupied,boolean[][] block){
        float best=Float.MAX_VALUE;int score=Integer.MIN_VALUE,bx=-1,by=-1;
        for(int y=0;y<=countY-spanY;y++)outer:for(int x=0;x<=countX-spanX;x++){
            for(int i=0;i<spanX;i++)for(int j=0;j<spanY;j++)if(occupied[x+i][y+j]&&(block==null||block[i][j]))continue outer;
            float d=(float)Math.hypot(x-cellX,y-cellY);int[] cur=new int[2];computeDirectionVector(x-cellX,y-cellY,cur);int s=direction[0]*cur[0]+direction[1]*cur[1];
            if(d<best||(d==best&&s>score)){best=d;score=s;bx=x;by=y;}
        }
        return new int[]{bx,by};
    }

    private void computeDirectionVector(float dx,float dy,int[] out){
        if(dx==0f){out[0]=0;out[1]=(int)Math.signum(dy);return;}double angle=Math.atan(dy/dx);out[0]=0;out[1]=0;
        if(Math.abs(Math.cos(angle))>.5)out[0]=(int)Math.signum(dx);if(Math.abs(Math.sin(angle))>.5)out[1]=(int)Math.signum(dy);
    }

    private Rect boundingRect(List<String> ids,Solution s){Rect r=null;for(String id:ids){CellAndSpan c=s.map.get(id);if(c==null)continue;Rect q=new Rect(c.cellX,c.cellY,c.cellX+c.spanX,c.cellY+c.spanY);if(r==null)r=new Rect(q);else r.union(q);}return r==null?new Rect():r;}

    private void sortForEdge(List<String> ids,final Solution s,final int edge){Collections.sort(ids,new Comparator<String>(){@Override public int compare(String a,String b){CellAndSpan l=s.map.get(a),r=s.map.get(b);if(l==null||r==null)return 0;switch(edge){case 1:return (r.cellX+r.spanX)-(l.cellX+l.spanX);case 4:return l.cellX-r.cellX;case 2:return (r.cellY+r.spanY)-(l.cellY+l.spanY);default:return l.cellY-r.cellY;}}});}

    private boolean touchesClusterEdge(String id,List<String> cluster,Solution s,int edge){
        CellAndSpan v=s.map.get(id);if(v==null)return false;
        for(String cid:cluster){CellAndSpan c=s.map.get(cid);if(c==null)continue;
            if(edge==1&&v.cellX+v.spanX==c.cellX&&overlap1D(v.cellY,v.cellY+v.spanY,c.cellY,c.cellY+c.spanY))return true;
            if(edge==4&&v.cellX==c.cellX+c.spanX&&overlap1D(v.cellY,v.cellY+v.spanY,c.cellY,c.cellY+c.spanY))return true;
            if(edge==2&&v.cellY+v.spanY==c.cellY&&overlap1D(v.cellX,v.cellX+v.spanX,c.cellX,c.cellX+c.spanX))return true;
            if(edge==8&&v.cellY==c.cellY+c.spanY&&overlap1D(v.cellX,v.cellX+v.spanX,c.cellX,c.cellX+c.spanX))return true;
        }return false;
    }
    private void shiftCluster(List<String> ids,Solution s,int edge,int d){for(String id:ids){CellAndSpan c=s.map.get(id);if(c==null)continue;if(edge==1)c.cellX-=d;else if(edge==4)c.cellX+=d;else if(edge==2)c.cellY-=d;else c.cellY+=d;}}

    private static boolean overlap1D(int a0,int a1,int b0,int b1){return a0<b1&&a1>b0;}
    private static int clamp(int v,int lo,int hi){return Math.max(lo,Math.min(hi,v));}
    private static void mark(boolean[][] grid,int x,int y,int sx,int sy,boolean value){if(grid==null)return;for(int i=Math.max(0,x);i<x+sx&&i<grid.length;i++)for(int j=Math.max(0,y);j<y+sy&&j<grid[i].length;j++)grid[i][j]=value;}
    private boolean isVacant(boolean[][] grid,int x,int y,int sx,int sy){if(x<0||y<0||sx<1||sy<1||x+sx>countX||y+sy>countY)return false;for(int i=x;i<x+sx;i++)for(int j=y;j<y+sy;j++)if(grid[i][j])return false;return true;}
    private static boolean[][] copyGrid(boolean[][] src){boolean[][] d=new boolean[src.length][];for(int i=0;i<src.length;i++)d[i]=src[i].clone();return d;}
    private static void restoreGrid(boolean[][] dst,boolean[][] src){for(int i=0;i<dst.length;i++)System.arraycopy(src[i],0,dst[i],0,dst[i].length);}
    private static void restoreState(Solution dst,Solution src){dst.map.clear();dst.sortedIds.clear();for(Map.Entry<String,CellAndSpan> e:src.map.entrySet())dst.map.put(e.getKey(),e.getValue().copy());dst.sortedIds.addAll(src.sortedIds);dst.intersectingIds=new ArrayList<>(src.intersectingIds);dst.cellX=src.cellX;dst.cellY=src.cellY;dst.spanX=src.spanX;dst.spanY=src.spanY;dst.isSolution=src.isSolution;}

    List<ClassicLayoutStore.Item> toItems(Solution s,ClassicLayoutStore.Item moving,int page){
        if(s==null||!s.isSolution)return null;ArrayList<ClassicLayoutStore.Item> out=new ArrayList<>();
        for(ClassicLayoutStore.Item original:originals){ClassicLayoutStore.Item c=original.copy();CellAndSpan cs=s.map.get(c.id);if(cs!=null){c.cellX=cs.cellX;c.cellY=cs.cellY;c.spanX=cs.spanX;c.spanY=cs.spanY;}out.add(c);}
        if(moving!=null){ClassicLayoutStore.Item m=moving.copy();m.page=page;m.cellX=s.cellX;m.cellY=s.cellY;m.spanX=s.spanX;m.spanY=s.spanY;out.add(m);}return out;
    }
}
