package br.com.danilo.feedlauncher.classic;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import br.com.danilo.feedlauncher.MainActivity;

/**
 * Launcher3-inspired classic Home using only public Android APIs.
 * The Feed mode is still entirely owned by MainActivity.
 */
public final class ClassicHomeActivity extends Activity implements ClassicWorkspace.Callbacks {
    private static final int HOST_ID=0xF33D;
    private static final int REQ_BIND_WIDGET=7301;
    private static final int REQ_CONFIG_WIDGET=7302;
    private static final int REQ_PROFILE_PHOTO=7303;
    private static final String SEP="\u001f";
    private static final String KEY_HOTSEAT="classic3.hotseat.v1";
    private static final int DEFAULT_COLS=4,DEFAULT_ROWS=5;
    private static final String KEY_GRID_COLS="classic3.grid.cols.v1";
    private static final String KEY_GRID_ROWS="classic3.grid.rows.v1";
    private static final String KEY_HIDDEN_APPS="classic3.hiddenApps.v1";
    private static final String[] LEGACY_CATEGORIES={"Comunicação","Jogos","Produtividade","Entretenimento","Finanças","Fotografia","Ferramentas","Educação","Música","Vídeo","Compras","Viagem"};

    private SharedPreferences prefs;
    private ClassicLayoutStore store;
    private ClassicWorkspace workspace;
    private AppWidgetManager widgetManager;
    private AppWidgetHost widgetHost;
    private FrameLayout root;
    private TextView pageIndicator;
    private LinearLayout hotseat;
    private LinearLayout legacyHeader;
    private ScrollView legacyHomeScroll;
    private LinearLayout legacyHomeContent;
    private EditText legacySearch;
    private LinearLayout legacyChips;
    private FrameLayout legacyGridHost;
    private HorizontalScrollView legacyGridPager;
    private LinearLayout legacyGridPages;
    private TextView legacyGridIndicator;
    private String legacySelectedCategory="Tudo";
    private int legacyGridPage=0;
    private float legacyGridDownX=0f;
    private boolean showingLegacyHome=true;
    private LinearLayout dragTargetBar;
    private View activeOverlay;
    private final Handler uiHandler=new Handler(Looper.getMainLooper());
    private final ArrayList<String> hotseatKeys=new ArrayList<>();
    private int hotseatCapacity=4;
    private int gridCols=DEFAULT_COLS,gridRows=DEFAULT_ROWS;
    private int pendingWidgetId=-1;
    private AppWidgetProviderInfo pendingWidgetInfo;
    private int pendingWidgetPage=-1,pendingWidgetX=-1,pendingWidgetY=-1,pendingWidgetSpanX=1,pendingWidgetSpanY=1;
    private int pendingWidgetMinSpanX=1,pendingWidgetMinSpanY=1;
    private L3WidgetResizeFrame activeResizeFrame;
    private L3WidgetDragController widgetDragController;
    private L3ItemDragController itemDragController;
    private float lastTouchRawX,lastTouchRawY;
    private float density;

    private static final class AppEntry {
        String label,pkg,cls,key; Drawable icon;
    }

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);density=getResources().getDisplayMetrics().density;
        prefs=getSharedPreferences("feed",MODE_PRIVATE);
        gridCols=Math.max(4,Math.min(5,prefs.getInt(KEY_GRID_COLS,DEFAULT_COLS)));
        gridRows=Math.max(5,Math.min(6,prefs.getInt(KEY_GRID_ROWS,DEFAULT_ROWS)));
        if(!"classic".equals(prefs.getString("homeLayoutMode","feed"))){openFeed();return;}
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        getWindow().setStatusBarColor(Color.TRANSPARENT);getWindow().setNavigationBarColor(0xaa07111d);
        if(android.os.Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        widgetManager=AppWidgetManager.getInstance(this);widgetHost=new AppWidgetHost(this,HOST_ID);store=new ClassicLayoutStore(prefs);
        loadHotseatState();
        buildHome();
    }

    @Override public boolean dispatchTouchEvent(MotionEvent ev){
        if(ev!=null){int a=ev.getActionMasked();if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_MOVE){lastTouchRawX=ev.getRawX();lastTouchRawY=ev.getRawY();}}
        if(widgetDragController!=null&&widgetDragController.isDragging())return widgetDragController.onMotionEvent(ev);
        if(itemDragController!=null&&itemDragController.isDragging())return itemDragController.onMotionEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    private void buildHome(){
        root=new FrameLayout(this);root.setBackgroundColor(Color.TRANSPARENT);setContentView(root);

        // Página 0 = a Home clássica original como CASCA VISUAL.
        // Nenhum drag/widget/grid antigo é reutilizado: o motor editável continua sendo Classic3.
        legacyHomeScroll=new ScrollView(this);legacyHomeScroll.setFillViewport(true);legacyHomeScroll.setClipToPadding(false);legacyHomeScroll.setBackgroundColor(Color.TRANSPARENT);
        legacyHomeContent=new LinearLayout(this);legacyHomeContent.setOrientation(LinearLayout.VERTICAL);legacyHomeContent.setClipChildren(false);legacyHomeContent.setClipToPadding(false);legacyHomeContent.setPadding(dp(16),dp(2),dp(16),dp(112));
        legacyHomeScroll.addView(legacyHomeContent,new ScrollView.LayoutParams(-1,-2));
        legacyHeader=buildLegacyHeader();legacyHomeContent.addView(legacyHeader,new LinearLayout.LayoutParams(-1,-2));
        legacyGridHost=new FrameLayout(this);legacyGridHost.setClipChildren(false);legacyGridHost.setClipToPadding(false);legacyHomeContent.addView(legacyGridHost,new LinearLayout.LayoutParams(-1,-2));
        renderLegacyInlineGrid();
        legacyHomeContent.setOnLongClickListener(v->{showHomeEditMenu();return true;});
        root.addView(legacyHomeScroll,new FrameLayout.LayoutParams(-1,-1));

        // Páginas livres = exclusivamente ClassicWorkspace/CellLayout/DragController novos.
        workspace=new ClassicWorkspace(this,store,gridCols,gridRows,this);
        FrameLayout.LayoutParams wp=new FrameLayout.LayoutParams(-1,-1);wp.leftMargin=dp(6);wp.rightMargin=dp(6);wp.topMargin=dp(10);wp.bottomMargin=dp(108);root.addView(workspace,wp);workspace.setVisibility(View.VISIBLE);legacyHomeScroll.bringToFront();
        widgetDragController=new L3WidgetDragController(root,workspace,(itemId,accepted)->{
            if(accepted&&itemId!=null)uiHandler.postDelayed(()->showLauncher3ResizeFrame(itemId),170);
        });
        itemDragController=new L3ItemDragController(root,workspace,new L3ItemDragController.Listener(){
            @Override public void onItemDragMove(ClassicWorkspace.DragPayload payload,float rawX,float rawY){updateInternalDragTargets(rawX,rawY);}
            @Override public boolean onItemDropTarget(ClassicWorkspace.DragPayload payload,float rawX,float rawY){return commitInternalDropTarget(payload,rawX,rawY);}
            @Override public void onItemDragFinished(ClassicWorkspace.DragPayload payload,boolean accepted){resetInternalDragTargets();}
        });

        pageIndicator=new TextView(this);pageIndicator.setTextColor(themeSubtle());pageIndicator.setTextSize(8);pageIndicator.setGravity(Gravity.CENTER);pageIndicator.setShadowLayer(dp(2),0,dp(1),0x99000000);
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(dp(220),dp(24),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);ip.bottomMargin=dp(88);root.addView(pageIndicator,ip);

        // Dock usa os mesmos apps/configuração visual do Clássico antigo, mas drag/drop é Classic3.
        hotseat=new LinearLayout(this);hotseat.setGravity(Gravity.CENTER);hotseat.setClipChildren(false);hotseat.setPadding(dp(8),dp(6),dp(8),dp(6));hotseat.setBackground(legacyCard(false));
        int screenDp=Math.round(getResources().getDisplayMetrics().widthPixels/density);
        int dockWidth=Math.min(Math.max(220,screenDp-28),Math.max(250,18+Math.max(4,gridCols)*(58+Math.max(0,prefs.getInt("dockSpacing",4)))));
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(dockWidth),dp(66),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);hp.bottomMargin=dp(12);root.addView(hotseat,hp);buildHotseat();

        showingLegacyHome=true;updateCombinedPageIndicator();
        root.setOnApplyWindowInsetsListener((v,in)->{
            try{
                int top=0,bottom=0;
                if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=in.getInsets(android.view.WindowInsets.Type.systemBars());top=bars.top;bottom=bars.bottom;}
                else{top=in.getSystemWindowInsetTop();bottom=in.getSystemWindowInsetBottom();}
                legacyHomeContent.setPadding(dp(16),Math.max(dp(2),top+dp(2)),dp(16),bottom+dp(112));
                FrameLayout.LayoutParams hp2=(FrameLayout.LayoutParams)hotseat.getLayoutParams();hp2.bottomMargin=Math.max(dp(8),bottom+dp(2));hotseat.setLayoutParams(hp2);
                FrameLayout.LayoutParams ip2=(FrameLayout.LayoutParams)pageIndicator.getLayoutParams();ip2.bottomMargin=hp2.bottomMargin+dp(68);pageIndicator.setLayoutParams(ip2);
                FrameLayout.LayoutParams wlp=(FrameLayout.LayoutParams)workspace.getLayoutParams();wlp.topMargin=Math.max(dp(8),top+dp(6));wlp.bottomMargin=hp2.bottomMargin+dp(76);workspace.setLayoutParams(wlp);
            }catch(Exception ignored){}
            return in;
        });
        root.requestApplyInsets();
    }

    private LinearLayout buildLegacyHeader(){
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setClipChildren(false);shell.setClipToPadding(false);

        // Mesmo cabeçalho do Clássico antigo: saudação + perfil antes do relógio.
        if(!prefs.getBoolean("minimalMode",false)&&prefs.getBoolean("welcomeEnabled",true)){
            View welcome=buildWelcomeHeaderExact();
            LinearLayout.LayoutParams wlp=new LinearLayout.LayoutParams(-1,-2);wlp.setMargins(0,0,0,dp(2));shell.addView(welcome,wlp);
        }

        LinearLayout hero=new LinearLayout(this);hero.setGravity(Gravity.BOTTOM);hero.setPadding(dp(4),dp(18),dp(4),dp(12));
        LinearLayout clockBox=new LinearLayout(this);clockBox.setOrientation(LinearLayout.VERTICAL);clockBox.setGravity(Gravity.BOTTOM|Gravity.LEFT);
        TextClock clock=new TextClock(this);clock.setFormat24Hour("HH:mm");clock.setFormat12Hour("HH:mm");clock.setTextSize(55);clock.setTextColor(themeFg());clock.setTypeface(android.graphics.Typeface.create("sans-serif-thin",0));clock.setGravity(Gravity.LEFT);clockBox.addView(clock,new LinearLayout.LayoutParams(-1,-2));
        TextClock date=new TextClock(this);date.setFormat24Hour("EEE, dd 'de' MMM");date.setFormat12Hour("EEE, dd 'de' MMM");date.setTextSize(15);date.setTextColor(themeSubtle());date.setGravity(Gravity.LEFT);date.setPadding(dp(2),0,0,0);clockBox.addView(date,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout weatherBox=new LinearLayout(this);weatherBox.setOrientation(LinearLayout.VERTICAL);weatherBox.setGravity(Gravity.BOTTOM|Gravity.RIGHT);
        TextView weather=new TextView(this);String wt=prefs.getString("weatherText","");weather.setText(wt==null||wt.trim().isEmpty()?"☁\nConfigurar clima":wt);weather.setTextColor(themeSubtle());weather.setTextSize(14);weather.setGravity(Gravity.RIGHT|Gravity.BOTTOM);weather.setLineSpacing(dp(2),1f);weatherBox.addView(weather,new LinearLayout.LayoutParams(-1,-2));
        hero.addView(clockBox,new LinearLayout.LayoutParams(0,-2,1.08f));LinearLayout.LayoutParams wlp2=new LinearLayout.LayoutParams(0,-2,.92f);wlp2.setMargins(dp(12),0,0,0);hero.addView(weatherBox,wlp2);shell.addView(hero,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout searchRow=new LinearLayout(this);searchRow.setGravity(Gravity.CENTER_VERTICAL);searchRow.setBackground(legacyCard(false));
        TextView glass=new TextView(this);glass.setText("⌕");glass.setTextSize(28);glass.setTextColor(themeSubtle());glass.setGravity(Gravity.CENTER);searchRow.addView(glass,new LinearLayout.LayoutParams(dp(48),dp(48)));
        legacySearch=new EditText(this);legacySearch.setSingleLine(true);legacySearch.setTextSize(14);legacySearch.setTextColor(themeFg());legacySearch.setHintTextColor(themeSubtle());legacySearch.setHint("Pesquisar apps, pastas, ajustes…");legacySearch.setBackgroundColor(Color.TRANSPARENT);searchRow.addView(legacySearch,new LinearLayout.LayoutParams(0,dp(48),1f));
        TextView options=new TextView(this);options.setText("⋮");options.setTextSize(26);options.setTextColor(themeSubtle());options.setGravity(Gravity.CENTER);options.setContentDescription("Configurações do launcher");options.setOnClickListener(v->showClassicSettings());searchRow.addView(options,new LinearLayout.LayoutParams(dp(48),dp(48)));shell.addView(searchRow,new LinearLayout.LayoutParams(-1,dp(48)));
        legacySearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence q,int st,int before,int count){renderLegacyInlineGrid();}public void afterTextChanged(Editable e){}});

        HorizontalScrollView catScroll=new HorizontalScrollView(this);catScroll.setHorizontalScrollBarEnabled(false);catScroll.setFillViewport(false);
        legacyChips=new LinearLayout(this);legacyChips.setGravity(Gravity.CENTER_VERTICAL);legacyChips.setPadding(0,dp(14),0,dp(12));catScroll.addView(legacyChips);shell.addView(catScroll,new LinearLayout.LayoutParams(-1,dp(62)));renderLegacyChips();
        return shell;
    }

    private View buildWelcomeHeaderExact(){
        LinearLayout wrap=new LinearLayout(this);wrap.setGravity(Gravity.CENTER_VERTICAL);wrap.setPadding(dp(2),0,dp(2),0);
        TextView wave=new TextView(this);wave.setText("👋");wave.setTextSize(20);wave.setTextColor(themeFg());wave.setGravity(Gravity.CENTER);wrap.addView(wave,new LinearLayout.LayoutParams(dp(34),dp(38)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
        String name=savedWelcomeName();String greet=welcomeGreeting()+(name.isEmpty()?"":", "+name);
        TextView title=new TextView(this);title.setText(greet);title.setTextSize(16);title.setTextColor(themeFg());title.setTypeface(null,1);copy.addView(title);
        if(prefs.getBoolean("welcomeShowMessage",true)){TextView msg=new TextView(this);msg.setText(welcomeMessage());msg.setTextSize(11);msg.setTextColor(themeSubtle());copy.addView(msg);}
        wrap.addView(copy,new LinearLayout.LayoutParams(0,-2,1f));
        if(prefs.getBoolean("welcomeShowSettings",true)){TextView settings=new TextView(this);settings.setText("⚙");settings.setTextSize(19);settings.setTextColor(themeFg());settings.setGravity(Gravity.CENTER);settings.setBackground(legacyRoundButton());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(30),dp(30));lp.setMargins(dp(6),0,0,0);wrap.addView(settings,lp);settings.setOnClickListener(v->showClassicSettings());}
        if(prefs.getBoolean("welcomeShowProfile",true)){
            View profile=buildProfileAvatar();LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(30),dp(30));lp.setMargins(dp(6),0,0,0);wrap.addView(profile,lp);profile.setOnClickListener(v->showProfileEditor());profile.setOnLongClickListener(v->{chooseProfilePhoto();return true;});
        }
        return wrap;
    }

    private String savedWelcomeName(){String n=prefs.getString("welcomeName","");return n==null?"":n.trim();}
    private String welcomeGreeting(){int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);if(h>=5&&h<12)return "Bom dia";if(h>=12&&h<18)return "Boa tarde";if(h>=18||h<1)return "Boa noite";return "Olá";}
    private String welcomeMessage(){int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);String[] a=h>=5&&h<12?new String[]{"Que seu dia comece bem!","Um ótimo dia para você.","Pronto para começar?","Que hoje seja um dia leve."}:h>=12&&h<18?new String[]{"Que sua tarde seja produtiva!","Como está seu dia?","Continue no seu ritmo.","Uma ótima tarde para você."}:new String[]{"Aproveite sua noite.","Hora de desacelerar um pouco.","Que sua noite seja tranquila.","Feche o dia do seu jeito."};if(!prefs.getBoolean("welcomeRandomMessages",true))return a[0];long slot=System.currentTimeMillis()/(60L*60L*1000L);return a[(int)Math.abs((slot*31L+(savedWelcomeName().isEmpty()?"Você":savedWelcomeName()).hashCode())%a.length)];}
    private File profilePhotoFile(){return new File(getFilesDir(),"welcome_profile.jpg");}
    private View buildProfileAvatar(){Bitmap bmp=null;try{File f=profilePhotoFile();if(f.exists())bmp=BitmapFactory.decodeFile(f.getAbsolutePath());}catch(Exception ignored){}if(bmp!=null){ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setImageBitmap(bmp);iv.setBackground(legacyRoundButton());if(android.os.Build.VERSION.SDK_INT>=21)iv.setClipToOutline(true);iv.setContentDescription("Editar perfil");return iv;}String n=savedWelcomeName();TextView tv=new TextView(this);tv.setText(n.isEmpty()?"☺":n.substring(0,1).toUpperCase(Locale.getDefault()));tv.setTextSize(n.isEmpty()?17:16);tv.setTextColor(themeFg());tv.setTypeface(null,1);tv.setGravity(Gravity.CENTER);tv.setBackground(legacyRoundButton());tv.setContentDescription("Editar perfil");return tv;}
    private GradientDrawable legacyRoundButton(){GradientDrawable g=legacyCard(false);g.setCornerRadius(dp(18));return g;}
    private void showProfileEditor(){final EditText input=new EditText(this);input.setSingleLine(true);input.setText(savedWelcomeName());input.setSelection(input.getText().length());input.setHint("Seu nome");new AlertDialog.Builder(this).setTitle("Seu perfil").setMessage("Nome e foto ficam somente neste aparelho.").setView(input).setNeutralButton("Foto",(d,w)->chooseProfilePhoto()).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{String n=input.getText()==null?"":input.getText().toString().trim();SharedPreferences.Editor e=prefs.edit();if(n.isEmpty())e.remove("welcomeName");else e.putString("welcomeName",n);e.apply();rebuildLegacyHeaderOnly();}).show();}
    private void chooseProfilePhoto(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_PROFILE_PHOTO);}catch(Exception e){toast("Não foi possível abrir a galeria.");}}
    private void rebuildLegacyHeaderOnly(){if(legacyHomeContent==null)return;int index=legacyHomeContent.indexOfChild(legacyHeader);if(index<0)return;legacyHomeContent.removeView(legacyHeader);legacyHeader=buildLegacyHeader();legacyHomeContent.addView(legacyHeader,index,new LinearLayout.LayoutParams(-1,-2));renderLegacyInlineGrid();}

    private void renderLegacyChips(){
        if(legacyChips==null)return;legacyChips.removeAllViews();ArrayList<String> cats=new ArrayList<>();cats.add("Tudo");cats.add("Favoritos");Collections.addAll(cats,LEGACY_CATEGORIES);cats.addAll(splitPref("customCatNames"));
        for(String c:cats){boolean selected=c.equals(legacySelectedCategory);TextView t=new TextView(this);t.setText(c);t.setTextSize(12);t.setTextColor(selected?Color.WHITE:themeFg());t.setGravity(Gravity.CENTER);t.setPadding(dp(15),0,dp(15),0);t.setBackground(legacyCard(selected));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(36));lp.setMargins(0,0,dp(8),0);legacyChips.addView(t,lp);t.setOnClickListener(v->{legacySelectedCategory=c;legacyGridPage=0;renderLegacyChips();renderLegacyInlineGrid();});}
    }

    private void renderLegacyInlineGrid(){
        if(legacyGridHost==null)return;legacyGridHost.removeAllViews();List<AppEntry> all=loadApps();Set<String> hidden=loadHiddenApps();String query=legacySearch==null||legacySearch.getText()==null?"":legacySearch.getText().toString().trim().toLowerCase(Locale.ROOT);ArrayList<AppEntry> list=new ArrayList<>();
        for(AppEntry a:all){if(hidden.contains(a.key)||prefs.getBoolean("hidden:"+a.key,false))continue;if(!"Tudo".equals(legacySelectedCategory)){if("Favoritos".equals(legacySelectedCategory)){if(!prefs.getBoolean("fav:"+a.key,false))continue;}else if(!legacySelectedCategory.equals(legacyCategoryFor(a)))continue;}if(!query.isEmpty()&&!a.label.toLowerCase(Locale.ROOT).contains(query)&&!a.pkg.toLowerCase(Locale.ROOT).contains(query))continue;list.add(a);}
        int cols=Math.max(4,Math.min(5,prefs.getInt("appGridColumns",4))),rows=Math.max(4,Math.min(5,prefs.getInt("appGridRows",4)));int icon=Math.max(38,Math.min(58,prefs.getInt("iconSize",48)));int rowH=Math.max(icon+28,78);int perPage=Math.max(1,cols*rows);int pages=Math.max(1,(list.size()+perPage-1)/perPage);legacyGridPage=Math.max(0,Math.min(legacyGridPage,pages-1));
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);legacyGridHost.addView(shell,new FrameLayout.LayoutParams(-1,-2));
        legacyGridPager=new HorizontalScrollView(this);legacyGridPager.setHorizontalScrollBarEnabled(false);legacyGridPager.setOverScrollMode(View.OVER_SCROLL_NEVER);legacyGridPager.setFillViewport(true);legacyGridPages=new LinearLayout(this);legacyGridPages.setOrientation(LinearLayout.HORIZONTAL);legacyGridPager.addView(legacyGridPages,new HorizontalScrollView.LayoutParams(-2,-2));shell.addView(legacyGridPager,new LinearLayout.LayoutParams(-1,dp(rowH*rows)));
        int pageWidth=Math.max(1,getResources().getDisplayMetrics().widthPixels-dp(32));
        for(int p=0;p<pages;p++){LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setClipChildren(false);page.setClipToPadding(false);page.setTag(p);for(int r=0;r<rows;r++){LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.TOP);for(int c=0;c<cols;c++){int idx=p*perPage+r*cols+c;if(idx<list.size()){AppEntry a=list.get(idx);View tile=legacyAppTile(a,icon);line.addView(tile,new LinearLayout.LayoutParams(0,dp(rowH),1f));}else line.addView(new View(this),new LinearLayout.LayoutParams(0,dp(rowH),1f));}page.addView(line,new LinearLayout.LayoutParams(-1,dp(rowH)));}legacyGridPages.addView(page,new LinearLayout.LayoutParams(pageWidth,dp(rowH*rows)));}
        legacyGridIndicator=new TextView(this);legacyGridIndicator.setTextSize(8);legacyGridIndicator.setTextColor(themeSubtle());legacyGridIndicator.setGravity(Gravity.CENTER);legacyGridIndicator.setPadding(0,dp(2),0,dp(2));shell.addView(legacyGridIndicator,new LinearLayout.LayoutParams(-1,dp(22)));updateLegacyGridIndicator(pages);
        legacyGridPager.post(()->legacyGridPager.scrollTo(legacyGridPage*pageWidth,0));
        legacyGridPager.setOnTouchListener((v,e)->{if(e.getActionMasked()==MotionEvent.ACTION_DOWN){legacyGridDownX=e.getX();return false;}if(e.getActionMasked()==MotionEvent.ACTION_UP){float dx=e.getX()-legacyGridDownX;int current=Math.max(0,Math.min(pages-1,Math.round(legacyGridPager.getScrollX()/(float)pageWidth)));if(current==pages-1&&dx<-dp(64)){showWorkspaceHome(true);return true;}int target=Math.max(0,Math.min(pages-1,Math.round(legacyGridPager.getScrollX()/(float)pageWidth)));legacyGridPage=target;legacyGridPager.smoothScrollTo(target*pageWidth,0);updateLegacyGridIndicator(pages);}return false;});
        if(list.isEmpty()){TextView empty=new TextView(this);empty.setText("Nenhum aplicativo encontrado");empty.setTextSize(14);empty.setTextColor(themeSubtle());empty.setGravity(Gravity.CENTER);legacyGridHost.removeAllViews();legacyGridHost.addView(empty,new FrameLayout.LayoutParams(-1,dp(100)));}
    }
    private void updateLegacyGridIndicator(int pages){if(legacyGridIndicator==null)return;StringBuilder b=new StringBuilder();for(int i=0;i<pages;i++){if(i>0)b.append("  ");b.append(i==legacyGridPage?"●":"○");}legacyGridIndicator.setText(b.toString());}
    private View legacyAppTile(AppEntry a,int iconSize){LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(3),dp(7),dp(3),dp(5));tile.setClipChildren(false);ImageView icon=new ImageView(this);icon.setImageDrawable(a.icon);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);tile.addView(icon,new LinearLayout.LayoutParams(dp(iconSize),dp(iconSize)));if(prefs.getBoolean("showAppLabels",true)){TextView label=new TextView(this);label.setText(a.label);label.setTextSize(11);label.setTextColor(themeFg());label.setGravity(Gravity.CENTER);label.setSingleLine(true);label.setEllipsize(android.text.TextUtils.TruncateAt.END);label.setShadowLayer(dp(2),0,dp(1),0xaa000000);tile.addView(label,new LinearLayout.LayoutParams(-1,dp(22)));}tile.setOnClickListener(v->launch(a.pkg,a.cls));bindLauncher3LongPress(tile,v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);boolean started=itemDragController!=null&&itemDragController.startExternalApp(v,a.pkg,a.cls,null,-1,lastTouchRawX,lastTouchRawY);if(started)uiHandler.post(()->showWorkspaceHome(false));return started;});return tile;}

    private void showWorkspaceHome(boolean animate){if(workspace==null)return;showingLegacyHome=false;if(legacyHomeScroll!=null){legacyHomeScroll.animate().cancel();legacyHomeScroll.setVisibility(View.GONE);}workspace.setVisibility(View.VISIBLE);workspace.bringToFront();if(pageIndicator!=null)pageIndicator.bringToFront();if(hotseat!=null)hotseat.bringToFront();if(dragTargetBar!=null&&dragTargetBar.getVisibility()==View.VISIBLE)dragTargetBar.bringToFront();workspace.showPage(Math.max(0,store.currentPage()),animate);updateCombinedPageIndicator();}
    private void showLegacyHome(boolean animate){showingLegacyHome=true;if(workspace!=null)workspace.setVisibility(View.VISIBLE);if(legacyHomeScroll!=null){legacyHomeScroll.setVisibility(View.VISIBLE);legacyHomeScroll.bringToFront();legacyHomeScroll.setAlpha(animate?0.82f:1f);if(animate)legacyHomeScroll.animate().alpha(1f).setDuration(150).start();}if(pageIndicator!=null)pageIndicator.bringToFront();if(hotseat!=null)hotseat.bringToFront();renderLegacyInlineGrid();updateCombinedPageIndicator();}
    private void updateCombinedPageIndicator(){if(pageIndicator==null)return;int count=workspace==null?1:workspace.pageCount()+1;int selected=showingLegacyHome?0:(workspace.currentPage()+1);StringBuilder b=new StringBuilder();for(int i=0;i<count;i++){if(i>0)b.append("  ");b.append(i==selected?"●":"○");}pageIndicator.setText(b.toString());}

    private void seedWorkspaceFromInstalledAppsIfEmpty(){
        if(store==null||!store.items().isEmpty())return;List<AppEntry> apps=loadApps();if(apps.isEmpty())return;ArrayList<ClassicLayoutStore.Item> seed=new ArrayList<>();int capacity=Math.max(1,gridCols*gridRows),index=0;
        Set<String> hidden=loadHiddenApps();for(AppEntry a:apps){if(hidden.contains(a.key)||prefs.getBoolean("hidden:"+a.key,false))continue;ClassicLayoutStore.Item item=new ClassicLayoutStore.Item();item.type=ClassicLayoutStore.TYPE_APP;item.packageName=a.pkg;item.className=a.cls;item.page=index/capacity;int local=index%capacity;item.cellX=local%gridCols;item.cellY=local/gridCols;seed.add(item);index++;}
        if(!seed.isEmpty()){store.putAll(seed);store.ensurePages(Math.max(2,(index+capacity-1)/capacity));store.setCurrentPage(0);}
    }

    private int themeFg(){return prefs.getInt("runtimeUnifiedTheme.fg",Color.WHITE);}
    private int themeSubtle(){return prefs.getInt("runtimeUnifiedTheme.subtle",0xffb8c4d4);}
    private int themeAccent(){return prefs.getInt("runtimeUnifiedTheme.accent",0xff187cff);}
    private int themePrimary(){return prefs.getInt("runtimeUnifiedTheme.primary",0xff101a26);}
    private int themeBorder(){return prefs.getInt("runtimeUnifiedTheme.border",0x44ffffff);}
    private GradientDrawable legacyCard(boolean selected){GradientDrawable g=new GradientDrawable();g.setColor(selected?themeAccent():themePrimary());g.setCornerRadius(dp(Math.max(12,prefs.getInt("runtimeUnifiedTheme.corner",14))));g.setStroke(dp(1),themeBorder());g.setAlpha(Math.max(80,Math.min(255,prefs.getInt("runtimeUnifiedTheme.homeAlpha",220))));return g;}

    private String legacyCategoryFor(AppEntry a){
        if(a==null)return "Ferramentas";String custom=prefs.getString("customcat:"+a.key,"");if(custom!=null&&!custom.isEmpty())return custom;int idx=prefs.getInt("cat:"+a.key,-1);if(idx>=0&&idx<LEGACY_CATEGORIES.length)return LEGACY_CATEGORIES[idx];
        try{android.content.pm.ApplicationInfo ai=getPackageManager().getApplicationInfo(a.pkg,0);switch(ai.category){case android.content.pm.ApplicationInfo.CATEGORY_GAME:return "Jogos";case android.content.pm.ApplicationInfo.CATEGORY_AUDIO:return "Música";case android.content.pm.ApplicationInfo.CATEGORY_VIDEO:return "Vídeo";case android.content.pm.ApplicationInfo.CATEGORY_IMAGE:return "Fotografia";case android.content.pm.ApplicationInfo.CATEGORY_PRODUCTIVITY:return "Produtividade";case android.content.pm.ApplicationInfo.CATEGORY_SOCIAL:return "Comunicação";case android.content.pm.ApplicationInfo.CATEGORY_NEWS:return "Entretenimento";case android.content.pm.ApplicationInfo.CATEGORY_MAPS:return "Viagem";default:return "Ferramentas";}}catch(Exception ignored){return "Ferramentas";}
    }

    private void showLegacyAppBrowser(String initialQuery,String category){
        closeOverlay();List<AppEntry> all=loadApps();Set<String> hidden=loadHiddenApps();ArrayList<AppEntry> apps=new ArrayList<>();for(AppEntry a:all){if(hidden.contains(a.key)||prefs.getBoolean("hidden:"+a.key,false))continue;if(category!=null&&!category.isEmpty()&&!"Tudo".equals(category)){if("Favoritos".equals(category)){if(!prefs.getBoolean("fav:"+a.key,false))continue;}else if(!category.equals(legacyCategoryFor(a)))continue;}apps.add(a);}
        FrameLayout overlay=createOverlay();LinearLayout panel=createBottomPanel();overlay.addView(panel,bottomPanelParams(dp(108)));panel.addView(headerRow(category==null||"Tudo".equals(category)?"Aplicativos":category,overlay));
        EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Buscar aplicativos");search.setText(initialQuery==null?"":initialQuery);search.setSelection(search.getText().length());search.setTextColor(Color.WHITE);search.setHintTextColor(0x88ffffff);search.setTextSize(15);search.setPadding(dp(14),0,dp(14),0);search.setBackground(round(0x55131c28,dp(18),0x44ffffff,1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(46));sp.leftMargin=dp(12);sp.rightMargin=dp(12);sp.bottomMargin=dp(4);panel.addView(search,sp);
        ScrollView scroll=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(8),dp(4),dp(8),dp(24));scroll.addView(content,new ScrollView.LayoutParams(-1,-2));panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));renderAppDrawerGrid(content,apps,search.getText().toString());search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence q,int st,int before,int count){renderAppDrawerGrid(content,apps,q==null?"":q.toString());}public void afterTextChanged(Editable e){}});showOverlay(overlay);search.requestFocus();
    }

    private void loadHotseatState(){
        hotseatKeys.clear();String raw=prefs.getString(KEY_HOTSEAT,null);
        if(raw==null)hotseatKeys.addAll(splitPref("dockApps"));
        else if(!raw.isEmpty())Collections.addAll(hotseatKeys,raw.split(SEP,-1));
    }

    private void saveHotseatState(){
        StringBuilder b=new StringBuilder();for(String key:hotseatKeys){if(key==null||key.isEmpty())continue;if(b.length()>0)b.append(SEP);b.append(key);}
        prefs.edit().putString(KEY_HOTSEAT,b.toString()).apply();
    }

    private void buildHotseat(){
        hotseat.removeAllViews();hotseatCapacity=Math.max(4,Math.min(5,gridCols));
        List<AppEntry> apps=loadApps();ArrayList<String> valid=new ArrayList<>();
        for(String key:hotseatKeys){if(valid.size()>=hotseatCapacity)break;if(findApp(apps,key)!=null&&!valid.contains(key))valid.add(key);}
        if(!valid.equals(hotseatKeys)){hotseatKeys.clear();hotseatKeys.addAll(valid);saveHotseatState();}
        int gap=Math.max(0,Math.min(14,prefs.getInt("dockSpacing",4)));int iconDp=Math.max(30,Math.min(64,prefs.getInt("dockIconSize",44)));
        for(int slot=0;slot<hotseatCapacity;slot++){
            View child;
            if(slot<hotseatKeys.size())child=hotseatIcon(findApp(apps,hotseatKeys.get(slot)),slot);
            else{TextView empty=new TextView(this);empty.setGravity(Gravity.CENTER);empty.setContentDescription("Espaço vazio do Dock");child=empty;}
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1f);lp.setMargins(dp(gap/2f),0,dp(gap/2f),0);hotseat.addView(child,lp);
            if(child instanceof LinearLayout){LinearLayout box=(LinearLayout)child;if(box.getChildCount()>0&&box.getChildAt(0) instanceof ImageView){View iv=box.getChildAt(0);iv.getLayoutParams().width=dp(iconDp);iv.getLayoutParams().height=dp(iconDp);iv.requestLayout();}}
        }
    }

    private View hotseatIcon(AppEntry a,int index){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setContentDescription(a.label);
        ImageView iv=new ImageView(this);iv.setImageDrawable(a.icon);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);box.addView(iv,new LinearLayout.LayoutParams(dp(42),dp(42)));
        box.setOnClickListener(v->launch(a.pkg,a.cls));
        bindLauncher3LongPress(box,v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);boolean started=itemDragController!=null&&itemDragController.startExternalApp(v,a.pkg,a.cls,null,index,lastTouchRawX,lastTouchRawY);if(started)uiHandler.post(()->showWorkspaceHome(false));return started;});
        return box;
    }

    private int hotseatTargetIndex(float x){
        float slot=Math.max(1f,hotseat.getWidth()/(float)Math.max(1,hotseatCapacity));
        return Math.max(0,Math.min(hotseatCapacity-1,(int)(x/slot)));
    }
    private void insertHotseatKey(String key,int index){
        if(key==null||key.isEmpty())return;int old=hotseatKeys.indexOf(key);if(old>=0){hotseatKeys.remove(old);if(old<index)index--;}
        index=Math.max(0,Math.min(index,hotseatKeys.size()));hotseatKeys.add(index,key);while(hotseatKeys.size()>hotseatCapacity)hotseatKeys.remove(hotseatKeys.size()-1);
    }
    private void removeHotseatKey(String key){hotseatKeys.remove(key);saveHotseatState();}

    @Override public View createItemView(ClassicLayoutStore.Item item){
        if(ClassicLayoutStore.TYPE_WIDGET.equals(item.type))return createWidgetFrame(item);
        if(ClassicLayoutStore.TYPE_FOLDER.equals(item.type))return createFolderShortcut(item);
        return createAppShortcut(item);
    }

    private View createAppShortcut(ClassicLayoutStore.Item item){
        AppEntry a=resolveApp(item.packageName,item.className);if(a==null)return null;
        LinearLayout box=appIconView(a,true);
        box.setOnClickListener(v->launch(item.packageName,item.className));
        bindLauncher3LongPress(box,v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);ClassicLayoutStore.Item live=store.find(item.id);return itemDragController!=null&&itemDragController.startExisting(v,live,lastTouchRawX,lastTouchRawY);});
        return box;
    }

    private View createFolderShortcut(ClassicLayoutStore.Item item){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(3),dp(3),dp(3),dp(3));
        FrameLayout preview=new FrameLayout(this);preview.setBackground(round(0x663a4656,dp(16),0x44ffffff,1));box.addView(preview,new LinearLayout.LayoutParams(dp(56),dp(56)));
        int index=0;for(String key:item.members){if(index>=4)break;String[] pair=ClassicLayoutStore.parseComponentKey(key);AppEntry a=resolveApp(pair[0],pair[1]);if(a==null)continue;
            ImageView iv=new ImageView(this);iv.setImageDrawable(a.icon);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(25),dp(25));
            lp.leftMargin=(index%2)*dp(27)+dp(2);lp.topMargin=(index/2)*dp(27)+dp(2);preview.addView(iv,lp);index++;}
        TextView label=new TextView(this);label.setText(item.title==null||item.title.isEmpty()?"Pasta":item.title);label.setTextColor(Color.WHITE);label.setTextSize(11);label.setGravity(Gravity.CENTER);label.setMaxLines(1);label.setShadowLayer(dp(2),0,dp(1),0xcc000000);box.addView(label,new LinearLayout.LayoutParams(-1,dp(22)));
        box.setOnClickListener(v->showFolderOverlay(item.id));
        bindLauncher3LongPress(box,v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);ClassicLayoutStore.Item live=store.find(item.id);return itemDragController!=null&&itemDragController.startExisting(v,live,lastTouchRawX,lastTouchRawY);});
        return box;
    }

    private void bindLauncher3LongPress(View view,View.OnLongClickListener listener){
        if(view==null)return;L3CheckLongPressHelper helper=new L3CheckLongPressHelper(view,listener);
        view.setOnTouchListener((v,e)->{helper.onTouchEvent(e);return false;});
    }

    private LinearLayout appIconView(AppEntry a,boolean withLabel){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(3),dp(3),dp(3),dp(3));
        ImageView icon=new ImageView(this);icon.setImageDrawable(a.icon);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);box.addView(icon,new LinearLayout.LayoutParams(dp(52),dp(52)));
        if(withLabel){TextView label=new TextView(this);label.setText(a.label);label.setTextColor(Color.WHITE);label.setTextSize(11);label.setGravity(Gravity.CENTER);label.setMaxLines(1);label.setShadowLayer(dp(2),0,dp(1),0xcc000000);box.addView(label,new LinearLayout.LayoutParams(-1,dp(22)));}
        return box;
    }

    private View createWidgetFrame(ClassicLayoutStore.Item item){
        AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(item.appWidgetId);
        if(info==null){try{widgetHost.deleteAppWidgetId(item.appWidgetId);}catch(Exception ignored){}store.remove(item.id);return null;}
        WidgetFrame frame=new WidgetFrame(this,item,info);
        try{AppWidgetHostView host=widgetHost.createView(this,item.appWidgetId,info);host.setAppWidget(item.appWidgetId,info);frame.setHost(host);}catch(Exception e){return brokenWidget(item);}
        return frame;
    }

    private View brokenWidget(ClassicLayoutStore.Item item){TextView t=new TextView(this);t.setText("Widget indisponível\nToque para remover");t.setTextColor(Color.WHITE);t.setGravity(Gravity.CENTER);t.setBackground(round(0xaa8b1e2d,dp(16),0x55ffffff,1));t.setOnClickListener(v->{widgetHost.deleteAppWidgetId(item.appWidgetId);workspace.removeItem(item.id);});return t;}

    /**
     * Widget host wrapper. The old Classic edit handles are intentionally gone: long-press now
     * starts the Launcher3-style widget drag and resize is handled by L3WidgetResizeFrame.
     */
    private final class WidgetFrame extends FrameLayout {
        private final ClassicLayoutStore.Item item;
        private final AppWidgetProviderInfo info;
        private final L3CheckLongPressHelper longPressHelper;
        private AppWidgetHostView host;

        WidgetFrame(Activity c,ClassicLayoutStore.Item item,AppWidgetProviderInfo info){
            super(c);this.item=item;this.info=info;setClipChildren(false);setClipToPadding(false);setBackgroundColor(Color.TRANSPARENT);
            longPressHelper=new L3CheckLongPressHelper(this,v->{
                ClassicLayoutStore.Item live=store.find(item.id);if(live==null)return false;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);int[] min=launcher3MinimumSpan(info,live.spanX,live.spanY);
                if(activeResizeFrame!=null){activeResizeFrame.dismiss(false);activeResizeFrame=null;}
                return widgetDragController!=null&&widgetDragController.startExisting(WidgetFrame.this,live,min[0],min[1],lastTouchRawX,lastTouchRawY);
            });
            longPressHelper.setLongPressTimeoutFactor(L3CheckLongPressHelper.DEFAULT_LONG_PRESS_TIMEOUT_FACTOR);
        }

        @Override public boolean onInterceptTouchEvent(MotionEvent e){longPressHelper.onTouchEvent(e);return false;}
        @Override protected void onDetachedFromWindow(){longPressHelper.cancelLongPress();super.onDetachedFromWindow();}
        void setHost(AppWidgetHostView host){this.host=host;FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,-1);hp.setMargins(dp(2),dp(2),dp(2),dp(2));addView(host,0,hp);post(this::syncHostSize);}
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);if(w!=oldw||h!=oldh)post(this::syncHostSize);}
        private void syncHostSize(){if(host==null||getWidth()<=0||getHeight()<=0)return;int wDp=Math.max(1,Math.round(getWidth()/density)),hDp=Math.max(1,Math.round(getHeight()/density));try{host.updateAppWidgetSize(null,wDp,hDp,wDp,hDp);}catch(Exception ignored){}}
    }

    private int[] launcher3MinimumSpan(AppWidgetProviderInfo info,int currentSpanX,int currentSpanY){
        int[] min=minimumResizeSpan(info);boolean h=(info.resizeMode&AppWidgetProviderInfo.RESIZE_HORIZONTAL)!=0,v=(info.resizeMode&AppWidgetProviderInfo.RESIZE_VERTICAL)!=0;
        if(!h)min[0]=Math.max(1,currentSpanX);if(!v)min[1]=Math.max(1,currentSpanY);return min;
    }

    private int[] launcher3MaximumSpan(AppWidgetProviderInfo info){
        int maxW=0,maxH=0;if(android.os.Build.VERSION.SDK_INT>=31){maxW=info.maxResizeWidth;maxH=info.maxResizeHeight;}
        int maxX=maxW>0?workspace.suggestedSpan(maxW,1)[0]:workspace.columns();
        int maxY=maxH>0?workspace.suggestedSpan(1,maxH)[1]:workspace.rows();
        int[] max=new int[]{maxX,maxY};
        if((info.resizeMode&AppWidgetProviderInfo.RESIZE_HORIZONTAL)==0)max[0]=workspace.columns();
        if((info.resizeMode&AppWidgetProviderInfo.RESIZE_VERTICAL)==0)max[1]=workspace.rows();
        return new int[]{Math.max(1,Math.min(workspace.columns(),max[0])),Math.max(1,Math.min(workspace.rows(),max[1]))};
    }

    private void showLauncher3ResizeFrame(String itemId){
        if(itemId==null||root==null||workspace==null)return;ClassicLayoutStore.Item item=store.find(itemId);if(item==null||!ClassicLayoutStore.TYPE_WIDGET.equals(item.type)||item.page!=workspace.currentPage())return;
        AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(item.appWidgetId);if(info==null||info.resizeMode==AppWidgetProviderInfo.RESIZE_NONE)return;
        ClassicCellLayout grid=workspace.currentCellLayout();if(grid==null)return;View container=null;
        for(int i=0;i<grid.getChildCount();i++){View child=grid.getChildAt(i);if(child.getLayoutParams() instanceof ClassicCellLayout.LayoutParams){ClassicCellLayout.LayoutParams lp=(ClassicCellLayout.LayoutParams)child.getLayoutParams();if(itemId.equals(lp.itemId)){container=child;break;}}}
        if(!(container instanceof WidgetFrame))return;WidgetFrame wf=(WidgetFrame)container;if(wf.host==null)return;
        if(activeResizeFrame!=null&&activeResizeFrame.getParent()!=null)((FrameLayout)activeResizeFrame.getParent()).removeView(activeResizeFrame);
        int[] min=launcher3MinimumSpan(info,item.spanX,item.spanY),max=launcher3MaximumSpan(info);
        activeResizeFrame=L3WidgetResizeFrame.show(root,workspace,store,itemId,container,wf.host,info,min[0],min[1],max[0],max[1],committed->{activeResizeFrame=null;});
    }

    private String findWidgetItemId(int appWidgetId){for(ClassicLayoutStore.Item i:store.items())if(ClassicLayoutStore.TYPE_WIDGET.equals(i.type)&&i.appWidgetId==appWidgetId)return i.id;return null;}

    private int[] minimumResizeSpan(AppWidgetProviderInfo info){int minW=info.minResizeWidth>0?info.minResizeWidth:info.minWidth,minH=info.minResizeHeight>0?info.minResizeHeight:info.minHeight;return workspace.suggestedSpan(minW,minH);}
    private void removeWidget(ClassicLayoutStore.Item item){new AlertDialog.Builder(this).setTitle("Remover widget?").setNegativeButton("Cancelar",null).setPositiveButton("Remover",(d,w)->{try{widgetHost.deleteAppWidgetId(item.appWidgetId);}catch(Exception ignored){}workspace.removeItem(item.id);}).show();}

    private void showHomeEditMenu(){
        String[] items={"Widgets","Aplicativos","Papel de parede","Configurações","Grade da Home","Nova página","Ir para Modo Feed"};
        new AlertDialog.Builder(this).setTitle("Editar Home").setItems(items,(d,w)->{
            if(w==0)showWidgetPicker();else if(w==1)showLegacyAppBrowser("",null);else if(w==2)openWallpaperPicker();
            else if(w==3)showClassicSettings();else if(w==4)showGridPicker();
            else if(w==5){store.ensurePages(workspace.pageCount()+1);workspace.rebuild();showWorkspaceHome(false);workspace.showPage(workspace.pageCount()-1,true);}
            else switchToFeed();
        }).show();
    }

    private void showClassicSettings(){
        String msg="Grade: "+gridCols+" × "+gridRows+"\nPáginas: "+workspace.pageCount()+"\nDock: "+hotseatCapacity+" slots\nApps ocultos: "+loadHiddenApps().size()+"\n\nA Home usa backup automático do layout antes de cada alteração.";
        new AlertDialog.Builder(this).setTitle("Configurações do Clássico").setMessage(msg)
                .setPositiveButton("Grade",(d,w)->showGridPicker()).setNeutralButton("Apps ocultos",(d,w)->showHiddenAppsManager()).setNegativeButton("Fechar",null).show();
    }

    private void showGridPicker(){
        final int[][] grids={{4,5},{4,6},{5,5},{5,6}};String[] labels=new String[grids.length];
        for(int i=0;i<grids.length;i++)labels[i]=grids[i][0]+" × "+grids[i][1]+(grids[i][0]==gridCols&&grids[i][1]==gridRows?"  · atual":" ");
        new AlertDialog.Builder(this).setTitle("Grade da Home").setItems(labels,(d,w)->{
            int c=grids[w][0],r=grids[w][1];if(c==gridCols&&r==gridRows)return;
            prefs.edit().putInt(KEY_GRID_COLS,c).putInt(KEY_GRID_ROWS,r).commit();recreate();
        }).show();
    }

    private void openWallpaperPicker(){
        try{startActivity(Intent.createChooser(new Intent(Intent.ACTION_SET_WALLPAPER),"Papel de parede"));}
        catch(Exception e){try{startActivity(new Intent(android.app.WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));}catch(Exception ignored){toast("Seletor de papel de parede indisponível.");}}
    }

    private void showAddMenu(){String[] items={"Aplicativo","Widget","Nova página","Ir para Modo Feed"};new AlertDialog.Builder(this).setTitle("Adicionar à Home").setItems(items,(d,w)->{if(w==0)showLegacyAppBrowser("",null);else if(w==1)showWidgetPicker();else if(w==2){store.ensurePages(workspace.pageCount()+1);workspace.rebuild();showWorkspaceHome(false);workspace.showPage(workspace.pageCount()-1,true);}else switchToFeed();}).show();}

    private void showAppDrawer(){showLegacyAppBrowser("",null);}

    private void renderAppDrawerGrid(LinearLayout content,List<AppEntry> apps,String query){
        content.removeAllViews();String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);ArrayList<AppEntry> filtered=new ArrayList<>();
        for(AppEntry a:apps)if(q.isEmpty()||a.label.toLowerCase(Locale.ROOT).contains(q)||a.pkg.toLowerCase(Locale.ROOT).contains(q))filtered.add(a);
        if(filtered.isEmpty()){TextView empty=new TextView(this);empty.setText("Nenhum aplicativo encontrado");empty.setTextColor(0xaaffffff);empty.setTextSize(14);empty.setGravity(Gravity.CENTER);content.addView(empty,new LinearLayout.LayoutParams(-1,dp(84)));return;}
        for(int i=0;i<filtered.size();i+=4){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.TOP);content.addView(row,new LinearLayout.LayoutParams(-1,dp(92)));
            for(int col=0;col<4;col++){int idx=i+col;if(idx>=filtered.size()){row.addView(new TextView(this),new LinearLayout.LayoutParams(0,-1,1f));continue;}AppEntry a=filtered.get(idx);LinearLayout cell=appIconView(a,true);cell.setContentDescription(a.label);cell.setOnClickListener(v->launch(a.pkg,a.cls));bindLauncher3LongPress(cell,v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);boolean started=itemDragController!=null&&itemDragController.startExternalApp(v,a.pkg,a.cls,null,-1,lastTouchRawX,lastTouchRawY);if(started)v.post(()->{closeOverlay();showWorkspaceHome(false);});return started;});row.addView(cell,new LinearLayout.LayoutParams(0,-1,1f));}}
    }

    private Set<String> loadHiddenApps(){HashSet<String> out=new HashSet<>();String raw=prefs.getString(KEY_HIDDEN_APPS,"");if(raw!=null&&!raw.isEmpty())Collections.addAll(out,raw.split(SEP,-1));return out;}
    private void saveHiddenApps(Set<String> hidden){ArrayList<String> keys=new ArrayList<>(hidden);Collections.sort(keys);StringBuilder b=new StringBuilder();for(String key:keys){if(key==null||key.isEmpty())continue;if(b.length()>0)b.append(SEP);b.append(key);}prefs.edit().putString(KEY_HIDDEN_APPS,b.toString()).commit();}
    private void showHiddenAppsManager(){
        List<AppEntry> apps=loadApps();Set<String> current=loadHiddenApps();String[] labels=new String[apps.size()];boolean[] checked=new boolean[apps.size()];
        for(int i=0;i<apps.size();i++){labels[i]=apps.get(i).label;checked[i]=current.contains(apps.get(i).key);}
        HashSet<String> next=new HashSet<>(current);new AlertDialog.Builder(this).setTitle("Apps ocultos no Drawer").setMultiChoiceItems(labels,checked,(d,which,isChecked)->{String key=apps.get(which).key;if(isChecked)next.add(key);else next.remove(key);})
                .setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{saveHiddenApps(next);closeOverlay();showLegacyAppBrowser("",null);}).show();
    }

    private void showWidgetPicker(){
        closeOverlay();List<AppWidgetProviderInfo> providers=new ArrayList<>(widgetManager.getInstalledProviders());Collections.sort(providers,(a,b)->{int c=widgetAppLabel(a).compareToIgnoreCase(widgetAppLabel(b));return c!=0?c:labelForWidget(a).compareToIgnoreCase(labelForWidget(b));});if(providers.isEmpty()){toast("Nenhum widget disponível.");return;}
        FrameLayout overlay=createOverlay();LinearLayout panel=createBottomPanel();overlay.addView(panel,bottomPanelParams(dp(108)));panel.addView(headerRow("Widgets",overlay));
        TextView hint=new TextView(this);hint.setText("Toque para adicionar · segure para arrastar até a Home");hint.setTextColor(0xbfffffff);hint.setTextSize(12);hint.setGravity(Gravity.CENTER);panel.addView(hint,new LinearLayout.LayoutParams(-1,dp(34)));
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(10),dp(4),dp(10),dp(24));scroll.addView(list,new ScrollView.LayoutParams(-1,-2));panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        String lastApp="";for(AppWidgetProviderInfo info:providers){String appName=widgetAppLabel(info);if(!appName.equals(lastApp)){TextView section=new TextView(this);section.setText(appName);section.setTextColor(0xddffffff);section.setTextSize(14);section.setPadding(dp(6),dp(12),dp(6),dp(4));list.addView(section,new LinearLayout.LayoutParams(-1,dp(42)));lastApp=appName;}
            LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(8));card.setBackground(round(0x44192533,dp(18),0x33ffffff,1));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(108));cp.setMargins(0,dp(4),0,dp(4));list.addView(card,cp);
            ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.CENTER_INSIDE);Drawable pd=widgetPreview(info);if(pd!=null)preview.setImageDrawable(pd);card.addView(preview,new LinearLayout.LayoutParams(dp(118),-1));
            LinearLayout texts=new LinearLayout(this);texts.setOrientation(LinearLayout.VERTICAL);texts.setGravity(Gravity.CENTER_VERTICAL);TextView name=new TextView(this);name.setText(labelForWidget(info));name.setTextColor(Color.WHITE);name.setTextSize(15);texts.addView(name);TextView pkg=new TextView(this);int[] span=workspace.suggestedSpan(info.minWidth,info.minHeight);pkg.setText(span[0]+"×"+span[1]+"  ·  "+info.provider.getPackageName());pkg.setTextColor(0xaaffffff);pkg.setTextSize(11);texts.addView(pkg);card.addView(texts,new LinearLayout.LayoutParams(0,-1,1f));
            card.setOnClickListener(v->{closeOverlay();showWorkspaceHome(false);beginWidgetBind(info,-1,-1,-1,span[0],span[1]);});
            bindLauncher3LongPress(card,v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);int[] min=launcher3MinimumSpan(info,span[0],span[1]);boolean started=widgetDragController!=null&&widgetDragController.startProvider(v,info.provider,span[0],span[1],min[0],min[1],lastTouchRawX,lastTouchRawY);if(started)v.post(()->{closeOverlay();showWorkspaceHome(false);});return started;});}
        showOverlay(overlay);
    }

    private void showFolderOverlay(String folderId){
        ClassicLayoutStore.Item folder=store.find(folderId);if(folder==null||!ClassicLayoutStore.TYPE_FOLDER.equals(folder.type))return;closeOverlay();
        FrameLayout overlay=createOverlay();LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(14));card.setBackground(round(0xee1a2532,dp(26),0x55ffffff,1));FrameLayout.LayoutParams cardLp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);cardLp.leftMargin=dp(24);cardLp.rightMargin=dp(24);overlay.addView(card,cardLp);card.setOnClickListener(v->{});
        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);EditText title=new EditText(this);title.setSingleLine(true);title.setText(folder.title==null||folder.title.isEmpty()?"Pasta":folder.title);title.setTextColor(Color.WHITE);title.setTextSize(20);title.setHintTextColor(0x88ffffff);title.setBackgroundColor(Color.TRANSPARENT);titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(52),1f));TextView save=roundButton("✓");save.setTextSize(18);save.setOnClickListener(v->{store.renameFolder(folderId,title.getText().toString());workspace.rebuild();toast("Nome da pasta salvo.");});titleRow.addView(save,new LinearLayout.LayoutParams(dp(42),dp(42)));TextView close=roundButton("×");close.setTextSize(20);close.setOnClickListener(v->closeOverlay());titleRow.addView(close,new LinearLayout.LayoutParams(dp(42),dp(42)));card.addView(titleRow);
        TextView hint=new TextView(this);hint.setText("Segure o app para tirar da pasta · segure ☰ para reordenar");hint.setTextColor(0xaaffffff);hint.setTextSize(11);hint.setGravity(Gravity.CENTER);card.addView(hint,new LinearLayout.LayoutParams(-1,dp(28)));
        List<String> members=new ArrayList<>(folder.members);for(int i=0;i<members.size();i+=3){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);card.addView(row,new LinearLayout.LayoutParams(-1,dp(110)));for(int c=0;c<3;c++){int idx=i+c;if(idx>=members.size()){row.addView(new TextView(this),new LinearLayout.LayoutParams(0,-1,1f));continue;}String key=members.get(idx);String[] pair=ClassicLayoutStore.parseComponentKey(key);AppEntry a=resolveApp(pair[0],pair[1]);if(a==null){row.addView(new TextView(this),new LinearLayout.LayoutParams(0,-1,1f));continue;}LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setGravity(Gravity.CENTER);LinearLayout cell=appIconView(a,true);cell.setOnClickListener(v->launch(a.pkg,a.cls));bindLauncher3LongPress(cell,v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);boolean started=itemDragController!=null&&itemDragController.startExternalApp(v,a.pkg,a.cls,folderId,-1,lastTouchRawX,lastTouchRawY);if(started)v.post(this::closeOverlay);return started;});wrap.addView(cell,new LinearLayout.LayoutParams(-1,0,1f));row.addView(wrap,new LinearLayout.LayoutParams(0,-1,1f));}}
        showOverlay(overlay);
    }

    private FrameLayout createOverlay(){FrameLayout overlay=new FrameLayout(this);overlay.setBackgroundColor(0x66000000);overlay.setOnClickListener(v->closeOverlay());return overlay;}
    private LinearLayout createBottomPanel(){LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setBackground(round(0xf21a2532,dp(28),0x44ffffff,1));panel.setOnClickListener(v->{});return panel;}
    private FrameLayout.LayoutParams bottomPanelParams(int topMargin){FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1,Gravity.BOTTOM);lp.topMargin=topMargin;lp.leftMargin=dp(8);lp.rightMargin=dp(8);lp.bottomMargin=dp(8);return lp;}
    private LinearLayout headerRow(String title,View overlay){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(16),dp(4),dp(8),0);TextView t=new TextView(this);t.setText(title);t.setTextColor(Color.WHITE);t.setTextSize(21);t.setGravity(Gravity.CENTER_VERTICAL);row.addView(t,new LinearLayout.LayoutParams(0,dp(54),1f));TextView close=roundButton("×");close.setTextSize(22);close.setOnClickListener(v->closeOverlay());row.addView(close,new LinearLayout.LayoutParams(dp(42),dp(42)));return row;}
    private void showOverlay(View overlay){activeOverlay=overlay;root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));}
    private void closeOverlay(){if(activeOverlay!=null&&root!=null){root.removeView(activeOverlay);activeOverlay=null;}}

    private Drawable widgetPreview(AppWidgetProviderInfo info){try{Drawable d=info.loadPreviewImage(this,getResources().getDisplayMetrics().densityDpi);if(d!=null)return d;}catch(Exception ignored){}try{return info.loadIcon(this,getResources().getDisplayMetrics().densityDpi);}catch(Exception ignored){return null;}}

    private void beginWidgetBind(AppWidgetProviderInfo info,int page,int x,int y,int spanX,int spanY){
        pendingWidgetId=widgetHost.allocateAppWidgetId();pendingWidgetInfo=info;pendingWidgetPage=page;pendingWidgetX=x;pendingWidgetY=y;pendingWidgetSpanX=Math.max(1,spanX);pendingWidgetSpanY=Math.max(1,spanY);int[] pendingMin=launcher3MinimumSpan(info,pendingWidgetSpanX,pendingWidgetSpanY);pendingWidgetMinSpanX=pendingMin[0];pendingWidgetMinSpanY=pendingMin[1];
        Bundle options=new Bundle();boolean allowed=false;try{allowed=widgetManager.bindAppWidgetIdIfAllowed(pendingWidgetId,info.provider,options);}catch(Exception ignored){}
        if(allowed)configureOrAddWidget(pendingWidgetId,info);else{Intent bind=new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId);bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER,info.provider);startActivityForResult(bind,REQ_BIND_WIDGET);}
    }
    private void configureOrAddWidget(int id,AppWidgetProviderInfo info){if(info!=null&&info.configure!=null){Intent i=new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);i.setComponent(info.configure);i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);try{startActivityForResult(i,REQ_CONFIG_WIDGET);return;}catch(Exception ignored){}}addWidgetNow(id,info);}
    private void addWidgetNow(int id,AppWidgetProviderInfo info){
        if(info==null)info=widgetManager.getAppWidgetInfo(id);if(info==null){deletePendingWidget();return;}int[] suggested=workspace.suggestedSpan(info.minWidth,info.minHeight);int sx=Math.max(pendingWidgetSpanX,suggested[0]),sy=Math.max(pendingWidgetSpanY,suggested[1]);int[] min=launcher3MinimumSpan(info,sx,sy);boolean ok;
        if(pendingWidgetPage>=0)ok=workspace.addWidgetAtL3(id,sx,sy,min[0],min[1],pendingWidgetPage,pendingWidgetX,pendingWidgetY);else ok=workspace.addWidgetL3(id,sx,sy,min[0],min[1]);
        if(!ok){try{widgetHost.deleteAppWidgetId(id);}catch(Exception ignored){}toast("Sem espaço para o widget.");}else{final String widgetItem=findWidgetItemId(id);if(widgetItem!=null)uiHandler.postDelayed(()->showLauncher3ResizeFrame(widgetItem),180);}resetPendingWidget();
    }

    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==REQ_PROFILE_PHOTO){
            if(result==RESULT_OK&&data!=null&&data.getData()!=null){
                Uri uri=data.getData();try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(profilePhotoFile())){byte[] buf=new byte[8192];int n;while(in!=null&&(n=in.read(buf))>0)out.write(buf,0,n);out.flush();rebuildLegacyHeaderOnly();}catch(Exception e){toast("Não foi possível salvar a foto.");}
            }
            return;
        }
        if(request==REQ_BIND_WIDGET){int id=data!=null?data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId):pendingWidgetId;if(result==RESULT_OK&&id>0)configureOrAddWidget(id,widgetManager.getAppWidgetInfo(id));else deletePendingWidget();}
        else if(request==REQ_CONFIG_WIDGET){int id=data!=null?data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId):pendingWidgetId;if(result==RESULT_OK&&id>0)addWidgetNow(id,widgetManager.getAppWidgetInfo(id));else deletePendingWidget();}
    }
    private void deletePendingWidget(){if(pendingWidgetId>0)try{widgetHost.deleteAppWidgetId(pendingWidgetId);}catch(Exception ignored){}resetPendingWidget();}
    private void resetPendingWidget(){pendingWidgetId=-1;pendingWidgetInfo=null;pendingWidgetPage=pendingWidgetX=pendingWidgetY=-1;pendingWidgetSpanX=pendingWidgetSpanY=1;pendingWidgetMinSpanX=pendingWidgetMinSpanY=1;}

    @Override protected void onStart(){super.onStart();if(widgetHost!=null)try{widgetHost.startListening();}catch(Exception ignored){}}
    @Override protected void onStop(){if(widgetHost!=null)try{widgetHost.stopListening();}catch(Exception ignored){}super.onStop();}
    @Override protected void onResume(){super.onResume();if(prefs!=null&&!"classic".equals(prefs.getString("homeLayoutMode","feed"))){openFeed();return;}cleanupMissingItems();if(workspace!=null)workspace.rebuild();if(hotseat!=null)buildHotseat();if(showingLegacyHome)renderLegacyInlineGrid();updateCombinedPageIndicator();}

    private void cleanupMissingItems(){
        if(store==null)return;Set<String> installed=new HashSet<>();for(AppEntry a:loadApps())installed.add(a.key);store.pruneMissingComponents(installed);
        ArrayList<Integer> missingWidgets=new ArrayList<>();for(ClassicLayoutStore.Item item:store.items())if(ClassicLayoutStore.TYPE_WIDGET.equals(item.type)&&widgetManager.getAppWidgetInfo(item.appWidgetId)==null)missingWidgets.add(item.appWidgetId);
        for(Integer id:missingWidgets){store.removeWidgetId(id);try{widgetHost.deleteAppWidgetId(id);}catch(Exception ignored){}}
    }

    @Override public void onPageChanged(int page,int count){updateCombinedPageIndicator();}
    @Override public void onLayoutPersisted(){}
    @Override public void onNoSpace(){toast("Sem espaço. Arraste para a borda para criar/trocar página.");}
    @Override public void onRequestAdd(){showHomeEditMenu();}
    @Override public void onRequestLegacyHome(){showLegacyHome(true);}
    @Override public void onExternalAppCommitted(ClassicWorkspace.DragPayload payload){cleanupExternalSource(payload);}
    @Override public void onWidgetDropRequested(ComponentName provider,int page,int cellX,int cellY,int spanX,int spanY){AppWidgetProviderInfo info=findWidgetProvider(provider);if(info==null){toast("Widget indisponível.");return;}beginWidgetBind(info,page,cellX,cellY,spanX,spanY);}
    @Override public void onDragStateChanged(boolean active,ClassicWorkspace.DragPayload payload){if(active)showDragTargets(payload);else{hideDragTargets();if(payload!=null&&payload.dropAccepted&&payload.kind==ClassicWorkspace.DragPayload.KIND_EXISTING){ClassicLayoutStore.Item moved=store.find(payload.itemId);if(moved!=null&&ClassicLayoutStore.TYPE_WIDGET.equals(moved.type))uiHandler.postDelayed(()->showLauncher3ResizeFrame(moved.id),160);}}}

    private boolean rawInside(View v,float rawX,float rawY){
        if(v==null||v.getVisibility()!=View.VISIBLE||v.getWidth()<=0||v.getHeight()<=0)return false;int[] loc=new int[2];v.getLocationOnScreen(loc);
        return rawX>=loc[0]&&rawX<loc[0]+v.getWidth()&&rawY>=loc[1]&&rawY<loc[1]+v.getHeight();
    }

    private void updateInternalDragTargets(float rawX,float rawY){
        if(hotseat!=null)hotseat.setAlpha(rawInside(hotseat,rawX,rawY)?.84f:1f);
        if(dragTargetBar!=null&&dragTargetBar.getVisibility()==View.VISIBLE){
            for(int i=0;i<dragTargetBar.getChildCount();i++){View child=dragTargetBar.getChildAt(i);boolean over=rawInside(child,rawX,rawY);child.animate().cancel();child.setScaleX(over?1.06f:1f);child.setScaleY(over?1.06f:1f);child.setAlpha(over?.80f:1f);}
        }
    }

    private boolean commitInternalDropTarget(ClassicWorkspace.DragPayload p,float rawX,float rawY){
        if(p==null)return false;
        if(dragTargetBar!=null&&dragTargetBar.getVisibility()==View.VISIBLE&&rawInside(dragTargetBar,rawX,rawY)){
            for(int i=0;i<dragTargetBar.getChildCount();i++){View child=dragTargetBar.getChildAt(i);if(rawInside(child,rawX,rawY)&&dragActionSupported(p,i))return performDragAction(p,i);}
        }
        if(hotseat!=null&&rawInside(hotseat,rawX,rawY))return commitInternalHotseatDrop(p,rawX);
        return false;
    }

    private boolean commitInternalHotseatDrop(ClassicWorkspace.DragPayload p,float rawX){
        int[] loc=new int[2];hotseat.getLocationOnScreen(loc);int target=hotseatTargetIndex(rawX-loc[0]);boolean ok=false;
        if(p.kind==ClassicWorkspace.DragPayload.KIND_EXISTING){
            ClassicLayoutStore.Item item=store.find(p.itemId);
            if(item!=null&&ClassicLayoutStore.TYPE_APP.equals(item.type)){String key=ClassicLayoutStore.componentKey(item);insertHotseatKey(key,target);workspace.removeItem(item.id);ok=true;}
        }else if(p.kind==ClassicWorkspace.DragPayload.KIND_APP){
            String key=ClassicLayoutStore.componentKey(p.packageName,p.className);
            if(p.sourceHotseatIndex>=0){removeHotseatKey(key);insertHotseatKey(key,target);ok=true;}
            else{insertHotseatKey(key,target);cleanupExternalSource(p);ok=true;}
        }
        p.dropAccepted=ok;if(ok){saveHotseatState();buildHotseat();}return ok;
    }

    private void resetInternalDragTargets(){
        if(hotseat!=null)hotseat.setAlpha(1f);
        if(dragTargetBar!=null)for(int i=0;i<dragTargetBar.getChildCount();i++){View child=dragTargetBar.getChildAt(i);child.animate().cancel();child.setScaleX(1f);child.setScaleY(1f);child.setAlpha(1f);}
    }

    private void showDragTargets(ClassicWorkspace.DragPayload payload){
        if(root==null)return;if(dragTargetBar==null){dragTargetBar=new LinearLayout(this);dragTargetBar.setGravity(Gravity.CENTER);dragTargetBar.setPadding(dp(8),dp(6),dp(8),dp(6));dragTargetBar.setBackground(round(0xe81a2532,dp(24),0x55ffffff,1));
            dragTargetBar.addView(dragTarget("Remover",0),new LinearLayout.LayoutParams(0,-1,1f));dragTargetBar.addView(dragTarget("Info",1),new LinearLayout.LayoutParams(0,-1,1f));dragTargetBar.addView(dragTarget("Desinstalar",2),new LinearLayout.LayoutParams(0,-1,1f));
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(56),Gravity.TOP);lp.leftMargin=dp(18);lp.rightMargin=dp(18);lp.topMargin=dp(4);root.addView(dragTargetBar,lp);}
        dragTargetBar.setVisibility(View.VISIBLE);dragTargetBar.setAlpha(1f);
    }

    private TextView dragTarget(String label,int action){
        TextView t=new TextView(this);t.setText(label);t.setTextColor(action==0?0xffffb0b0:Color.WHITE);t.setTextSize(13);t.setGravity(Gravity.CENTER);t.setBackground(round(0x33ffffff,dp(16),0x33ffffff,1));
        return t;
    }

    private boolean dragActionSupported(ClassicWorkspace.DragPayload p,int action){
        if(action==0){if(p.kind==ClassicWorkspace.DragPayload.KIND_EXISTING)return true;return p.kind==ClassicWorkspace.DragPayload.KIND_APP&&(p.sourceFolderId!=null||p.sourceHotseatIndex>=0);}
        return payloadPackage(p)!=null;
    }

    private boolean performDragAction(ClassicWorkspace.DragPayload p,int action){
        if(action==0){
            if(p.kind==ClassicWorkspace.DragPayload.KIND_EXISTING){ClassicLayoutStore.Item item=store.find(p.itemId);if(item==null)return false;if(ClassicLayoutStore.TYPE_WIDGET.equals(item.type)){try{widgetHost.deleteAppWidgetId(item.appWidgetId);}catch(Exception ignored){}}workspace.removeItem(item.id);p.dropAccepted=true;return true;}
            if(p.kind==ClassicWorkspace.DragPayload.KIND_APP){String key=ClassicLayoutStore.componentKey(p.packageName,p.className);if(p.sourceFolderId!=null){store.removeFolderMember(p.sourceFolderId,key);workspace.rebuild();p.dropAccepted=true;return true;}if(p.sourceHotseatIndex>=0){removeHotseatKey(key);buildHotseat();p.dropAccepted=true;return true;}}return false;
        }
        String pkg=payloadPackage(p);if(pkg==null)return false;p.keepSource=true;
        try{Intent i=new Intent(action==1?Settings.ACTION_APPLICATION_DETAILS_SETTINGS:Intent.ACTION_DELETE,Uri.parse("package:"+pkg));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);p.dropAccepted=true;return true;}catch(Exception e){toast(action==1?"Informações do app indisponíveis.":"Desinstalação indisponível.");return false;}
    }

    private String payloadPackage(ClassicWorkspace.DragPayload p){
        if(p==null)return null;if(p.kind==ClassicWorkspace.DragPayload.KIND_APP)return p.packageName==null||p.packageName.isEmpty()?null:p.packageName;
        if(p.kind==ClassicWorkspace.DragPayload.KIND_EXISTING){ClassicLayoutStore.Item item=store.find(p.itemId);if(item==null)return null;if(ClassicLayoutStore.TYPE_APP.equals(item.type))return item.packageName;if(ClassicLayoutStore.TYPE_WIDGET.equals(item.type)){AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(item.appWidgetId);return info==null?null:info.provider.getPackageName();}}return null;
    }

    private void hideDragTargets(){if(dragTargetBar!=null)dragTargetBar.setVisibility(View.GONE);}

    private void cleanupExternalSource(ClassicWorkspace.DragPayload p){
        if(p.keepSource)return;
        boolean rebuild=false;if(p.sourceFolderId!=null){store.removeFolderMember(p.sourceFolderId,ClassicLayoutStore.componentKey(p.packageName,p.className));rebuild=true;}
        if(p.sourceHotseatIndex>=0){removeHotseatKey(ClassicLayoutStore.componentKey(p.packageName,p.className));buildHotseat();}
        if(rebuild)workspace.rebuild();
    }

    private AppWidgetProviderInfo findWidgetProvider(ComponentName provider){for(AppWidgetProviderInfo info:widgetManager.getInstalledProviders())if(provider.equals(info.provider))return info;return null;}
    private List<AppEntry> loadApps(){Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> rs=getPackageManager().queryIntentActivities(i,0);ArrayList<AppEntry> out=new ArrayList<>();for(ResolveInfo r:rs){if(r.activityInfo==null)continue;ComponentName c=new ComponentName(r.activityInfo.packageName,r.activityInfo.name);if(getPackageName().equals(c.getPackageName()))continue;AppEntry a=new AppEntry();a.label=String.valueOf(r.loadLabel(getPackageManager()));a.pkg=c.getPackageName();a.cls=c.getClassName();a.key=ClassicLayoutStore.componentKey(a.pkg,a.cls);try{a.icon=r.loadIcon(getPackageManager());}catch(Exception ignored){}out.add(a);}Collator collator=Collator.getInstance(new Locale("pt","BR"));Collections.sort(out,(a,b)->collator.compare(a.label,b.label));return out;}
    private AppEntry resolveApp(String pkg,String cls){if(pkg==null||cls==null||pkg.isEmpty()||cls.isEmpty())return null;Intent intent=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(pkg,cls));ResolveInfo r=getPackageManager().resolveActivity(intent,0);if(r==null||r.activityInfo==null)return null;AppEntry a=new AppEntry();a.label=String.valueOf(r.loadLabel(getPackageManager()));a.pkg=pkg;a.cls=cls;a.key=ClassicLayoutStore.componentKey(pkg,cls);try{a.icon=r.loadIcon(getPackageManager());}catch(Exception ignored){}return a;}
    private AppEntry findApp(List<AppEntry> list,String key){for(AppEntry a:list)if(a.key.equals(key))return a;return null;}
    private String widgetAppLabel(AppWidgetProviderInfo info){try{android.content.pm.ApplicationInfo ai=getPackageManager().getApplicationInfo(info.provider.getPackageName(),0);CharSequence c=getPackageManager().getApplicationLabel(ai);return c==null?info.provider.getPackageName():c.toString();}catch(Exception e){return info.provider.getPackageName();}}
    private String labelForWidget(AppWidgetProviderInfo info){try{CharSequence c=info.loadLabel(getPackageManager());return c==null?info.provider.getClassName():c.toString();}catch(Exception e){return info.provider.getClassName();}}
    private void launch(String pkg,String cls){try{Intent i=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(pkg,cls)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){toast("Não foi possível abrir o aplicativo.");}}

    @Override public void onBackPressed(){if(activeOverlay!=null){closeOverlay();return;}if(!showingLegacyHome){showLegacyHome(true);return;}/* Home screen: back does not leave the launcher. */}
    private void switchToFeed(){prefs.edit().putString("homeLayoutMode","feed").apply();openFeed();}
    private void openFeed(){Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}
    private ArrayList<String> splitPref(String key){String raw=prefs.getString(key,"");ArrayList<String> out=new ArrayList<>();if(raw!=null&&!raw.isEmpty())Collections.addAll(out,raw.split(SEP,-1));return out;}
    private TextView roundButton(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(25);t.setGravity(Gravity.CENTER);t.setBackground(round(0xa91b2838,dp(22),0x55ffffff,1));return t;}
    private GradientDrawable round(int color,int radius,int strokeColor,int strokeDp){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);if(strokeDp>0)g.setStroke(dp(strokeDp),strokeColor);return g;}
    private int dp(float n){return (int)(n*density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
