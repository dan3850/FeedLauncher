package br.com.danilo.feedlauncher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.text.*;
import android.util.LruCache;
import android.view.*;
import android.widget.*;

import org.json.*;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.*;
import java.lang.ref.WeakReference;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

final class NewsPanelController extends ContextThemeWrapper {
    final MainActivity host;
    final Dialog panel;
    boolean created=false, disposed=false;
    FrameLayout panelRootView;
    View panelDimView;
    LinearLayout searchBoxView;
    TextView refreshActionView, menuActionView, panelHintView, searchGlyphView, searchGoView;
    long topicGeneration=0L;
    String loadingTopic="";
    final Object imageWaiterLock=new Object();
    final HashMap<String,ArrayList<WeakReference<ImageView>>> imageWaiters=new HashMap<>();

    NewsPanelController(MainActivity host) {
        super(host, R.style.AppTheme);
        this.host=host;
        this.panel=new Dialog(host, R.style.AppTheme){
            @Override public boolean dispatchTouchEvent(MotionEvent ev){
                if(NewsPanelController.this.handlePanelTouchEvent(ev))return true;
                return super.dispatchTouchEvent(ev);
            }
        };
        this.panel.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.panel.setOnDismissListener(d->{
            if(this.host.newsPanel==this)this.host.newsPanel=null;
            this.host.onNewsPanelVisibilityChanged(false);
        });
        this.panel.setOnKeyListener((d,key,event)->{
            if(key==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_UP){finishPanel();return true;}
            return false;
        });
    }

    void show(){
        disposed=false;
        if(!created){onCreate(null);created=true;}
        panel.show();
        host.onNewsPanelVisibilityChanged(true);
        Window w=panel.getWindow();
        if(w!=null){
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setGravity(Gravity.FILL);
        }
        onResume();
    }
    boolean isShowing(){return panel.isShowing();}
    void dismiss(){
        disposed=true;topicGeneration++;loading=false;loadingTopic="";
        synchronized(imageWaiterLock){imageWaiters.clear();}
        if(panel.isShowing())panel.dismiss();
    }
    boolean isControllerActive(){return !disposed&&host.newsPanel==this&&!host.isFinishing()&&!host.isDestroyed();}
    void executeNetwork(Runnable task){
        if(task==null||disposed)return;
        host.newsNetworkTaskCount++;
        try{host.networkExecutor.execute(task);}catch(Exception ignored){}
    }
    Window getWindow(){return panel.getWindow();}
    void setContentView(View v){panel.setContentView(v);}
    void runOnUiThread(Runnable r){host.runOnUiThread(r);}

    final String[] topics = {"Para você", "Destaques", "Brasil", "Tecnologia", "Games", "Esportes", "Entretenimento"};
    final String[] topicKeys = {"foryou", "top", "brasil", "tech", "games", "sports", "entertainment"};

    final String[] interestLabels = {"Brasil", "Tecnologia", "Games", "Esportes", "Entretenimento", "Economia", "Ciência", "Mundo", "Automóveis", "Android", "Inteligência Artificial", "Nintendo", "PlayStation", "Xbox", "PC"};
    final String[] interestKeys = {"brasil", "tech", "games", "sports", "entertainment", "economy", "science", "world", "autos", "android", "ai", "nintendo", "playstation", "xbox", "pc"};
    final String[] interestQueries = {"Brasil", "tecnologia", "games OR videogames", "esportes OR futebol", "entretenimento OR cinema OR séries", "economia OR mercado", "ciência OR espaço", "mundo OR internacional", "automóveis OR carros", "Android", "inteligência artificial OR IA", "Nintendo OR Switch", "PlayStation OR PS5", "Xbox", "PC gaming OR computador"};

    LinearLayout list, chips, trends, smartCards;
    TextView status, panelTitle;
    EditText newsSearch;
    ScrollView newsScroll;
    SharedPreferences prefs;
    String selectedTopic = "foryou";
    int bg = 0xff020f1d, accent = 0xff187cff;
    int themeFg = Color.WHITE, themeSubtle = 0xff9db8d5, themeSurface = 0xff0b2136, themeSurface2 = 0xff10273d, themeBorder = 0x66538bc0;
    UnifiedThemeRuntime.Style themeStyle;
    String appliedThemeSignature = "";
    GestureDetector gestures;
    boolean loading = false;
    boolean viewingSaved = false;
    boolean viewingHistory = false;
    float pullStartY = 0f, pullStartX = 0f;
    boolean pulling = false;
    float panelDownX = 0f, panelDownY = 0f;
    int panelGestureAxis = 0; // 0 undecided, 1 horizontal, 2 vertical
    boolean panelGestureBlocked = false;
    int panelTouchSlop = 0;
    VelocityTracker panelVelocity;
    final ArrayList<NewsItem> currentItems = new ArrayList<>();

    final LruCache<String, Bitmap> imageMemory = new LruCache<String, Bitmap>(10 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value == null ? 0 : value.getByteCount(); }
    };

    static class NewsItem {
        String title = "";
        String link = "";
        String source = "";
        String pubDate = "";
        String image = "";
        String summary = "";
    }

    static class ScoreInfo {
        String home = "", away = "", homeShort = "", awayShort = "";
        String homeScore = "", awayScore = "", homeLogo = "", awayLogo = "";
        String status = "", detail = "", eventDate = "";
        boolean live = false;
    }

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    TextView text(String s, int size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    int blend(int a,int b,float f){ return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f)); }
    boolean isLightTheme(){
        String mode=prefs==null?"dark":prefs.getString("themeMode","dark");
        if("light".equals(mode))return true;
        if("auto".equals(mode))return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)!=android.content.res.Configuration.UI_MODE_NIGHT_YES;
        if("schedule".equals(mode)){
            int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY),start=prefs.getInt("themeScheduleLightStart",7),end=prefs.getInt("themeScheduleLightEnd",19);
            return start==end || (start<end?(h>=start&&h<end):(h>=start||h<end));
        }
        return false;
    }
    boolean themeGradientEnabled(){return prefs!=null&&prefs.getBoolean("themeGradientEnabled",false);}
    boolean themeGradientThird(){return prefs!=null&&prefs.getBoolean("themeGradientThird",false);}
    int themeBase(){return prefs==null?0xff187cff:prefs.getInt("themeBaseColor",0xff187cff);}
    int themeColor2(){return prefs==null?themeBase():prefs.getInt("themeGradientColor2",blend(themeBase(),Color.WHITE,.18f));}
    int themeColor3(){return prefs==null?themeColor2():prefs.getInt("themeGradientColor3",themeColor2());}
    GradientDrawable.Orientation themeGradientOrientation(){
        int a=((prefs==null?135:prefs.getInt("themeGradientAngle",135))%360+360)%360;
        if(a<23||a>=338)return GradientDrawable.Orientation.LEFT_RIGHT;if(a<68)return GradientDrawable.Orientation.TL_BR;if(a<113)return GradientDrawable.Orientation.TOP_BOTTOM;if(a<158)return GradientDrawable.Orientation.TR_BL;if(a<203)return GradientDrawable.Orientation.RIGHT_LEFT;if(a<248)return GradientDrawable.Orientation.BR_TL;if(a<293)return GradientDrawable.Orientation.BOTTOM_TOP;return GradientDrawable.Orientation.BL_TR;
    }
    int readableText(int c){
        double lum=(.2126*Color.red(c)+.7152*Color.green(c)+.0722*Color.blue(c))/255.0;
        return lum>.61?0xff172033:Color.WHITE;
    }
    void loadThemePalette(){
        themeStyle=UnifiedThemeRuntime.load(prefs);
        if(themeStyle==null){
            // Fallback visual local caso o painel ainda não tenha recebido o snapshot unificado.
            // O caminho normal recebe o tema publicado pela Home antes de abrir.
            boolean light=isLightTheme();int base=themeBase();
            boolean override=prefs!=null&&prefs.getBoolean("themeAccentOverrideEnabled",false);
            accent=override?prefs.getInt("themeAccentColor",base):base;
            bg=(prefs!=null&&prefs.getBoolean("themeAmoled",false)&&!light)?Color.BLACK:(light?blend(0xfff7f9fc,base,.025f):blend(0xff06111d,base,.075f));
            themeSurface=light?blend(bg,base,.075f):blend(bg,base,.19f);themeSurface2=light?blend(bg,base,.115f):blend(bg,base,.27f);themeFg=readableText(themeSurface);themeSubtle=blend(themeFg,themeSurface,.42f);themeBorder=blend(themeSurface,accent,light?.25f:.42f);
            themeStyle=new UnifiedThemeRuntime.Style();themeStyle.light=light;themeStyle.bg=bg;themeStyle.fg=themeFg;themeStyle.subtle=themeSubtle;themeStyle.accent=accent;themeStyle.primary=themeSurface;themeStyle.sub=themeSurface2;themeStyle.tertiary=themeSurface2;themeStyle.button=themeSurface2;themeStyle.selected=accent;themeStyle.border=themeBorder;themeStyle.dialog=themeSurface;
            themeStyle.baseColor=base;themeStyle.gradientColor2=themeColor2();themeStyle.gradientColor3=themeColor3();themeStyle.gradientAngle=prefs==null?135:prefs.getInt("themeGradientAngle",135);themeStyle.gradientStrength=prefs==null?80:prefs.getInt("themeGradientStrength",80);themeStyle.harmonyStrength=prefs==null?72:prefs.getInt("themeHarmonyStrength",72);themeStyle.depth=prefs==null?68:prefs.getInt("themeDepth",68);themeStyle.gradientEnabled=themeGradientEnabled();themeStyle.gradientThird=themeGradientThird();themeStyle.colorStyle=prefs==null?"solid":prefs.getString("themeColorStyle","solid");themeStyle.effectMode=prefs==null?"off":prefs.getString("surfaceEffectMode",prefs.getBoolean("glassEffect",true)?"glass":"off");themeStyle.glassIntensity=prefs==null?65:prefs.getInt("glassIntensity",65);themeStyle.blurIntensity=prefs==null?62:prefs.getInt("blurIntensity",62);themeStyle.borderStrength=prefs==null?55:prefs.getInt("surfaceBorderStrength",55);themeStyle.cornerRadius=prefs==null?14:prefs.getInt("cornerRadius",14);themeStyle.cardAlpha=prefs==null?238:prefs.getInt("cardAlpha",238);themeStyle.homeCardAlpha=themeStyle.cardAlpha;themeStyle.effectSubcards=prefs==null||prefs.getBoolean("themeEffectSubcards",true);themeStyle.effectButtons=prefs==null||prefs.getBoolean("themeEffectButtons",true);themeStyle.signature=UnifiedThemeRuntime.signature(themeStyle);
        }
        bg=themeStyle.bg;accent=themeStyle.accent;themeFg=themeStyle.fg;themeSubtle=themeStyle.subtle;themeSurface=themeStyle.primary;themeSurface2=themeStyle.sub;themeBorder=themeStyle.border;appliedThemeSignature=themeSignature();
    }
    String themeSignature(){
        String shared=prefs==null?"":prefs.getString(UnifiedThemeRuntime.P+"signature","");
        if(!shared.isEmpty())return shared;
        return themeStyle==null?"":UnifiedThemeRuntime.signature(themeStyle);
    }
    GradientDrawable themedSurface(int variant){return variant<=0?UnifiedThemeRuntime.homeCard(this,themeStyle):UnifiedThemeRuntime.subCard(this,themeStyle);}
    GradientDrawable themedPill(boolean active){return UnifiedThemeRuntime.button(this,themeStyle,active);}
    Drawable themedRootBackground(){return new ColorDrawable(themeStyle==null?bg:themeStyle.bg);}
    void themeNewsDialogTree(View v){
        if(v==null)return;
        if(v instanceof EditText){EditText e=(EditText)v;e.setTextColor(themeFg);e.setHintTextColor(themeSubtle);}
        else if(v instanceof TextView && !(v instanceof Button))((TextView)v).setTextColor(themeFg);
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)themeNewsDialogTree(g.getChildAt(i));}
    }
    void applyNewsDialogTheme(AlertDialog dialog){
        if(dialog==null)return;Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(UnifiedThemeRuntime.dialog(this,themeStyle));w.setNavigationBarColor(bg);themeNewsDialogTree(w.getDecorView());}
        ListView listView=dialog.getListView();if(listView!=null){listView.setBackground(themedSurface(1));listView.setDivider(new ColorDrawable(themeBorder));listView.setDividerHeight(dp(1));}
        int[] ids={AlertDialog.BUTTON_POSITIVE,AlertDialog.BUTTON_NEGATIVE,AlertDialog.BUTTON_NEUTRAL};for(int id:ids){Button b=dialog.getButton(id);if(b!=null){b.setTextColor(themeFg);b.setAllCaps(false);b.setBackground(UnifiedThemeRuntime.button(this,themeStyle,false));}}
    }
    class NewsDialogBuilder extends AlertDialog.Builder{
        NewsDialogBuilder(Context c){super(c);}
        @Override public AlertDialog show(){AlertDialog d=super.show();applyNewsDialogTheme(d);return d;}
    }

    void onCreate(Bundle state) {
        prefs = getSharedPreferences("feed", MODE_PRIVATE);
        ensureDefaults();
        loadThemePalette();
        prefs.edit().putString("runtimeNewsUnifiedThemeApplied", appliedThemeSignature+" · "+(themeStyle==null?"?":themeStyle.effectMode)).apply();
        selectedTopic = prefs.getString("newsTopic", "foryou");
        build();
        setupGestures();
        loadTopic(selectedTopic, true);
    }


    void onResume(){
        if(prefs==null)return;
        String sig=themeSignature();
        if(appliedThemeSignature!=null&&!appliedThemeSignature.isEmpty()&&!appliedThemeSignature.equals(sig)&&newsScroll!=null)applyThemeInPlace();
    }

    void applyThemeInPlace(){
        if(newsScroll==null)return;
        int oldY=newsScroll.getScrollY();
        ArrayList<NewsItem> keep=new ArrayList<>(currentItems);
        loadThemePalette();
        prefs.edit().putString("runtimeNewsUnifiedThemeApplied", appliedThemeSignature+" · "+(themeStyle==null?"?":themeStyle.effectMode)).apply();
        if(panelRootView!=null)panelRootView.setBackground(themedRootBackground());
        if(panelDimView!=null)panelDimView.setBackgroundColor(Color.argb(isLightTheme()?70:128,Color.red(bg),Color.green(bg),Color.blue(bg)));
        Window w=getWindow();if(w!=null){w.setStatusBarColor(bg);w.setNavigationBarColor(bg);}
        if(panelTitle!=null)panelTitle.setTextColor(themeFg);
        if(refreshActionView!=null)refreshActionView.setTextColor(accent);
        if(menuActionView!=null)menuActionView.setTextColor(accent);
        if(panelHintView!=null)panelHintView.setTextColor(themeSubtle);
        if(searchBoxView!=null)searchBoxView.setBackground(themedSurface(0));
        if(searchGlyphView!=null)searchGlyphView.setTextColor(accent);
        if(searchGoView!=null)searchGoView.setTextColor(accent);
        if(newsSearch!=null){newsSearch.setTextColor(themeFg);newsSearch.setHintTextColor(themeSubtle);}
        if(status!=null)status.setTextColor(themeSubtle);
        renderSmartCards();renderChips();
        if(!keep.isEmpty())renderNews(keep);
        host.newsThemeLiveApplyCount++;
        newsScroll.post(()->newsScroll.scrollTo(0,oldY));
    }

    void ensureDefaults() {
        if (!prefs.contains("newsInterests")) {
            HashSet<String> defaults = new HashSet<>();
            defaults.add("brasil"); defaults.add("tech"); defaults.add("games");
            prefs.edit().putStringSet("newsInterests", defaults).apply();
        }
    }

    void build() {
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        FrameLayout root = new FrameLayout(this);panelRootView=root;
        root.setBackground(themedRootBackground());

        File wp = new File(getFilesDir(), "wallpaper.jpg");
        if (wp.exists()) {
            Bitmap b = BitmapFactory.decodeFile(wp.getAbsolutePath());
            if (b != null) {
                ImageView wallpaper = new ImageView(this);
                wallpaper.setImageBitmap(b);
                wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
                root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));
                View dim = new View(this);panelDimView=dim;
                dim.setBackgroundColor(Color.argb(isLightTheme()?70:128,Color.red(bg),Color.green(bg),Color.blue(bg)));
                root.addView(dim, new FrameLayout.LayoutParams(-1, -1));
            }
        }

        newsScroll = new ScrollView(this);
        newsScroll.setFillViewport(true);
        newsScroll.setVerticalScrollBarEnabled(false);
        ScrollView scroll = newsScroll;
        LinearLayout content = col();
        content.setPadding(dp(16), dp(10), dp(16), dp(60));
        scroll.addView(content);

        LinearLayout header = row();
        panelTitle = text("Notícias", 28, themeFg);
        panelTitle.setTypeface(null, 1);
        header.addView(panelTitle, new LinearLayout.LayoutParams(0, dp(54), 1));
        TextView refresh = text("↻", 28, accent);refreshActionView=refresh;
        refresh.setGravity(Gravity.CENTER);
        refresh.setContentDescription("Atualizar notícias");
        header.addView(refresh, new LinearLayout.LayoutParams(dp(48), dp(48)));
        refresh.setOnClickListener(v -> { if (viewingSaved) showSavedArticles(); else if (viewingHistory) showHistoryArticles(); else loadTopic(selectedTopic, false); });
        TextView menu = text("⋮", 28, accent);menuActionView=menu;
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Opções das notícias");
        header.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(48)));
        menu.setOnClickListener(v -> showInfo());
        content.addView(header);

        TextView hint = text("Deslize para a esquerda para voltar · puxe para baixo para atualizar", 10, themeSubtle);panelHintView=hint;
        hint.setPadding(1, 0, 0, dp(10));
        content.addView(hint);

        LinearLayout searchBox = row();searchBoxView=searchBox;
        searchBox.setPadding(dp(12), 0, dp(8), 0);
        searchBox.setBackground(themedSurface(0));
        TextView magnify = text("⌕", 25, accent);searchGlyphView=magnify; magnify.setGravity(Gravity.CENTER); magnify.setContentDescription("Pesquisar no Google");
        searchBox.addView(magnify, new LinearLayout.LayoutParams(dp(38), dp(46)));
        newsSearch = new EditText(this); newsSearch.setSingleLine(true); newsSearch.setTextSize(13); newsSearch.setTextColor(themeFg); newsSearch.setHintTextColor(themeSubtle); newsSearch.setHint("Pesquisar no Google…"); newsSearch.setBackgroundColor(Color.TRANSPARENT);
        newsSearch.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        searchBox.addView(newsSearch, new LinearLayout.LayoutParams(0, dp(46), 1));
        TextView googleSearch = text("Ir", 12, accent);searchGoView=googleSearch; googleSearch.setTypeface(null, 1); googleSearch.setGravity(Gravity.CENTER); googleSearch.setContentDescription("Abrir pesquisa no Google");
        searchBox.addView(googleSearch, new LinearLayout.LayoutParams(dp(44), dp(46)));
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(46)); searchLp.setMargins(0, 0, 0, dp(10)); content.addView(searchBox, searchLp);
        View.OnClickListener runGoogleSearch = v -> openGoogleSearch(newsSearch.getText().toString());
        magnify.setOnClickListener(runGoogleSearch); googleSearch.setOnClickListener(runGoogleSearch);
        newsSearch.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_ENTER;
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH || enter) { openGoogleSearch(newsSearch.getText().toString()); return true; }
            return false;
        });

        HorizontalScrollView infoScroll = new HorizontalScrollView(this);
        infoScroll.setHorizontalScrollBarEnabled(false);
        smartCards = row();
        smartCards.setPadding(0, dp(2), 0, dp(12));
        infoScroll.addView(smartCards);
        content.addView(infoScroll);
        renderSmartCards();
        loadSmartCards();

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        chips = row();
        chips.setPadding(0, dp(4), 0, dp(14));
        hsv.addView(chips);
        content.addView(hsv);
        renderChips();

        status = text("Carregando notícias…", 11, themeSubtle);
        status.setPadding(dp(4), dp(4), dp(4), dp(8));
        content.addView(status);

        trends = row();
        trends.setPadding(0, 0, 0, dp(10));
        content.addView(trends);

        list = col();
        content.addView(list);

        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        root.setOnApplyWindowInsetsListener((v, in) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = in.getInsets(WindowInsets.Type.systemBars());
                scroll.setPadding(0, bars.top, 0, bars.bottom);
            }
            return in;
        });
    }

    void renderSmartCards() {
        if (smartCards == null) return;
        smartCards.removeAllViews();

        String city = prefs.getString("city", "").trim();
        String temp = prefs.getString("newsWeatherTemp", "");
        String condition = prefs.getString("newsWeatherCondition", "");
        String aqi = prefs.getString("newsWeatherAqi", "");
        String sunset = prefs.getString("newsSunset", "");
        if (temp.isEmpty()) {
            String old = prefs.getString("weatherText", "");
            String[] lines = old.split("\n");
            if (lines.length > 0 && lines[0].contains("°")) temp = lines[0];
            if (city.isEmpty() && lines.length > 1) city = lines[1];
            if (condition.isEmpty() && lines.length > 2) condition = lines[2];
        }

        final String cityForClick = city;
        String weatherDetail = condition;
        if (!aqi.isEmpty()) weatherDetail += (weatherDetail.isEmpty() ? "" : "  ·  ") + "AQI " + aqi;
        addSmartCard(city.isEmpty() ? "Clima" : city,
                temp.isEmpty() ? (city.isEmpty() ? "Configurar" : "Atualizando…") : temp,
                weatherDetail.isEmpty() ? (city.isEmpty() ? "Defina uma cidade no launcher" : "Tempo agora") : weatherDetail,
                "☁", v -> {
                    if (cityForClick.isEmpty()) { Toast.makeText(this, "Configure sua cidade no clima do FeedLauncher", Toast.LENGTH_SHORT).show(); finishPanel(); }
                    else openGoogleSearch("clima " + cityForClick);
                }, 172);

        addSmartCard("Pôr do sol hoje", sunset.isEmpty() ? "—" : sunset,
                sunset.isEmpty() ? (city.isEmpty() ? "Configure o clima" : "Atualizando…") : "Horário local", "◒", null, 164);

        renderScoreCard();
    }

    void renderScoreCard() {
        String favoriteTeam = prefs.getString("newsFavoriteTeam", "").trim();
        if (favoriteTeam.isEmpty()) {
            LinearLayout card = col();
            card.setPadding(dp(14), dp(12), dp(14), dp(11));
            card.setBackground(themedSurface(0));
            TextView title = text("Placar", 12, themeFg); card.addView(title);
            TextView ball = text("⚽  Escolher time", 18, themeFg); ball.setPadding(0, dp(12), 0, dp(5)); card.addView(ball);
            TextView hint = text("Mostra jogo ao vivo, último ou próximo", 10, themeSubtle); card.addView(hint);
            card.setOnClickListener(v -> chooseFavoriteTeam());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(220), dp(116)); lp.setMargins(0,0,dp(9),0); smartCards.addView(card, lp);
            return;
        }

        String home = prefs.getString("newsScoreHome", "");
        String away = prefs.getString("newsScoreAway", "");
        if (home.isEmpty() || away.isEmpty()) {
            LinearLayout card = col(); card.setPadding(dp(14),dp(12),dp(14),dp(11)); card.setBackground(themedSurface(0));
            LinearLayout top=row(); TextView title=text(favoriteTeam,12,themeFg); title.setSingleLine(); title.setEllipsize(TextUtils.TruncateAt.END); top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
            TextView refresh=text("↻",18,accent); refresh.setGravity(Gravity.CENTER); top.addView(refresh,new LinearLayout.LayoutParams(dp(32),dp(28))); card.addView(top);
            TextView value=text(prefs.getBoolean("newsScoreLoading", false)?"Buscando placar…":"Sem jogo encontrado",16,themeFg); value.setPadding(0,dp(11),0,dp(6)); card.addView(value);
            TextView hint=text("Toque para atualizar · segure para trocar o time",10,themeSubtle); card.addView(hint);
            card.setOnClickListener(v->loadSportsScore(true)); card.setOnLongClickListener(v->{chooseFavoriteTeam();return true;});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(232),dp(116));lp.setMargins(0,0,dp(9),0);smartCards.addView(card,lp);return;
        }

        String hs = prefs.getString("newsScoreHomeScore", "-");
        String as = prefs.getString("newsScoreAwayScore", "-");
        String statusText = prefs.getString("newsScoreStatus", "");
        String detail = prefs.getString("newsScoreDetail", "");
        String homeLogo = prefs.getString("newsScoreHomeLogo", "");
        String awayLogo = prefs.getString("newsScoreAwayLogo", "");
        String homeShort = prefs.getString("newsScoreHomeShort", home);
        String awayShort = prefs.getString("newsScoreAwayShort", away);

        LinearLayout card=col();card.setPadding(dp(12),dp(10),dp(12),dp(9));card.setBackground(themedSurface(0));
        LinearLayout top=row();TextView title=text(favoriteTeam,11,themeFg);title.setSingleLine();title.setEllipsize(TextUtils.TruncateAt.END);top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView state=text(statusText.isEmpty()?"JOGO":statusText,10,themeFg);state.setGravity(Gravity.CENTER);state.setPadding(dp(8),dp(3),dp(8),dp(3));state.setBackground(prefs.getBoolean("newsScoreLive",false)?rounded(0xffb3261e,12,themeBorder):UnifiedThemeRuntime.button(this,themeStyle,false));top.addView(state);card.addView(top);

        LinearLayout score=row();score.setGravity(Gravity.CENTER_VERTICAL);score.setPadding(0,dp(6),0,0);
        ImageView homeImage=new ImageView(this);homeImage.setScaleType(ImageView.ScaleType.FIT_CENTER);score.addView(homeImage,new LinearLayout.LayoutParams(dp(34),dp(34)));if(!homeLogo.isEmpty())loadImage(homeImage,homeLogo);
        TextView homeName=text(shortTeam(homeShort),10,themeFg);homeName.setGravity(Gravity.CENTER);homeName.setMaxLines(1);score.addView(homeName,new LinearLayout.LayoutParams(dp(48),-2));
        TextView scoreText=text(hs+"  -  "+as,22,themeFg);scoreText.setTypeface(null,1);scoreText.setGravity(Gravity.CENTER);score.addView(scoreText,new LinearLayout.LayoutParams(0,-2,1));
        TextView awayName=text(shortTeam(awayShort),10,themeFg);awayName.setGravity(Gravity.CENTER);awayName.setMaxLines(1);score.addView(awayName,new LinearLayout.LayoutParams(dp(48),-2));
        ImageView awayImage=new ImageView(this);awayImage.setScaleType(ImageView.ScaleType.FIT_CENTER);score.addView(awayImage,new LinearLayout.LayoutParams(dp(34),dp(34)));if(!awayLogo.isEmpty())loadImage(awayImage,awayLogo);card.addView(score);
        TextView detailView=text(detail,9,themeSubtle);detailView.setGravity(Gravity.CENTER);detailView.setSingleLine();detailView.setEllipsize(TextUtils.TruncateAt.END);detailView.setPadding(0,dp(4),0,0);card.addView(detailView);
        card.setOnClickListener(v->loadSportsScore(true));card.setOnLongClickListener(v->{chooseFavoriteTeam();return true;});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(254),dp(116));lp.setMargins(0,0,dp(9),0);smartCards.addView(card,lp);
    }

    String shortTeam(String value) {
        if (value == null) return "";
        String v=value.trim();
        if (v.length() <= 7) return v;
        String[] parts=v.split("\\s+");
        if(parts.length>1){StringBuilder b=new StringBuilder();for(String part:parts)if(!part.isEmpty())b.append(Character.toUpperCase(part.charAt(0)));if(b.length()>=2&&b.length()<=5)return b.toString();}
        return v.substring(0, Math.min(6,v.length()));
    }

    void addSmartCard(String title, String value, String detail, String icon, View.OnClickListener click, int widthDp) {
        LinearLayout card = col();
        card.setPadding(dp(14), dp(12), dp(14), dp(11));
        card.setBackground(themedSurface(0));
        TextView titleView = text(title, 12, themeFg); titleView.setMaxLines(1); titleView.setEllipsize(TextUtils.TruncateAt.END); card.addView(titleView);
        LinearLayout middle = row(); middle.setPadding(0, dp(7), 0, 0);
        TextView valueView = text(value, value.length() > 20 ? 14 : 21, themeFg); valueView.setTypeface(null, value.length() > 20 ? 1 : 0); valueView.setMaxLines(value.length() > 20 ? 2 : 1); valueView.setEllipsize(TextUtils.TruncateAt.END); middle.addView(valueView, new LinearLayout.LayoutParams(0, -2, 1));
        TextView iconView = text(icon, 22, accent); iconView.setGravity(Gravity.CENTER); middle.addView(iconView, new LinearLayout.LayoutParams(dp(36), dp(36))); card.addView(middle);
        TextView detailView = text(detail == null ? "" : detail, 10, themeSubtle); detailView.setMaxLines(1); detailView.setEllipsize(TextUtils.TruncateAt.END); detailView.setPadding(0, dp(5), 0, 0); card.addView(detailView);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(116)); lp.setMargins(0, 0, dp(9), 0); smartCards.addView(card, lp);
        if (click != null) { card.setClickable(true); card.setOnClickListener(click); }
    }

    String shortenCardText(String value, int max) {
        if (value == null) return "";
        String clean = value.trim();
        return clean.length() <= max ? clean : clean.substring(0, Math.max(1, max - 1)).trim() + "…";
    }

    void openSportsTopic() {
        viewingSaved = false; viewingHistory = false; selectedTopic = "sports";
        prefs.edit().putString("newsTopic", selectedTopic).apply();
        panelTitle.setText("Notícias"); renderChips(); loadTopic("sports", true);
    }

    void loadSmartCards() {
        loadWeatherSmartCards();
        loadSportsScore(false);
    }

    void loadWeatherSmartCards() {
        final String lat = prefs.getString("lat", "");
        final String lon = prefs.getString("lon", "");
        if (lat.isEmpty() || lon.isEmpty()) { renderSmartCards(); return; }
        long weatherUpdated=prefs.getLong("newsWeatherUpdated",0L);
        if(System.currentTimeMillis()-weatherUpdated<10L*60L*1000L&&!prefs.getString("newsWeatherTemp","").isEmpty()){renderSmartCards();return;}
        executeNetwork(() -> {
            try {
                String forecastUrl = "https://api.open-meteo.com/v1/forecast?latitude=" + URLEncoder.encode(lat, "UTF-8") + "&longitude=" + URLEncoder.encode(lon, "UTF-8") + "&current=temperature_2m,weather_code&daily=sunset&timezone=auto";
                JSONObject forecast = getJson(forecastUrl);
                JSONObject current = forecast.optJSONObject("current");
                String temp = current == null ? "" : Math.round(current.optDouble("temperature_2m", 0)) + "°C";
                String condition = current == null ? "" : weatherCondition(current.optInt("weather_code", -1));
                String sunset = "";
                JSONObject daily = forecast.optJSONObject("daily");
                if (daily != null) { JSONArray sunsets = daily.optJSONArray("sunset"); if (sunsets != null && sunsets.length() > 0) sunset = formatIsoTime(sunsets.optString(0)); }
                String aqi = "";
                try {
                    JSONObject air = getJson("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=" + URLEncoder.encode(lat, "UTF-8") + "&longitude=" + URLEncoder.encode(lon, "UTF-8") + "&current=us_aqi&timezone=auto");
                    JSONObject ac = air.optJSONObject("current"); if (ac != null && ac.has("us_aqi")) aqi = String.valueOf(Math.round(ac.optDouble("us_aqi", 0)));
                } catch (Exception ignored) {}
                prefs.edit().putString("newsWeatherTemp", temp).putString("newsWeatherCondition", condition).putString("newsSunset", sunset).putString("newsWeatherAqi", aqi).putLong("newsWeatherUpdated",System.currentTimeMillis()).apply();
                runOnUiThread(()->{if(isControllerActive())renderSmartCards();});
            } catch (Exception ignored) { runOnUiThread(()->{if(isControllerActive())renderSmartCards();}); }
        });
    }

    void loadSportsScore(boolean force) {
        final String team = prefs.getString("newsFavoriteTeam", "").trim();
        if (team.isEmpty()) { clearScoreCache(); renderSmartCards(); return; }
        long last = prefs.getLong("newsScoreUpdated", 0L);
        if (!force && System.currentTimeMillis() - last < 180000L && !prefs.getString("newsScoreHome", "").isEmpty()) { renderSmartCards(); return; }
        if (prefs.getBoolean("newsScoreLoading", false) && !force) return;
        prefs.edit().putBoolean("newsScoreLoading", true).apply(); renderSmartCards();
        executeNetwork(() -> {
            try {
                ScoreInfo info = fetchFavoriteTeamScore(team);
                SharedPreferences.Editor ed=prefs.edit().putBoolean("newsScoreLoading",false).putLong("newsScoreUpdated",System.currentTimeMillis());
                if(info==null){
                    ed.remove("newsScoreHome").remove("newsScoreAway").remove("newsScoreHomeScore").remove("newsScoreAwayScore").remove("newsScoreHomeLogo").remove("newsScoreAwayLogo").remove("newsScoreHomeShort").remove("newsScoreAwayShort").remove("newsScoreStatus").remove("newsScoreDetail").putBoolean("newsScoreLive",false).apply();
                }else{
                    ed.putString("newsScoreHome",info.home).putString("newsScoreAway",info.away).putString("newsScoreHomeShort",info.homeShort).putString("newsScoreAwayShort",info.awayShort)
                      .putString("newsScoreHomeScore",info.homeScore).putString("newsScoreAwayScore",info.awayScore).putString("newsScoreHomeLogo",info.homeLogo).putString("newsScoreAwayLogo",info.awayLogo)
                      .putString("newsScoreStatus",info.status).putString("newsScoreDetail",info.detail).putBoolean("newsScoreLive",info.live).apply();
                }
                runOnUiThread(()->{if(isControllerActive())renderSmartCards();});
            } catch (Exception e) { prefs.edit().putBoolean("newsScoreLoading",false).apply(); runOnUiThread(()->{if(isControllerActive())renderSmartCards();}); }
        });
    }

    void clearScoreCache(){ prefs.edit().remove("newsScoreHome").remove("newsScoreAway").remove("newsScoreHomeScore").remove("newsScoreAwayScore").remove("newsScoreHomeLogo").remove("newsScoreAwayLogo").remove("newsScoreHomeShort").remove("newsScoreAwayShort").remove("newsScoreStatus").remove("newsScoreDetail").remove("newsScoreUpdated").putBoolean("newsScoreLive",false).putBoolean("newsScoreLoading",false).apply(); }

    ScoreInfo fetchFavoriteTeamScore(String favorite) throws Exception {
        Calendar from=Calendar.getInstance();from.add(Calendar.DAY_OF_YEAR,-7);Calendar to=Calendar.getInstance();to.add(Calendar.DAY_OF_YEAR,7);
        SimpleDateFormat df=new SimpleDateFormat("yyyyMMdd",Locale.US);
        String range=df.format(from.getTime())+"-"+df.format(to.getTime());
        JSONObject root=getJson("https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates="+range+"&limit=300");
        JSONArray events=root.optJSONArray("events");if(events==null)return null;
        String needle=normalizeTeam(favorite);ScoreInfo best=null;int bestRank=99;long bestDistance=Long.MAX_VALUE;long now=System.currentTimeMillis();
        for(int i=0;i<events.length();i++){
            JSONObject event=events.optJSONObject(i);if(event==null)continue;JSONArray comps=event.optJSONArray("competitions");if(comps==null||comps.length()==0)continue;JSONObject comp=comps.optJSONObject(0);if(comp==null)continue;JSONArray competitors=comp.optJSONArray("competitors");if(competitors==null||competitors.length()<2)continue;
            JSONObject homeObj=null,awayObj=null;boolean match=false;
            for(int j=0;j<competitors.length();j++){JSONObject co=competitors.optJSONObject(j);if(co==null)continue;JSONObject team=co.optJSONObject("team");String name=team==null?"":team.optString("displayName",team.optString("name",""));String shortName=team==null?"":team.optString("shortDisplayName",team.optString("abbreviation",name));if(teamMatches(needle,name)||teamMatches(needle,shortName)||teamMatches(needle,team==null?"":team.optString("abbreviation","")))match=true;if("home".equals(co.optString("homeAway")))homeObj=co;else if("away".equals(co.optString("homeAway")))awayObj=co;}
            if(!match||homeObj==null||awayObj==null)continue;
            JSONObject type=event.optJSONObject("status")==null?null:event.optJSONObject("status").optJSONObject("type");String state=type==null?"":type.optString("state","");long when=dateMillis(event.optString("date",""));int rank="in".equals(state)?0:(when>=now?1:2);long dist=Math.abs(when-now);if(rank>bestRank||(rank==bestRank&&dist>=bestDistance))continue;
            ScoreInfo info=new ScoreInfo();fillCompetitor(info,homeObj,true);fillCompetitor(info,awayObj,false);info.live="in".equals(state);info.eventDate=event.optString("date","");info.status=scoreStatus(type,state,when);String eventName=event.optString("shortName",event.optString("name",""));info.detail=scoreDetail(eventName,state,when);best=info;bestRank=rank;bestDistance=dist;
        }
        return best;
    }

    void fillCompetitor(ScoreInfo info, JSONObject co, boolean homeSide){
        JSONObject team=co.optJSONObject("team");String name=team==null?"":team.optString("displayName",team.optString("name",""));String shortName=team==null?name:team.optString("abbreviation",team.optString("shortDisplayName",name));String logo=team==null?"":team.optString("logo","");String score=co.optString("score","-");
        if(homeSide){info.home=name;info.homeShort=shortName;info.homeLogo=logo;info.homeScore=score;}else{info.away=name;info.awayShort=shortName;info.awayLogo=logo;info.awayScore=score;}
    }

    String scoreStatus(JSONObject type,String state,long when){
        if(type!=null){String shortDetail=type.optString("shortDetail","");if("in".equals(state)&&!shortDetail.isEmpty())return shortDetail;if("post".equals(state))return "ENC";}
        if(when>0){Calendar d=Calendar.getInstance();d.setTimeInMillis(when);Calendar n=Calendar.getInstance();boolean today=d.get(Calendar.YEAR)==n.get(Calendar.YEAR)&&d.get(Calendar.DAY_OF_YEAR)==n.get(Calendar.DAY_OF_YEAR);return new SimpleDateFormat(today?"HH:mm":"dd/MM",Locale.getDefault()).format(new Date(when));}
        return "JOGO";
    }

    String scoreDetail(String eventName,String state,long when){
        if("in".equals(state))return "Ao vivo"+(eventName.isEmpty()?"":" · "+eventName);
        if("post".equals(state))return "Encerrado"+(eventName.isEmpty()?"":" · "+eventName);
        String whenText=when>0?new SimpleDateFormat("EEE, HH:mm",new Locale("pt","BR")).format(new Date(when)):"Próximo jogo";return whenText+(eventName.isEmpty()?"":" · "+eventName);
    }

    String normalizeTeam(String value){if(value==null)return"";return Normalizer.normalize(value,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(new Locale("pt","BR")).replaceAll("[^a-z0-9]","");}
    boolean teamMatches(String needle,String candidate){String c=normalizeTeam(candidate);return !needle.isEmpty()&&!c.isEmpty()&&(c.contains(needle)||needle.contains(c));}

    JSONObject getJson(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(9000); c.setRequestProperty("User-Agent", "FeedLauncher/0.10.14");
        try {
            if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
            ByteArrayOutputStream out = new ByteArrayOutputStream(); InputStream in = c.getInputStream(); byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) != -1) out.write(b, 0, n); in.close(); return new JSONObject(out.toString("UTF-8"));
        } finally { c.disconnect(); }
    }

    String formatIsoTime(String iso) {
        if (iso == null || iso.length() < 16) return iso == null ? "" : iso;
        try { return iso.substring(11, 16); } catch (Exception ignored) { return iso; }
    }

    String weatherCondition(int code) {
        if (code == 0) return "Céu limpo";
        if (code == 1 || code == 2) return "Parcialmente nublado";
        if (code == 3) return "Nublado";
        if (code == 45 || code == 48) return "Nevoeiro";
        if (code >= 51 && code <= 57) return "Garoa";
        if (code >= 61 && code <= 67) return "Chuva";
        if (code >= 71 && code <= 77) return "Neve";
        if (code >= 80 && code <= 82) return "Pancadas";
        if (code >= 95) return "Trovoadas";
        return "Tempo agora";
    }

    void enrichMissingImages(ArrayList<NewsItem> items) {
        int attempts = 0;
        for (NewsItem item : items) {
            if (attempts >= 5) break;
            if (item.image != null && !item.image.trim().isEmpty()) continue;
            attempts++;
            try { String found = discoverArticleImage(item.link); if (!found.isEmpty()) item.image = found; } catch (Exception ignored) {}
        }
    }

    String discoverArticleImage(String link) throws Exception {
        if (link == null || link.isEmpty()) return "";
        HttpURLConnection c = (HttpURLConnection)new URL(link).openConnection();
        c.setInstanceFollowRedirects(true); c.setConnectTimeout(3000); c.setReadTimeout(4000); c.setRequestProperty("User-Agent", "Mozilla/5.0 FeedLauncher/0.10.14");
        try {
            int code = c.getResponseCode(); if (code < 200 || code >= 400) return "";
            URL finalUrl = c.getURL(); InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[4096]; int n, total = 0;
            while ((n = in.read(buf)) != -1 && total < 180000) { int take = Math.min(n, 180000 - total); out.write(buf, 0, take); total += take; }
            in.close(); String html = out.toString("UTF-8"); String image = metaImage(html);
            if (image.isEmpty()) return "";
            try { return new URL(finalUrl, image).toString(); } catch (Exception ignored) { return image; }
        } finally { c.disconnect(); }
    }

    String metaImage(String html) {
        if (html == null || html.isEmpty()) return "";
        String[] patterns = {
                "(?is)<meta[^>]+(?:property|name)=[\\\"'](?:og:image|twitter:image(?::src)?)[\\\"'][^>]+content=[\\\"']([^\\\"']+)",
                "(?is)<meta[^>]+content=[\\\"']([^\\\"']+)[\\\"'][^>]+(?:property|name)=[\\\"'](?:og:image|twitter:image(?::src)?)[\\\"']",
                "(?is)<link[^>]+rel=[\\\"']image_src[\\\"'][^>]+href=[\\\"']([^\\\"']+)"
        };
        for (String pattern : patterns) { Matcher m = Pattern.compile(pattern).matcher(html); if (m.find()) return m.group(1).replace("&amp;", "&").trim(); }
        return "";
    }

    void renderChips() {
        chips.removeAllViews();
        for (int i = 0; i < topics.length; i++) {
            final String key = topicKeys[i];
            boolean active = !viewingSaved && !viewingHistory && key.equals(selectedTopic);
            TextView chip = text(topics[i], 12, readableText(active?accent:themeSurface2));
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(15), 0, dp(15), 0);
            GradientDrawable d = themedPill(active);
            chip.setBackground(d);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
            lp.setMargins(0, 0, dp(8), 0);
            chips.addView(chip, lp);
            chip.setOnClickListener(v -> {
                viewingSaved = false; viewingHistory = false;
                panelTitle.setText("Notícias");
                if (key.equals(selectedTopic)) { renderChips(); return; }
                selectedTopic = key;
                prefs.edit().putString("newsTopic", key).apply();
                renderChips();
                loadTopic(key, true);
            });
        }
    }

    GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    void loadTopic(String key, boolean showCacheFirst) {
        if(key==null||key.isEmpty()||disposed)return;
        // Tocar em outro tópico enquanto uma consulta está em andamento não fica mais
        // preso no resultado antigo. A geração mais nova vence; resultados obsoletos
        // são descartados sem tocar na UI.
        if(loading&&key.equals(loadingTopic))return;
        viewingSaved = false; viewingHistory = false;
        panelTitle.setText("Notícias");
        renderChips();
        if (showCacheFirst) {
            ArrayList<NewsItem> cached = readCache(key);
            if (!cached.isEmpty()) {
                renderNews(cached);
                status.setText("Atualizando…");
            } else {
                list.removeAllViews();
                status.setText("Carregando notícias…");
            }
        } else status.setText("Atualizando…");

        final long generation=++topicGeneration;
        final String requestedKey=key;
        loading = true;loadingTopic=key;
        executeNetwork(() -> {
            try {
                ArrayList<NewsItem> items = fetchNews(requestedKey);
                if (items.isEmpty()) throw new IOException("Feed vazio");
                saveCache(requestedKey, items);
                runOnUiThread(() -> {
                    if(!isControllerActive()||generation!=topicGeneration){host.newsStaleResultIgnoredCount++;return;}
                    loading = false;loadingTopic="";
                    renderNews(items);
                    status.setText("Atualizado agora · toque em uma matéria para abrir");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if(!isControllerActive()||generation!=topicGeneration){host.newsStaleResultIgnoredCount++;return;}
                    loading = false;loadingTopic="";
                    ArrayList<NewsItem> cached = readCache(requestedKey);
                    if (!cached.isEmpty()) {
                        renderNews(cached);
                        status.setText("Sem atualização · mostrando a última versão salva");
                    } else {
                        status.setText("Não foi possível carregar as notícias. Verifique sua conexão.");
                        showEmpty();
                    }
                });
            }
        });
    }

    String urlFor(String key) throws Exception {
        String base = "https://news.google.com/rss";
        String suffix = "?hl=pt-BR&gl=BR&ceid=BR:pt-419";
        if ("foryou".equals(key)) {
            String query = personalizedQuery();
            return query.isEmpty() ? base + suffix : base + "/search?q=" + URLEncoder.encode(query, "UTF-8") + "&hl=pt-BR&gl=BR&ceid=BR:pt-419";
        }
        if ("tech".equals(key)) return base + "/headlines/section/topic/TECHNOLOGY" + suffix;
        if ("sports".equals(key)) return base + "/headlines/section/topic/SPORTS" + suffix;
        if ("entertainment".equals(key)) return base + "/headlines/section/topic/ENTERTAINMENT" + suffix;
        if ("brasil".equals(key)) return base + "/search?q=" + URLEncoder.encode("Brasil", "UTF-8") + "&hl=pt-BR&gl=BR&ceid=BR:pt-419";
        if ("games".equals(key)) return base + "/search?q=" + URLEncoder.encode("games OR videogames", "UTF-8") + "&hl=pt-BR&gl=BR&ceid=BR:pt-419";
        return base + suffix;
    }

    String personalizedQuery() {
        Set<String> chosen = new HashSet<>(prefs.getStringSet("newsInterests", Collections.emptySet()));
        ArrayList<String> parts = new ArrayList<>();
        for (int i = 0; i < interestKeys.length; i++) if (chosen.contains(interestKeys[i])) parts.add("(" + interestQueries[i] + ")");
        if (parts.isEmpty()) return "";
        return TextUtils.join(" OR ", parts);
    }

    ArrayList<NewsItem> fetchNews(String key) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(urlFor(key)).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 FeedLauncher/0.10.14");
        if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
        ArrayList<NewsItem> out = new ArrayList<>();
        try (InputStream in = c.getInputStream()) {
            XmlPullParserFactory f = XmlPullParserFactory.newInstance();
            f.setNamespaceAware(true);
            XmlPullParser p = f.newPullParser();
            p.setInput(in, "UTF-8");
            NewsItem current = null;
            int event = p.getEventType();
            while (event != XmlPullParser.END_DOCUMENT && out.size() < 28) {
                if (event == XmlPullParser.START_TAG) {
                    String name = p.getName();
                    if ("item".equalsIgnoreCase(name)) current = new NewsItem();
                    else if (current != null) {
                        if ("title".equalsIgnoreCase(name)) current.title = clean(p.nextText());
                        else if ("link".equalsIgnoreCase(name)) current.link = p.nextText().trim();
                        else if ("pubDate".equalsIgnoreCase(name)) current.pubDate = p.nextText().trim();
                        else if ("source".equalsIgnoreCase(name)) current.source = clean(p.nextText());
                        else if ("description".equalsIgnoreCase(name)) {
                            String desc = p.nextText();
                            String image = imageFromHtml(desc);
                            if (!image.isEmpty()) current.image = image;
                            String plain = clean(desc);
                            current.summary = cleanSummary(plain, current.title, current.source);
                        } else if (("content".equalsIgnoreCase(name) || "thumbnail".equalsIgnoreCase(name)) && p.getAttributeValue(null, "url") != null) {
                            current.image = p.getAttributeValue(null, "url");
                        }
                    }
                } else if (event == XmlPullParser.END_TAG && "item".equalsIgnoreCase(p.getName()) && current != null) {
                    if (!current.title.isEmpty() && !current.link.isEmpty()) {
                        if (current.source.isEmpty()) current.source = sourceFromTitle(current.title);
                        current.title = stripSourceSuffix(current.title, current.source);
                        if (!isSourceHidden(current.source) && !isArticleHidden(current.link)) out.add(current);
                    }
                    current = null;
                }
                event = p.next();
            }
        } finally { c.disconnect(); }
        enrichMissingImages(out);
        sortPreferredSources(out);
        if ("foryou".equals(key)) sortReadLast(out);
        return out;
    }

    void sortPreferredSources(ArrayList<NewsItem> items) {
        final Set<String> preferred = new HashSet<>(prefs.getStringSet("newsPreferredSources", Collections.emptySet()));
        Collections.sort(items, (a, b) -> {
            boolean ap = preferred.contains(a.source), bp = preferred.contains(b.source);
            if (ap != bp) return ap ? -1 : 1;
            return Long.compare(dateMillis(b.pubDate), dateMillis(a.pubDate));
        });
    }

    boolean isSourceHidden(String source) {
        return source != null && prefs.getStringSet("newsHiddenSources", Collections.emptySet()).contains(source);
    }

    boolean isArticleHidden(String link) {
        return link != null && prefs.getStringSet("newsHiddenArticles", Collections.emptySet()).contains(link);
    }

    boolean isRead(String link) {
        return link != null && prefs.getStringSet("newsReadLinks", Collections.emptySet()).contains(link);
    }

    void markRead(NewsItem item) {
        if (item == null || item.link == null || item.link.isEmpty()) return;
        HashSet<String> read = new HashSet<>(prefs.getStringSet("newsReadLinks", Collections.emptySet()));
        if (read.add(item.link)) prefs.edit().putStringSet("newsReadLinks", read).apply();
        ArrayList<NewsItem> history = readItemsJson(prefs.getString("newsHistoryItems", "[]"));
        for (Iterator<NewsItem> it = history.iterator(); it.hasNext();) if (item.link.equals(it.next().link)) it.remove();
        history.add(0, item);
        try { prefs.edit().putString("newsHistoryItems", itemsToJson(history, 80).toString()).apply(); } catch (Exception ignored) {}
    }

    void sortReadLast(ArrayList<NewsItem> items) {
        final Set<String> preferred = new HashSet<>(prefs.getStringSet("newsPreferredSources", Collections.emptySet()));
        Collections.sort(items, (a, b) -> {
            boolean ar = isRead(a.link), br = isRead(b.link);
            if (ar != br) return ar ? 1 : -1;
            boolean ap = preferred.contains(a.source), bp = preferred.contains(b.source);
            if (ap != bp) return ap ? -1 : 1;
            return Long.compare(dateMillis(b.pubDate), dateMillis(a.pubDate));
        });
    }

    String cleanSummary(String plain, String title, String source) {
        if (plain == null) return "";
        String out = plain.replaceAll("\\s+", " ").trim();
        if (title != null && !title.isEmpty() && out.startsWith(title)) out = out.substring(Math.min(out.length(), title.length())).trim();
        if (source != null && !source.isEmpty()) out = out.replace(" - " + source, "").trim();
        if (out.length() > 240) out = out.substring(0, 237).trim() + "…";
        return out;
    }

    String detectedInterestKey(NewsItem item) {
        String hay = ((item == null ? "" : item.title + " " + item.summary)).toLowerCase(new Locale("pt", "BR"));
        String[][] words = {
                {"android","android"},{"ai","inteligência artificial","inteligencia artificial"," ia ","chatgpt","openai"},
                {"nintendo","nintendo","switch"},{"playstation","playstation","ps5","ps4"},{"xbox","xbox"},{"pc","pc gaming","computador"},
                {"games","game","games","videogame"},{"sports","futebol","esporte","campeonato"},{"autos","carro","automóvel","automovel"},
                {"economy","economia","mercado","bolsa"},{"science","ciência","ciencia","espaço","espaco"},{"entertainment","filme","cinema","série","serie"}
        };
        for (String[] group : words) for (int i = 1; i < group.length; i++) if (hay.contains(group[i])) return group[0];
        return "";
    }

    String interestLabelForKey(String key) {
        for (int i = 0; i < interestKeys.length; i++) if (interestKeys[i].equals(key)) return interestLabels[i];
        return "este assunto";
    }

    String clean(String s) {
        if (s == null) return "";
        if (Build.VERSION.SDK_INT >= 24) return Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().trim();
        return Html.fromHtml(s).toString().trim();
    }

    String imageFromHtml(String html) {
        if (html == null) return "";
        Matcher m = Pattern.compile("(?i)<img[^>]+src=[\\\"']([^\\\"']+)").matcher(html);
        return m.find() ? m.group(1).replace("&amp;", "&") : "";
    }

    String sourceFromTitle(String title) {
        int at = title.lastIndexOf(" - ");
        return at > 0 && at < title.length() - 3 ? title.substring(at + 3).trim() : "Notícias";
    }

    String stripSourceSuffix(String title, String source) {
        if (source == null || source.isEmpty()) return title;
        String suffix = " - " + source;
        return title.endsWith(suffix) ? title.substring(0, title.length() - suffix.length()).trim() : title;
    }

    void renderNews(ArrayList<NewsItem> items) {
        currentItems.clear();
        if (items != null) currentItems.addAll(items);
        if ("sports".equals(selectedTopic) && !currentItems.isEmpty()) {
            NewsItem top = currentItems.get(0);
            prefs.edit().putString("newsSportsTitle", top.title).putString("newsSportsSource", top.source).apply();
            renderSmartCards();
        }
        updateTrending(currentItems);
        displayNews(currentItems);
    }

    // Mantido para chamadas internas que precisam apenas redesenhar a lista.
    // A caixa de pesquisa agora abre uma pesquisa Google, em vez de filtrar o RSS local.
    void applyNewsSearch() { if (list != null) displayNews(currentItems); }

    void openGoogleSearch(String rawQuery) {
        String q = rawQuery == null ? "" : rawQuery.trim();
        if (q.isEmpty()) { Toast.makeText(this, "Digite algo para pesquisar", Toast.LENGTH_SHORT).show(); return; }
        try {
            String url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8");
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir a pesquisa Google", Toast.LENGTH_SHORT).show();
        }
    }

    void displayNews(ArrayList<NewsItem> items) {
        list.removeAllViews();
        if (items == null || items.isEmpty()) { showEmpty(); return; }
        int limit = Math.min(items.size(), prefs.getBoolean("newsCompact", false) ? 24 : 18);
        for (int i = 0; i < limit; i++) addNewsCard(items.get(i), i == 0 && !prefs.getBoolean("newsCompact", false));
    }

    void updateTrending(ArrayList<NewsItem> items) {
        if (trends == null) return;
        trends.removeAllViews();
        ArrayList<String> words = trendingWords(items);
        if (words.isEmpty()) return;
        TextView label = text("Em alta", 10, themeSubtle); label.setPadding(dp(2),0,dp(8),0); trends.addView(label);
        for (int i = 0; i < Math.min(3, words.size()); i++) {
            final String word = words.get(i);
            TextView t = text(word, 10, themeFg); t.setGravity(Gravity.CENTER); t.setPadding(dp(10),0,dp(10),0); t.setBackground(themedPill(false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(30)); lp.setMargins(0,0,dp(6),0); trends.addView(t,lp);
            t.setOnClickListener(v -> { newsSearch.setText(word); openGoogleSearch(word); });
        }
    }

    ArrayList<String> trendingWords(ArrayList<NewsItem> items) {
        HashMap<String,Integer> count = new HashMap<>();
        HashSet<String> stop = new HashSet<>(Arrays.asList("para","como","com","sem","uma","um","dos","das","de","da","do","e","em","no","na","nos","nas","que","por","mais","sobre","após","apos","novo","nova","hoje","brasil"));
        for (NewsItem n : items) {
            String clean = (n.title == null ? "" : n.title).toLowerCase(new Locale("pt","BR")).replaceAll("[^\\p{L}\\p{N}]+"," ");
            HashSet<String> once = new HashSet<>();
            for (String w : clean.split("\\s+")) if (w.length() >= 4 && !stop.contains(w) && once.add(w)) count.put(w, count.containsKey(w) ? count.get(w)+1 : 1);
        }
        ArrayList<String> out = new ArrayList<>(count.keySet());
        Collections.sort(out, (a,b) -> { int c = Integer.compare(count.get(b), count.get(a)); return c != 0 ? c : a.compareTo(b); });
        ArrayList<String> filtered = new ArrayList<>();
        for (String w : out) if (count.get(w) >= 2) { filtered.add(Character.toUpperCase(w.charAt(0)) + w.substring(1)); if (filtered.size() >= 6) break; }
        return filtered;
    }

    void addNewsCard(NewsItem item, boolean hero) {
        LinearLayout card = col();
        card.setPadding(dp(14), dp(14), dp(14), dp(13));
        card.setBackground(themedSurface(0));

        if (item.image != null && !item.image.isEmpty()) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(themedSurface(1));
            image.setClipToOutline(true);
            card.addView(image, new LinearLayout.LayoutParams(-1, dp(hero ? 220 : 166)));
            loadImage(image, item.image);
        } else {
            FrameLayout visual = new FrameLayout(this); visual.setBackground(themedSurface(1));
            TextView sourceVisual = text((item.source == null || item.source.isEmpty() ? "NOTÍCIAS" : item.source).toUpperCase(new Locale("pt","BR")), hero ? 20 : 16, themeFg); sourceVisual.setTypeface(null, 1); sourceVisual.setGravity(Gravity.CENTER); sourceVisual.setPadding(dp(18), dp(10), dp(18), dp(10)); visual.addView(sourceVisual, new FrameLayout.LayoutParams(-1, -1));
            card.addView(visual, new LinearLayout.LayoutParams(-1, dp(hero ? 188 : 132)));
        }

        TextView title = text(item.title, hero ? 21 : 17, themeFg);
        title.setTypeface(null, 1);
        title.setMaxLines(hero ? 4 : 3);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(0, dp(12), 0, dp(10));
        card.addView(title);

        if (item.summary != null && !item.summary.isEmpty() && !prefs.getBoolean("newsCompact", false)) {
            TextView summary = text(item.summary, 12, themeSubtle);
            summary.setMaxLines(hero ? 3 : 2);
            summary.setEllipsize(TextUtils.TruncateAt.END);
            summary.setPadding(0, 0, 0, dp(9));
            card.addView(summary);
        }

        LinearLayout meta = row();
        TextView source = text(item.source.isEmpty() ? "Notícias" : item.source, 11, blend(themeFg,accent,.20f));
        source.setSingleLine(true);
        source.setEllipsize(TextUtils.TruncateAt.END);
        meta.addView(source, new LinearLayout.LayoutParams(0, -2, 1));
        if (isRead(item.link)) {
            TextView read = text("Lida", 9, themeSubtle); read.setPadding(dp(8),0,0,0); meta.addView(read);
            card.setAlpha(.82f);
        }
        TextView time = text(relativeTime(item.pubDate), 10, themeSubtle);
        time.setPadding(dp(8), 0, dp(4), 0);
        meta.addView(time);
        TextView more = text("⋮", 22, accent);
        more.setGravity(Gravity.CENTER);
        more.setContentDescription("Opções da matéria");
        meta.addView(more, new LinearLayout.LayoutParams(dp(40), dp(40)));
        card.addView(meta);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        list.addView(card, lp);
        card.setOnClickListener(v -> showReader(item));
        card.setOnLongClickListener(v -> { showArticleOptions(item); return true; });
        more.setOnClickListener(v -> showArticleOptions(item));
    }

    void showReader(NewsItem item) {
        markRead(item);
        LinearLayout root = col(); root.setPadding(dp(14), dp(8), dp(14), dp(4));
        if (item.image != null && !item.image.isEmpty()) {
            ImageView image = new ImageView(this); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setBackground(themedSurface(1)); image.setClipToOutline(true); root.addView(image, new LinearLayout.LayoutParams(-1, dp(190))); loadImage(image, item.image);
        }
        TextView title = text(item.title, 19, themeFg); title.setTypeface(null, 1); title.setPadding(0, dp(12), 0, dp(8)); root.addView(title);
        TextView meta = text((item.source.isEmpty()?"Notícias":item.source) + (relativeTime(item.pubDate).isEmpty()?"":" · "+relativeTime(item.pubDate)), 11, themeSubtle); root.addView(meta);
        String body = item.summary == null || item.summary.isEmpty() ? "O feed não forneceu um resumo desta matéria. Você pode abrir a publicação original para ler o conteúdo completo." : item.summary;
        TextView summary = text(body, 14, themeFg); summary.setLineSpacing(0f, 1.15f); summary.setPadding(0, dp(14), 0, dp(6)); root.addView(summary);
        ScrollView sc = new ScrollView(this); sc.addView(root); sc.setFillViewport(false);
        new NewsDialogBuilder(this).setTitle("Modo leitura").setView(sc)
                .setNegativeButton("Fechar", (d,w)->{ if (!viewingSaved) applyNewsSearch(); })
                .setNeutralButton(isSaved(item.link)?"Remover dos salvos":"Salvar", (d,w)->toggleSaved(item))
                .setPositiveButton("Abrir matéria", (d,w)->openArticle(item)).show();
    }

    void openArticle(NewsItem item) {
        markRead(item);
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.link))); }
        catch (Exception e) { Toast.makeText(this, "Não foi possível abrir esta matéria.", Toast.LENGTH_SHORT).show(); }
    }

    void showArticleOptions(NewsItem item) {
        boolean saved = isSaved(item.link);
        boolean preferred = prefs.getStringSet("newsPreferredSources", Collections.emptySet()).contains(item.source);
        String interestKey = detectedInterestKey(item);
        ArrayList<String> labels = new ArrayList<>();
        labels.add("Modo leitura");
        labels.add("Abrir matéria no navegador");
        labels.add(saved ? "Remover dos salvos" : "Salvar matéria");
        if (!interestKey.isEmpty()) labels.add("Menos notícias sobre " + interestLabelForKey(interestKey));
        labels.add("Não tenho interesse nesta matéria");
        if (!item.source.isEmpty()) labels.add(preferred ? "Deixar de priorizar " + item.source : "Priorizar " + item.source);
        if (!item.source.isEmpty()) labels.add("Não mostrar " + item.source);
        labels.add("Compartilhar");
        new NewsDialogBuilder(this).setTitle(item.source.isEmpty() ? "Opções" : item.source).setItems(labels.toArray(new String[0]), (d, which) -> {
            int pos = 0;
            if (which == pos++) { showReader(item); return; }
            if (which == pos++) { openArticle(item); return; }
            if (which == pos++) { toggleSaved(item); return; }
            if (!interestKey.isEmpty() && which == pos++) { muteInterest(interestKey); return; }
            if (which == pos++) { hideArticle(item); return; }
            if (!item.source.isEmpty()) {
                if (which == pos++) { togglePreferredSource(item.source); return; }
                if (which == pos++) { hideSource(item.source); return; }
            }
            if (which == pos) shareArticle(item);
        }).show();
    }

    void hideArticle(NewsItem item) {
        HashSet<String> hidden = new HashSet<>(prefs.getStringSet("newsHiddenArticles", Collections.emptySet()));
        hidden.add(item.link); prefs.edit().putStringSet("newsHiddenArticles", hidden).apply();
        Toast.makeText(this, "Matéria removida do seu painel", Toast.LENGTH_SHORT).show();
        currentItems.remove(item); updateTrending(currentItems); applyNewsSearch();
    }

    void muteInterest(String key) {
        HashSet<String> muted = new HashSet<>(prefs.getStringSet("newsMutedTopics", Collections.emptySet())); muted.add(key);
        HashSet<String> interests = new HashSet<>(prefs.getStringSet("newsInterests", Collections.emptySet())); interests.remove(key);
        prefs.edit().putStringSet("newsMutedTopics", muted).putStringSet("newsInterests", interests).apply();
        Toast.makeText(this, "Menos notícias sobre " + interestLabelForKey(key), Toast.LENGTH_SHORT).show();
        selectedTopic = "foryou"; prefs.edit().putString("newsTopic", "foryou").apply(); loadTopic("foryou", false);
    }

    void shareArticle(NewsItem item) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, item.title);
            send.putExtra(Intent.EXTRA_TEXT, item.title + "\n" + item.link);
            startActivity(Intent.createChooser(send, "Compartilhar notícia"));
        } catch (Exception e) { Toast.makeText(this, "Não foi possível compartilhar.", Toast.LENGTH_SHORT).show(); }
    }

    void togglePreferredSource(String source) {
        HashSet<String> set = new HashSet<>(prefs.getStringSet("newsPreferredSources", Collections.emptySet()));
        boolean add = !set.contains(source);
        if (add) set.add(source); else set.remove(source);
        prefs.edit().putStringSet("newsPreferredSources", set).apply();
        Toast.makeText(this, add ? source + " priorizada" : source + " removida das favoritas", Toast.LENGTH_SHORT).show();
        if (viewingSaved) showSavedArticles(); else if (viewingHistory) showHistoryArticles(); else loadTopic(selectedTopic, true);
    }

    void hideSource(String source) {
        new NewsDialogBuilder(this).setTitle("Ocultar fonte").setMessage("Não mostrar mais notícias de “" + source + "” neste painel?").setNegativeButton("Cancelar", null).setPositiveButton("Ocultar", (d, w) -> {
            HashSet<String> hidden = new HashSet<>(prefs.getStringSet("newsHiddenSources", Collections.emptySet()));
            hidden.add(source);
            prefs.edit().putStringSet("newsHiddenSources", hidden).apply();
            Toast.makeText(this, source + " ocultada", Toast.LENGTH_SHORT).show();
            if (viewingSaved) showSavedArticles(); else if (viewingHistory) showHistoryArticles(); else loadTopic(selectedTopic, true);
        }).show();
    }

    void loadImage(ImageView view, String url) {
        if(view==null||url==null||url.isEmpty())return;
        Bitmap memory = imageMemory.get(url);
        if (memory != null && !memory.isRecycled()) {host.newsImageCacheHitCount++;view.setImageBitmap(memory); return;}
        final File disk = newsImageFile(url);
        synchronized(imageWaiterLock){
            ArrayList<WeakReference<ImageView>> waiters=imageWaiters.get(url);
            if(waiters!=null){waiters.add(new WeakReference<>(view));host.newsImageCoalescedCount++;return;}
            waiters=new ArrayList<>();waiters.add(new WeakReference<>(view));imageWaiters.put(url,waiters);
        }
        // Disco + decode também ficam fora da UI. O primeiro request para a URL é
        // dono do trabalho; os demais ImageViews apenas entram na lista de espera.
        executeNetwork(() -> {
            Bitmap decoded=null;byte[] bytes=null;
            if(disk.exists()){
                decoded=decodeNewsBitmap(disk);
                if(decoded!=null)host.newsImageCacheHitCount++;
            }
            if(decoded==null){
                host.newsImageCacheMissCount++;
                try {
                    HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
                    c.setConnectTimeout(8000); c.setReadTimeout(9000); c.setRequestProperty("User-Agent", "Mozilla/5.0");
                    if (c.getResponseCode() == 200) {
                        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                            byte[] buf = new byte[8192]; int count;
                            while ((count = in.read(buf)) != -1 && out.size() < 5 * 1024 * 1024) out.write(buf, 0, count);
                            bytes = out.toByteArray();
                        }
                        decoded=decodeNewsBitmap(bytes);
                    }
                    c.disconnect();
                    if (decoded != null) {
                        try { File dir = disk.getParentFile(); if (dir != null) dir.mkdirs(); try (FileOutputStream fos = new FileOutputStream(disk)) { if(bytes!=null)fos.write(bytes); } } catch (Exception ignored) {}
                    }
                } catch (Exception ignored) {}
            }
            if(decoded!=null)imageMemory.put(url,decoded);
            final Bitmap result=decoded;
            runOnUiThread(()->deliverNewsImage(url,result));
        });
    }

    void deliverNewsImage(String url,Bitmap bitmap){
        ArrayList<WeakReference<ImageView>> waiters;
        synchronized(imageWaiterLock){waiters=imageWaiters.remove(url);}
        if(bitmap==null||waiters==null||!isControllerActive())return;
        for(WeakReference<ImageView> ref:waiters){ImageView target=ref.get();if(target!=null&&target.isAttachedToWindow())target.setImageBitmap(bitmap);}
    }

    Bitmap decodeNewsBitmap(File file){
        if(file==null||!file.exists())return null;
        try{
            BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getAbsolutePath(),bounds);
            BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=newsSampleSize(bounds.outWidth,bounds.outHeight);opts.inPreferredConfig=Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(file.getAbsolutePath(),opts);
        }catch(Exception ignored){return null;}
    }

    Bitmap decodeNewsBitmap(byte[] bytes){
        if(bytes==null||bytes.length==0)return null;
        try{
            BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);
            BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=newsSampleSize(bounds.outWidth,bounds.outHeight);opts.inPreferredConfig=Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
        }catch(Exception ignored){return null;}
    }

    int newsSampleSize(int width,int height){
        int target=Math.max(dp(720),720),sample=1;
        while(width/sample>target*2||height/sample>target*2)sample*=2;
        return Math.max(1,sample);
    }

    File newsImageFile(String url) {
        File dir = new File(getCacheDir(), "news-images");
        return new File(dir, Integer.toHexString(url.hashCode()) + ".img");
    }

    String relativeTime(String raw) {
        long time = dateMillis(raw);
        if (time <= 0) return "";
        long min = Math.max(0, (System.currentTimeMillis() - time) / 60000L);
        if (min < 1) return "agora";
        if (min < 60) return "há " + min + " min";
        if (min < 1440) return "há " + (min / 60) + " h";
        return "há " + (min / 1440) + " dias";
    }

    long dateMillis(String raw) {
        if (raw == null || raw.isEmpty()) return 0;
        String[] patterns = {"EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd MMM yyyy HH:mm:ss Z"};
        for (String p : patterns) {
            try { Date d = new SimpleDateFormat(p, Locale.US).parse(raw); if (d != null) return d.getTime(); } catch (Exception ignored) {}
        }
        return 0;
    }

    void showEmpty() {
        list.removeAllViews();
        TextView empty = text("Sem notícias disponíveis no momento.", 14, themeSubtle);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(16), dp(70), dp(16), dp(70));
        list.addView(empty);
    }

    void saveCache(String key, ArrayList<NewsItem> items) {
        try {
            JSONArray a = itemsToJson(items, 24);
            prefs.edit().putString("newsCache:" + key, a.toString()).putLong("newsCacheTime:" + key, System.currentTimeMillis()).apply();
        } catch (Exception ignored) {}
    }

    JSONArray itemsToJson(ArrayList<NewsItem> items, int max) throws Exception {
        JSONArray a = new JSONArray();
        for (int i = 0; i < Math.min(items.size(), max); i++) {
            NewsItem n = items.get(i); JSONObject o = new JSONObject();
            o.put("t", n.title); o.put("l", n.link); o.put("s", n.source); o.put("d", n.pubDate); o.put("i", n.image); o.put("m", n.summary); a.put(o);
        }
        return a;
    }

    ArrayList<NewsItem> readItemsJson(String raw) {
        ArrayList<NewsItem> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i); NewsItem n = new NewsItem();
                n.title = o.optString("t"); n.link = o.optString("l"); n.source = o.optString("s"); n.pubDate = o.optString("d"); n.image = o.optString("i"); n.summary = o.optString("m");
                if (!n.title.isEmpty() && !n.link.isEmpty()) out.add(n);
            }
        } catch (Exception ignored) {}
        return out;
    }

    ArrayList<NewsItem> readCache(String key) { return readItemsJson(prefs.getString("newsCache:" + key, "[]")); }
    ArrayList<NewsItem> readSaved() { return readItemsJson(prefs.getString("newsSavedItems", "[]")); }

    boolean isSaved(String link) {
        for (NewsItem n : readSaved()) if (n.link.equals(link)) return true;
        return false;
    }

    void toggleSaved(NewsItem item) {
        ArrayList<NewsItem> saved = readSaved();
        int found = -1;
        for (int i = 0; i < saved.size(); i++) if (saved.get(i).link.equals(item.link)) { found = i; break; }
        boolean adding = found < 0;
        if (adding) saved.add(0, item); else saved.remove(found);
        try { prefs.edit().putString("newsSavedItems", itemsToJson(saved, 80).toString()).apply(); } catch (Exception ignored) {}
        Toast.makeText(this, adding ? "Matéria salva" : "Removida dos salvos", Toast.LENGTH_SHORT).show();
        if (viewingSaved) showSavedArticles();
    }

    void showSavedArticles() {
        viewingSaved = true; viewingHistory = false;
        panelTitle.setText("Salvos");
        renderChips();
        ArrayList<NewsItem> saved = readSaved();
        renderNews(saved);
        status.setText(saved.isEmpty() ? "Você ainda não salvou nenhuma matéria" : saved.size() + (saved.size() == 1 ? " matéria salva" : " matérias salvas"));
    }

    void showInfo() {
        String density = prefs.getBoolean("newsCompact", false) ? "Compacto" : "Confortável";
        String team = prefs.getString("newsFavoriteTeam", "").trim();
        String[] items = {"Atualizar agora", "Meus interesses", "Time favorito" + (team.isEmpty() ? "" : " · " + team), "Histórico de leitura", "Fontes favoritas", "Fontes ocultas", "Notícias salvas", "Visual dos cards · " + density, "Categoria inicial", "Limpar dados do painel", "Sobre o painel"};
        new NewsDialogBuilder(this).setTitle("Painel de notícias").setItems(items, (d, which) -> {
            if (which == 0) { if (viewingSaved) showSavedArticles(); else if (viewingHistory) showHistoryArticles(); else loadTopic(selectedTopic, false); loadSmartCards(); }
            else if (which == 1) chooseInterests();
            else if (which == 2) chooseFavoriteTeam();
            else if (which == 3) showHistoryArticles();
            else if (which == 4) manageSources(false);
            else if (which == 5) manageSources(true);
            else if (which == 6) showSavedArticles();
            else if (which == 7) { prefs.edit().putBoolean("newsCompact", !prefs.getBoolean("newsCompact", false)).apply(); applyNewsSearch(); }
            else if (which == 8) chooseDefaultTopic();
            else if (which == 9) showClearDialog();
            else new NewsDialogBuilder(this).setTitle("Sobre").setMessage("Painel inspirado na experiência de notícias à esquerda de launchers como o Pixel. Usa manchetes públicas via RSS, cards informativos de clima e placar esportivo e busca Google. Não é o Google Discover oficial e não acessa sua conta Google.").setPositiveButton("OK", null).show();
        }).show();
    }

    void chooseFavoriteTeam() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Ex.: Flamengo, Palmeiras, Corinthians");
        input.setText(prefs.getString("newsFavoriteTeam", ""));
        new NewsDialogBuilder(this).setTitle("Time favorito").setMessage("O quadro de placar procura jogos ao vivo, encerrados recentemente e próximos jogos do time. Ex.: Flamengo, Palmeiras, Corinthians.").setView(input)
                .setNeutralButton("Limpar", (d,w) -> { prefs.edit().remove("newsFavoriteTeam").apply(); clearScoreCache(); renderSmartCards(); })
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d,w) -> { prefs.edit().putString("newsFavoriteTeam", input.getText().toString().trim()).apply(); clearScoreCache(); renderSmartCards(); loadSportsScore(true); }).show();
    }

    void showHistoryArticles() {
        viewingSaved = false; viewingHistory = true;
        panelTitle.setText("Histórico");
        renderChips();
        ArrayList<NewsItem> history = readItemsJson(prefs.getString("newsHistoryItems", "[]"));
        renderNews(history);
        status.setText(history.isEmpty() ? "Você ainda não abriu nenhuma matéria" : history.size() + (history.size() == 1 ? " matéria lida" : " matérias lidas"));
    }

    void chooseInterests() {
        Set<String> current = new HashSet<>(prefs.getStringSet("newsInterests", Collections.emptySet()));
        boolean[] checked = new boolean[interestKeys.length];
        for (int i = 0; i < interestKeys.length; i++) checked[i] = current.contains(interestKeys[i]);
        new NewsDialogBuilder(this).setTitle("Meus interesses").setMultiChoiceItems(interestLabels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("Cancelar", null).setPositiveButton("Salvar", (d, w) -> {
                    HashSet<String> set = new HashSet<>();
                    for (int i = 0; i < interestKeys.length; i++) if (checked[i]) set.add(interestKeys[i]);
                    HashSet<String> muted = new HashSet<>(prefs.getStringSet("newsMutedTopics", Collections.emptySet()));
                    muted.removeAll(set);
                    prefs.edit().putStringSet("newsInterests", set).putStringSet("newsMutedTopics", muted).putString("newsTopic", "foryou").apply();
                    selectedTopic = "foryou"; viewingSaved = false; viewingHistory = false; renderChips(); loadTopic("foryou", false);
                }).show();
    }

    ArrayList<String> knownSources() {
        TreeSet<String> sources = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (String k : topicKeys) for (NewsItem n : readCache(k)) if (n.source != null && !n.source.trim().isEmpty()) sources.add(n.source.trim());
        for (NewsItem n : readSaved()) if (n.source != null && !n.source.trim().isEmpty()) sources.add(n.source.trim());
        sources.addAll(prefs.getStringSet("newsPreferredSources", Collections.emptySet()));
        sources.addAll(prefs.getStringSet("newsHiddenSources", Collections.emptySet()));
        return new ArrayList<>(sources);
    }

    void manageSources(boolean hiddenMode) {
        ArrayList<String> sources = knownSources();
        if (sources.isEmpty()) {
            new NewsDialogBuilder(this).setTitle(hiddenMode ? "Fontes ocultas" : "Fontes favoritas").setMessage("Ainda não há fontes suficientes no cache. Atualize algumas categorias e tente novamente.").setPositiveButton("OK", null).show();
            return;
        }
        String prefKey = hiddenMode ? "newsHiddenSources" : "newsPreferredSources";
        Set<String> current = new HashSet<>(prefs.getStringSet(prefKey, Collections.emptySet()));
        boolean[] checked = new boolean[sources.size()];
        for (int i = 0; i < sources.size(); i++) checked[i] = current.contains(sources.get(i));
        new NewsDialogBuilder(this).setTitle(hiddenMode ? "Fontes ocultas" : "Fontes favoritas").setMultiChoiceItems(sources.toArray(new String[0]), checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("Cancelar", null).setPositiveButton("Salvar", (d, w) -> {
                    HashSet<String> set = new HashSet<>();
                    for (int i = 0; i < sources.size(); i++) if (checked[i]) set.add(sources.get(i));
                    prefs.edit().putStringSet(prefKey, set).apply();
                    if (viewingHistory) showHistoryArticles(); else if (!viewingSaved) loadTopic(selectedTopic, true);
                }).show();
    }

    void showClearDialog() {
        String[] options = {"Limpar somente cache das notícias", "Limpar matérias salvas", "Limpar histórico de leitura", "Restaurar matérias/assuntos ocultados", "Limpar cache de imagens"};
        new NewsDialogBuilder(this).setTitle("Limpar dados do painel").setItems(options, (d, which) -> {
            if (which == 0) {
                SharedPreferences.Editor ed = prefs.edit();
                for (String k : topicKeys) ed.remove("newsCache:" + k).remove("newsCacheTime:" + k);
                ed.apply(); Toast.makeText(this, "Cache de notícias limpo", Toast.LENGTH_SHORT).show();
            } else if (which == 1) {
                prefs.edit().remove("newsSavedItems").apply(); Toast.makeText(this, "Matérias salvas removidas", Toast.LENGTH_SHORT).show();
                if (viewingSaved) showSavedArticles();
            } else if (which == 2) {
                prefs.edit().remove("newsReadLinks").remove("newsHistoryItems").apply(); Toast.makeText(this, "Histórico de leitura limpo", Toast.LENGTH_SHORT).show();
                if (viewingHistory) showHistoryArticles(); else if (!viewingSaved) loadTopic(selectedTopic, true);
            } else if (which == 3) {
                prefs.edit().remove("newsHiddenArticles").remove("newsMutedTopics").apply(); Toast.makeText(this, "Ocultações restauradas", Toast.LENGTH_SHORT).show();
                if (viewingHistory) showHistoryArticles(); else if (!viewingSaved) loadTopic(selectedTopic, false);
            } else {
                imageMemory.evictAll(); deleteRecursive(new File(getCacheDir(), "news-images")); Toast.makeText(this, "Cache de imagens limpo", Toast.LENGTH_SHORT).show();
            }
        }).show();
    }

    void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) { File[] files = f.listFiles(); if (files != null) for (File c : files) deleteRecursive(c); }
        try { f.delete(); } catch (Exception ignored) {}
    }

    void chooseDefaultTopic() {
        int selected = 0; for (int i = 0; i < topicKeys.length; i++) if (topicKeys[i].equals(selectedTopic)) selected = i;
        new NewsDialogBuilder(this).setTitle("Categoria inicial").setSingleChoiceItems(topics, selected, (d, which) -> {
            selectedTopic = topicKeys[which]; prefs.edit().putString("newsTopic", selectedTopic).apply(); viewingSaved = false; viewingHistory = false; d.dismiss(); renderChips(); loadTopic(selectedTopic, true);
        }).show();
    }

    void setupGestures() {
        panelTouchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        gestures = null; // Gestos são arbitrados manualmente para não brigar com rolagem e carrosséis.
    }

    boolean panelTouchInsideHorizontalScroller(float rawX,float rawY){return panelTouchInsideHorizontalScroller(getWindow().getDecorView(),rawX,rawY);}
    boolean panelTouchInsideHorizontalScroller(View view,float rawX,float rawY){
        if(view==null||view.getVisibility()!=View.VISIBLE)return false;
        if(view instanceof HorizontalScrollView){int[]loc=new int[2];view.getLocationOnScreen(loc);if(rawX>=loc[0]&&rawX<=loc[0]+view.getWidth()&&rawY>=loc[1]&&rawY<=loc[1]+view.getHeight())return true;}
        if(view instanceof ViewGroup){ViewGroup g=(ViewGroup)view;for(int i=0;i<g.getChildCount();i++)if(panelTouchInsideHorizontalScroller(g.getChildAt(i),rawX,rawY))return true;}
        return false;
    }

    boolean handlePanelTouchEvent(MotionEvent ev) {
        int action=ev.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN){
            panelDownX=ev.getRawX();panelDownY=ev.getRawY();pullStartX=ev.getX();pullStartY=ev.getY();panelGestureAxis=0;panelGestureBlocked=panelTouchInsideHorizontalScroller(ev.getRawX(),ev.getRawY());pulling=!panelGestureBlocked&&newsScroll!=null&&newsScroll.getScrollY()==0;
            if(panelVelocity!=null)panelVelocity.recycle();panelVelocity=VelocityTracker.obtain();panelVelocity.addMovement(ev);
        }else{
            if(panelVelocity!=null)panelVelocity.addMovement(ev);
            float dx=ev.getRawX()-panelDownX,dy=ev.getRawY()-panelDownY;float ax=Math.abs(dx),ay=Math.abs(dy);
            if(action==MotionEvent.ACTION_MOVE&&panelGestureAxis==0&&Math.max(ax,ay)>Math.max(panelTouchSlop*2,dp(10))){if(ax>ay*1.35f)panelGestureAxis=1;else if(ay>ax*1.35f)panelGestureAxis=2;}
            if(action==MotionEvent.ACTION_MOVE&&pulling&&panelGestureAxis!=1&&newsScroll!=null&&newsScroll.getScrollY()==0){if(dy>dp(48)&&ay>ax*1.25f&&!loading)status.setText(dy>dp(92)?"Solte para atualizar":"Puxe mais para atualizar");}
            if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
                float vx=0f;if(panelVelocity!=null){panelVelocity.computeCurrentVelocity(1000);vx=panelVelocity.getXVelocity();panelVelocity.recycle();panelVelocity=null;}
                boolean close=action==MotionEvent.ACTION_UP&&!panelGestureBlocked&&panelGestureAxis==1&&dx<-dp(72)&&ax>ay*1.35f&&(Math.abs(vx)>420f||ax>dp(120));
                boolean refresh=action==MotionEvent.ACTION_UP&&pulling&&panelGestureAxis!=1&&dy>dp(92)&&ay>ax*1.25f&&!loading&&newsScroll!=null&&newsScroll.getScrollY()==0;
                pulling=false;panelGestureAxis=0;
                if(close){finishPanel();return true;}
                if(refresh){if(viewingSaved)showSavedArticles();else if(viewingHistory)showHistoryArticles();else loadTopic(selectedTopic,false);loadSmartCards();}
            }
        }
        return false;
    }

    void finishPanel() {
        dismiss();
        host.overridePendingTransition(R.anim.news_stay, R.anim.news_exit_left);
    }
}
