package br.com.danilo.feedlauncher;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.lang.ref.WeakReference;

/**
 * v0.30.43 — proteção defensiva contra duas MainActivity no mesmo processo.
 *
 * O Manifest continua usando singleTask. Esta camada cobre comportamentos de OEM/
 * transições entre intent HOME e LAUNCHER que, em alguns aparelhos, podem criar uma
 * segunda instância antes de finalizar a primeira.
 */
final class MainActivityInstanceGuard {
    private static WeakReference<MainActivity> active = new WeakReference<>(null);

    private MainActivityInstanceGuard() {}

    static synchronized MainActivity claim(MainActivity candidate) {
        MainActivity current = active.get();
        if (current == null || current == candidate || current.isFinishing() || isDestroyed(current)) {
            active = new WeakReference<>(candidate);
            return null;
        }
        return current;
    }

    static synchronized void release(MainActivity activity) {
        MainActivity current = active.get();
        if (current == activity) active.clear();
    }

    static void handoff(MainActivity duplicate, MainActivity existing, Intent incoming) {
        if (duplicate == null || existing == null) return;
        try {
            existing.runOnUiThread(() -> {
                try { existing.handleHomeIntentFromDuplicate(incoming); } catch (Throwable ignored) {}
                try {
                    ActivityManager am = (ActivityManager) existing.getSystemService(Context.ACTIVITY_SERVICE);
                    if (am != null) am.moveTaskToFront(existing.getTaskId(), ActivityManager.MOVE_TASK_NO_USER_ACTION);
                } catch (Throwable ignored) {}
            });
        } catch (Throwable ignored) {}
        try { duplicate.finish(); } catch (Throwable ignored) {}
    }

    private static boolean isDestroyed(MainActivity activity) {
        return Build.VERSION.SDK_INT >= 17 && activity.isDestroyed();
    }
}
