/*
 * Copyright (C) 2012 The Android Open Source Project
 * Copyright (C) 2026 FeedLauncher contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Adapted from AOSP Launcher3 CheckLongPressHelper. It keeps Launcher3's 0.75 timeout factor
 * and slop-aware cancellation while depending only on public Android APIs.
 */
package br.com.danilo.feedlauncher.classic;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

final class L3CheckLongPressHelper {
    static final float DEFAULT_LONG_PRESS_TIMEOUT_FACTOR=.75f;

    private final View view;
    private final View.OnLongClickListener listener;
    private final float slop;
    private Runnable pending;
    private boolean performed;
    private float timeoutFactor=DEFAULT_LONG_PRESS_TIMEOUT_FACTOR;

    L3CheckLongPressHelper(View view,View.OnLongClickListener listener){
        this.view=view;this.listener=listener;this.slop=ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
    }

    void setLongPressTimeoutFactor(float factor){timeoutFactor=Math.max(.1f,factor);}

    void onTouchEvent(MotionEvent ev){
        if(ev==null)return;
        switch(ev.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                cancelLongPress();postCheckForLongPress();
                if(isStylusButtonPressed(ev))triggerLongPress();
                break;
            case MotionEvent.ACTION_MOVE:
                if(!pointInView(ev.getX(),ev.getY(),slop))cancelLongPress();
                else if(pending!=null&&isStylusButtonPressed(ev))triggerLongPress();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cancelLongPress();break;
        }
    }

    boolean hasPerformedLongPress(){return performed;}

    void cancelLongPress(){performed=false;clearCallbacks();}

    private void postCheckForLongPress(){
        performed=false;if(pending==null)pending=this::triggerLongPress;
        view.postDelayed(pending,(long)(ViewConfiguration.getLongPressTimeout()*timeoutFactor));
    }

    private void triggerLongPress(){
        if(view.getParent()!=null&&view.hasWindowFocus()&&!performed){
            boolean handled=listener!=null?listener.onLongClick(view):view.performLongClick();
            if(handled){view.cancelLongPress();view.setPressed(false);performed=true;}
        }
        clearCallbacks();
    }

    private void clearCallbacks(){if(pending!=null){view.removeCallbacks(pending);pending=null;}}

    private boolean pointInView(float x,float y,float s){return x>=-s&&y>=-s&&x<view.getWidth()+s&&y<view.getHeight()+s;}
    private static boolean isStylusButtonPressed(MotionEvent e){return e.getPointerCount()>0&&e.getToolType(0)==MotionEvent.TOOL_TYPE_STYLUS&&e.isButtonPressed(MotionEvent.BUTTON_SECONDARY);}
}
